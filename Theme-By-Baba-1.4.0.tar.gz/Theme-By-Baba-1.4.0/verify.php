<?php
declare(strict_types=1);
$package = __DIR__;
$panel = $argv[1] ?? '--package';
$packageOnly = $panel === '--package';
$root = $packageOnly ? $package.'/payload' : realpath($panel);
if (!$root || !is_dir($root)) { fwrite(STDERR, "Invalid panel directory.\n"); exit(1); }
$manifest = json_decode(file_get_contents($package.'/package-manifest.json'), true, 512, JSON_THROW_ON_ERROR);
$errors = [];
foreach ($manifest['files'] as $relative => $hash) {
    if (str_contains($relative, '..') || str_starts_with($relative, '/')) { $errors[] = 'Unsafe manifest path'; continue; }
    $file = $root.'/'.$relative;
    if (!is_file($file) || !hash_equals($hash, hash_file('sha256', $file))) $errors[] = 'Missing or changed: '.$relative;
}
$assets = json_decode(file_get_contents($root.'/public/assets/manifest.json'), true, 512, JSON_THROW_ON_ERROR);
foreach ($assets as $asset) {
    $src = $asset['src'] ?? '';
    if (!str_starts_with($src, '/assets/') || str_contains($src, '..')) { $errors[] = 'Invalid asset path'; continue; }
    $file = $root.'/public'.$src;
    if (!is_file($file)) { $errors[] = 'Missing frontend asset: '.$src; continue; }
    if (!empty($asset['integrity'])) {
        [$algorithm, $expected] = explode('-', $asset['integrity'], 2);
        if (!in_array($algorithm, ['sha256','sha384','sha512'], true) || !hash_equals($expected, base64_encode(hash_file($algorithm, $file, true)))) $errors[] = 'Frontend integrity mismatch: '.$src;
    }
}
if (!$packageOnly && !$errors) {
    require $root.'/vendor/autoload.php';
    $app = require $root.'/bootstrap/app.php';
    $app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();
    if (!Illuminate\Support\Facades\Route::has('admin.theme')) $errors[] = 'Admin theme editor route missing';
    foreach (['banner_image','icon_image'] as $column) {
        if (!Illuminate\Support\Facades\Schema::hasColumn('eggs', $column)) $errors[] = 'Egg artwork column missing: '.$column;
    }
    $theme = app(Pterodactyl\Services\Theme\PanelTheme::class)->get();
    foreach (['logo','icon','wallpaper'] as $key) {
        $url = $theme[$key] ?? '';
        if (str_starts_with($url, '/assets/') && !is_file($root.'/public'.$url)) $errors[] = 'Configured theme image missing: '.$key;
    }
}
if ($errors) { fwrite(STDERR, implode("\n", $errors)."\n"); exit(1); }
echo 'PASS: '.count($manifest['files']).' files, '.count($assets).' frontend assets'.($packageOnly ? ', package integrity' : ', Laravel boot, admin editor route and Egg artwork schema').".\n";
