# BABA HOST Theme 1.4.0

Latest deployed theme exported on 5 November 2026. Install on an existing Linux Pterodactyl **1.15.2** panel. This package installs the theme and its existing custom features; it does not install the panel, Wings or Minecraft servers.

Upload this entire `petrodetcyl` folder to your VPS, enter it, and run one command as root:

```bash
bash setup.sh /var/www/pterodactyl
```

The command checks SHA-256 checksums and compatibility, backs up replaced files and theme settings under `/var/backups/theme-by-baba-*`, installs the theme, applies migrations, clears caches and verifies installed files, frontend integrity, Laravel, the admin theme editor route and Egg artwork columns. A failure exits with an error and prints the restore command. No Node/Yarn build is needed; compiled assets and source are included.

Read-only preflight:

```bash
bash setup.sh /var/www/pterodactyl --check
```

Verify after installation:

```bash
php Theme-By-Baba-1.4.0/verify.php /var/www/pterodactyl
```

Use `--keep-branding` instead of `--check` to keep target panel theme settings. Otherwise BABA HOST branding is applied. Open Administration > Edit Theme to manage it. Refresh your browser with Ctrl+Shift+R.

The panel must already work, with PHP CLI, gd/zip/pdo_mysql, vendor dependencies, database, queue and HTTPS configured. Existing accounts, servers and node configuration are not exported or replaced. Other panel versions are rejected before installation. Custom themes on the destination need review before overwriting. Optional runtime Eggs are in `eggs/`; import those from Administration > Nests if needed.

Rollback uses the exact backup path printed by the installer:

```bash
bash /var/backups/theme-by-baba-XXXXXXXX/restore.sh /var/backups/theme-by-baba-XXXXXXXX
```

The additive Egg artwork database columns remain after rollback. Keep the backup safe. No .env, database dump, server data, tokens or sessions are included. Source and compiled assets are from the existing BABA HOST theme, not a new redesign. Pterodactyl licensing is preserved.

See VERIFICATION.txt for checks actually performed; a fresh second VPS installation is not claimed unless recorded there.
