#!/usr/bin/env bash
set -Eeuo pipefail
package="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
panel="$(realpath -e -- "${1:-/var/www/pterodactyl}")"
[[ $EUID -eq 0 ]] || { echo 'Run as root.'; exit 1; }
[[ -f "$panel/artisan" && -f "$panel/.env" && -d "$panel/vendor" ]] || { echo 'Install Pterodactyl first; this is a theme installer.'; exit 1; }
cd "$package"
sha256sum --check --quiet SHA256SUMS
php "$package/verify.php" --package
cd "$panel"
version="$(php -r 'require "vendor/autoload.php";$c=require "config/app.php";echo $c["version"]??"";')"
[[ "$version" == '1.15.2' ]] || { echo "Requires Pterodactyl 1.15.2; found $version. No files changed."; exit 1; }
php -r 'foreach(["gd","zip","pdo_mysql"] as $e){if(!extension_loaded($e)){fwrite(STDERR,"Missing PHP extension: $e\n");exit(1);}}'
webuser="$(stat -c '%U' storage)"
[[ "$webuser" != root ]] || webuser=www-data
id "$webuser" >/dev/null
if [[ "${2:-}" == '--check' ]]; then echo "Checks passed: compatible panel, dependencies and package integrity. No changes made."; exit 0; fi
backup="$(mktemp -d /var/backups/theme-by-baba-XXXXXXXX)"
chmod 700 "$backup"
printf '%s\n' "$panel" > "$backup/panel-path.txt"
: > "$backup/existing.txt"
: > "$backup/new.txt"
while IFS= read -r rel; do
 [[ "$rel" != /* && "$rel" != *..* ]] || exit 1
 resolved="$(realpath -m -- "$panel/$rel")"
 [[ "$resolved" == "$panel/"* ]] || { echo "Refusing path outside panel: $rel"; exit 1; }
 if [[ -e "$panel/$rel" ]]; then printf '%s\n' "$rel" >> "$backup/existing.txt"; else printf '%s\n' "$rel" >> "$backup/new.txt"; fi
done < "$package/payload-files.txt"
tar -czf "$backup/original-files.tar.gz" -C "$panel" -T "$backup/existing.txt"
cp "$package/restore.sh" "$backup/restore.sh"
cp "$package/settings.php" "$backup/settings.php"
php "$package/settings.php" backup "$panel" "$backup"
echo "File/settings backup: $backup"
echo 'On failure, run: bash '"$backup/restore.sh $backup"
trap 'echo "Installation stopped. Restore with: bash $backup/restore.sh $backup" >&2' ERR
cp -a "$package/payload/." "$panel/"
for dir in theme-uploads server-art eggs; do mkdir -p "$panel/public/assets/$dir"; chown "$webuser":"$(id -gn "$webuser")" "$panel/public/assets/$dir"; done
runuser -u "$webuser" -- php artisan migrate --force
if [[ "${2:-}" != '--keep-branding' ]]; then php "$package/settings.php" install "$panel" "$package"; fi
runuser -u "$webuser" -- php artisan optimize:clear
runuser -u "$webuser" -- php artisan view:cache
runuser -u "$webuser" -- php artisan queue:restart
php "$package/verify.php" "$panel"
trap - ERR
echo "Theme By Baba installed. Backup: $backup"
echo 'Verification passed. Hard refresh the browser, then open Administration > Edit Theme.'
echo 'Optional runtime Eggs: import the JSON files in eggs/ through Administration > Nests.'
