#!/usr/bin/env bash
set -Eeuo pipefail
[[ $EUID -eq 0 ]] || { echo 'Run as root.'; exit 1; }
backup="$(realpath -e -- "${1:?Pass the installation backup directory}")"
panel="$(realpath -e -- "$(cat "$backup/panel-path.txt")")"
[[ -f "$panel/artisan" && -f "$backup/original-files.tar.gz" ]] || exit 1
php "$backup/settings.php" restore "$panel" "$backup"
while IFS= read -r rel; do
 [[ "$rel" != /* && "$rel" != *..* ]] || exit 1
 resolved="$(realpath -m -- "$panel/$rel")"
 [[ "$resolved" == "$panel/"* ]] || exit 1
 [[ ! -d "$resolved" ]] && rm -f -- "$resolved"
done < "$backup/new.txt"
tar -xzf "$backup/original-files.tar.gz" -C "$panel"
cd "$panel"
webuser="$(stat -c '%U' storage)"; [[ "$webuser" != root ]] || webuser=www-data
runuser -u "$webuser" -- php artisan optimize:clear
runuser -u "$webuser" -- php artisan view:cache
runuser -u "$webuser" -- php artisan queue:restart
echo 'Original files/theme settings restored. Additive Egg image columns remain in the database.'
