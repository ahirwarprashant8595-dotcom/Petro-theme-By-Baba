<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddBannerAndIconColumnsToEggsTable extends Migration
{
    public function up(): void
    {
        Schema::table('eggs', function (Blueprint $table) {
            if (!Schema::hasColumn('eggs', 'banner_image')) {
                $table->string('banner_image')->nullable()->after('description');
            }
            if (!Schema::hasColumn('eggs', 'icon_image')) {
                $table->string('icon_image')->nullable()->after('banner_image');
            }
        });
    }

    public function down(): void
    {
        Schema::table('eggs', function (Blueprint $table) {
            $table->dropColumn(['banner_image', 'icon_image']);
        });
    }
}
