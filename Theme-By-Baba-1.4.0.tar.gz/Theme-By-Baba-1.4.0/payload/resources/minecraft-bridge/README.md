# BABA Utils Bridge 1.0.0

Paper/Spigot integration compiled against Spigot API 1.20.4, Java 17 bytecode. The dedicated panel test server runs Paper 1.21.4 / Java 21.

- Live snapshots every 5 seconds: actual online roster, inventory, equipment, Ender chest, position, XP, health, food, statistics, operator/whitelist/ban state and player-profile skin URL.
- Console-only `babautils` commands; in-game execution is rejected even for operators.
- World map uses actual top-surface block map colours in already-loaded chunks. It does not load/generate missing chunks. 128 pixels at 2 blocks/pixel; 256 samples per tick.
- Writes are restricted to this plugin's data folder. There is no HTTP listener or exposed bot token.
- Install through the panel's Players/World Viewer bridge control while the server is stopped; start afterwards.
- Other server software keeps saved world-file snapshots. These are clearly marked as snapshots, not live data.
- The panel requires file-read permissions for player data and console permissions for live changes. Player-data deletion requires the stopped server and an exact UUID confirmation. Egg reset is a separate owner-only, full-data deletion action with typed server-name confirmation.
- Modpack preparation verifies archive/download hashes, excludes client-only files and unsupported external hosts, and prepares a separate folder. Applying requires a stopped server, correct engine/version acknowledgement, typed server name and moves previous matching entries into a backup folder.

The bundled item/block textures are from the official Mojang Minecraft 1.21.4 client assets and are used as game-item previews. Minecraft assets remain the property of their respective owners.
