import { ThemeBrand } from '@/components/theme/PanelTheme';
import React from 'react';
import { NavLink } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
    faTerminal,
    faFolder,
    faDatabase,
    faCalendarAlt,
    faUsers,
    faCloudDownloadAlt,
    faGlobe,
    faRocket,
    faCog,
    faChartLine,
} from '@fortawesome/free-solid-svg-icons';
import Can from '@/components/elements/Can';
import { ServerContext } from '@/state/server';
import { minecraftFeatures } from '@/components/runtime/profile';
import { faUserFriends, faLayerGroup, faPuzzlePiece, faSlidersH } from '@fortawesome/free-solid-svg-icons';

interface Props {
    serverId: string;
}

export default ({ serverId }: Props) => {
    const features = minecraftFeatures(ServerContext.useStoreState((s) => s.server.data!));
    const navItems = [
        { name: 'Console', path: `/server/${serverId}`, exact: true, icon: faTerminal, permission: null },
        { name: 'Server Properties', path: `/server/${serverId}/options`, exact: false, icon: faSlidersH, permission: 'file.read-content', feature: 'options' },
        { name: 'Players Manager', path: `/server/${serverId}/players`, exact: false, icon: faUserFriends, permission: null, feature: 'minecraft' },
        { name: 'World Manager', path: `/server/${serverId}/worlds`, exact: false, icon: faGlobe, permission: 'file.read', feature: 'options' },
        { name: 'World Viewer', path: `/server/${serverId}/world-viewer`, exact: false, icon: faGlobe, permission: 'file.read-content', feature: 'options' },
        { name: 'Versions Manager', path: `/server/${serverId}/software`, exact: false, icon: faLayerGroup, permission: null, feature: 'minecraft' },
        { name: 'Plugins Manager', path: `/server/${serverId}/plugins`, exact: false, icon: faPuzzlePiece, permission: null, feature: 'plugins' },
        { name: 'Mods Manager', path: `/server/${serverId}/mods`, exact: false, icon: faPuzzlePiece, permission: null, feature: 'mods' },
        { name: 'Modpacks Manager', path: `/server/${serverId}/modpacks`, exact: false, icon: faLayerGroup, permission: 'file.create', feature: 'mods' },
        { name: 'Files', path: `/server/${serverId}/files`, exact: false, icon: faFolder, permission: 'file.*' },
        { name: 'Databases', path: `/server/${serverId}/databases`, exact: false, icon: faDatabase, permission: 'database.*' },
        { name: 'Schedules', path: `/server/${serverId}/schedules`, exact: false, icon: faCalendarAlt, permission: 'schedule.*' },
        { name: 'Users', path: `/server/${serverId}/users`, exact: false, icon: faUsers, permission: 'user.*' },
        { name: 'Backups', path: `/server/${serverId}/backups`, exact: false, icon: faCloudDownloadAlt, permission: 'backup.*' },
        { name: 'Network', path: `/server/${serverId}/network`, exact: false, icon: faGlobe, permission: 'allocation.*' },
        { name: 'Startup', path: `/server/${serverId}/startup`, exact: false, icon: faRocket, permission: 'startup.*' },
        { name: 'Settings', path: `/server/${serverId}/settings`, exact: false, icon: faCog, permission: ['settings.*', 'file.sftp'] },
        { name: 'Activity', path: `/server/${serverId}/activity`, exact: false, icon: faChartLine, permission: 'activity.*' },
    ];

    const visible=navItems.filter(item=>(item.feature!=='options'||features.options)&&(item.feature!=='minecraft'||features.minecraft)&&(item.feature!=='plugins'||features.plugins)&&(item.feature!=='mods'||features.mods));
    const renderItem=(item: typeof navItems[number])=>{
                        const linkContent = (
                            <NavLink
                                key={item.name}
                                to={item.path}
                                exact={item.exact}
                                title={item.name}
                                className={'bh-nav-link'}
                                activeClassName={'bh-nav-active'}
                            >
                                <FontAwesomeIcon icon={item.icon} className={'w-3.5 text-center text-xs'} />
                                <span>{item.name}</span>
                            </NavLink>
                        );

                        if (item.permission) {
                            return (
                                <Can key={item.name} action={item.permission} matchAny>
                                    {linkContent}
                                </Can>
                            );
                        }

                        return linkContent;
    };
    return (
        <aside className={'bh-sidebar'}>
            <div className={'bh-sidebar-content'}>
                {/* 1. Brand Logo */}
                <NavLink to={'/'} className={'bh-brand'}><ThemeBrand /></NavLink>

                {/* 2. Navigation items */}
                <nav className={'bh-nav'} aria-label={'Server navigation'}>
                    {visible.filter(item=>item.name==='Console').map(renderItem)}
                    {features.minecraft && <details className={'mcu-nav-group'} open><summary>MC UTILS</summary>{visible.filter(item=>!!item.feature).map(renderItem)}</details>}
                    {visible.filter(item=>!item.feature&&item.name!=='Console').map(renderItem)}
                </nav>
            </div>

            <NavLink to={'/'} className={'bh-back-dashboard'}>← <span>All servers</span></NavLink>
        </aside>
    );
};
