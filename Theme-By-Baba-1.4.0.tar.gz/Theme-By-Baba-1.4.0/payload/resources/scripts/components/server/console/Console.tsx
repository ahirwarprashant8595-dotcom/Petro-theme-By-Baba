import React, { useEffect, useMemo, useRef, useState } from 'react';
import { ITerminalOptions, Terminal } from 'xterm';
import { FitAddon } from 'xterm-addon-fit';
import { SearchAddon } from 'xterm-addon-search';
import { SearchBarAddon } from 'xterm-addon-search-bar';
import { WebLinksAddon } from 'xterm-addon-web-links';
import { Unicode11Addon } from 'xterm-addon-unicode11';
import { ScrollDownHelperAddon } from '@/plugins/XtermScrollDownHelperAddon';
import SpinnerOverlay from '@/components/elements/SpinnerOverlay';
import { ServerContext } from '@/state/server';
import useEventListener from '@/plugins/useEventListener';
import { debounce } from 'debounce';
import { SocketEvent, SocketRequest } from '@/components/server/events';
import classNames from 'classnames';

import 'xterm/css/xterm.css';
import styles from './style.module.css';

const theme = {
    background: '#0b0b0d',
    cursor: 'transparent',
    black: '#0b0b0d',
    red: '#EF4444',
    green: '#22C55E',
    yellow: '#FBBF24',
    blue: '#3B82F6',
    magenta: '#ab8bfa',
    cyan: '#06B6D4',
    white: '#E2E8F0',
    brightBlack: '#475569',
    brightRed: '#F87171',
    brightGreen: '#4ADE80',
    brightYellow: '#FDE047',
    brightBlue: '#60A5FA',
    brightMagenta: '#7f50f2',
    brightCyan: '#22D3EE',
    brightWhite: '#FFFFFF',
    selection: 'rgba(147, 51, 234, 0.45)',
};

const terminalProps: ITerminalOptions = {
    disableStdin: true,
    cursorStyle: 'underline',
    allowTransparency: true,
    fontSize: 12,
    fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace',
    theme: theme,
    convertEol: true,
    scrollback: 5000,
};

export default () => {
    const TERMINAL_PRELUDE = '\u001b[1m\u001b[35mcontainer@pterodactyl~ \u001b[0m';
    const ref = useRef<HTMLDivElement>(null);
    const terminal = useMemo(() => new Terminal({ ...terminalProps }), []);
    const fitAddon = useMemo(() => new FitAddon(), []);
    const searchAddon = useMemo(() => new SearchAddon(), []);
    const searchBar = useMemo(() => new SearchBarAddon({ searchAddon }), [searchAddon]);
    const webLinksAddon = useMemo(() => new WebLinksAddon(), []);
    const unicode11Addon = useMemo(() => new Unicode11Addon(), []);
    const scrollDownHelperAddon = useMemo(() => new ScrollDownHelperAddon(), []);
    const { connected, instance } = ServerContext.useStoreState((state) => state.socket);
    const serverId = ServerContext.useStoreState((state) => state.server.data!.id);
    const serverName = ServerContext.useStoreState((state) => state.server.data!.name);
    const isTransferring = ServerContext.useStoreState((state) => state.server.data!.isTransferring);
    const autoScrollRef = useRef(true);

    const zIndex = `
    .xterm-search-bar__addon {
        z-index: 10;
    }`;

    const handleConsoleOutput = (line: string, prelude = false) => {
        const viewport = terminal.buffer.active.viewportY;
        terminal.writeln((prelude ? TERMINAL_PRELUDE : '') + line.replace(/(?:\r\n|\r|\n)$/im, '') + '\u001b[0m');
        if (autoScrollRef.current) {
            terminal.scrollToBottom();
        } else {
            terminal.scrollToLine(viewport);
        }
    };

    const handleTransferStatus = (status: string) => {
        switch (status) {
            case 'failure':
                terminal.writeln(TERMINAL_PRELUDE + 'Transfer has failed.\u001b[0m');
                return;
        }
    };

    const handleDaemonErrorOutput = (line: string) =>
        terminal.writeln(
            TERMINAL_PRELUDE + '\u001b[1m\u001b[41m' + line.replace(/(?:\r\n|\r|\n)$/im, '') + '\u001b[0m'
        );

    const handlePowerChangeEvent = (state: string) =>
        terminal.writeln(TERMINAL_PRELUDE + 'Server marked as ' + state + '...\u001b[0m');

    // Mount terminal
    useEffect(() => {
        if (connected && ref.current && !terminal.element) {
            terminal.loadAddon(fitAddon);
            terminal.loadAddon(searchAddon);
            terminal.loadAddon(searchBar);
            terminal.loadAddon(webLinksAddon);
            terminal.loadAddon(unicode11Addon);
            terminal.loadAddon(scrollDownHelperAddon);

            terminal.open(ref.current);
            terminal.unicode.activeVersion = '11';

            // Safe initial fit with small delay for font & container calculation
            setTimeout(() => {
                try {
                    fitAddon.fit();
                } catch (e) {
                    // ignore
                }
            }, 60);

            searchBar.addNewStyle(zIndex);

            terminal.attachCustomKeyEventHandler((e: KeyboardEvent) => {
                if ((e.ctrlKey || e.metaKey) && e.key === 'c') {
                    document.execCommand('copy');
                    return false;
                } else if ((e.ctrlKey || e.metaKey) && e.key === 'f') {
                    e.preventDefault();
                    searchBar.show();
                    return false;
                } else if (e.key === 'Escape') {
                    searchBar.hidden();
                }
                return true;
            });
        }
    }, [terminal, connected]);

    // ResizeObserver for dynamic, reliable auto-fitting
    useEffect(() => {
        if (!ref.current) return;
        const observer = new ResizeObserver(
            debounce(() => {
                if (terminal.element) {
                    try {
                        fitAddon.fit();
                    } catch (e) {
                        // ignore
                    }
                }
            }, 80)
        );
        observer.observe(ref.current);
        return () => observer.disconnect();
    }, [terminal, fitAddon]);

    useEffect(() => () => terminal.dispose(), [terminal]);

    // Handle Clear Event
    useEffect(() => {
        const onClear = () => {
            terminal.clear();
        };
        window.addEventListener('clear-terminal', onClear);
        return () => window.removeEventListener('clear-terminal', onClear);
    }, [terminal]);

    // Handle Download Logs Event
    useEffect(() => {
        const onDownload = () => {
            try {
                const buffer = terminal.buffer.active;
                let text = '';
                for (let i = 0; i < buffer.length; i++) {
                    const line = buffer.getLine(i);
                    if (line) {
                        text += line.translateToString(true) + '\n';
                    }
                }
                const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `${serverName || 'server'}-console-${new Date().toISOString().slice(0, 10)}.log`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
            } catch (e) {
                console.error('Failed to download logs', e);
            }
        };
        window.addEventListener('download-terminal-logs', onDownload);
        return () => window.removeEventListener('download-terminal-logs', onDownload);
    }, [terminal, serverName]);

    // Handle Auto-Scroll Toggle Event
    useEffect(() => {
        const onToggleScroll = (e: any) => {
            if (e.detail !== undefined) {
                autoScrollRef.current = !!e.detail;
            } else {
                autoScrollRef.current = !autoScrollRef.current;
            }
            if (autoScrollRef.current) {
                terminal.scrollToBottom();
            }
        };
        window.addEventListener('toggle-autoscroll', onToggleScroll);
        return () => window.removeEventListener('toggle-autoscroll', onToggleScroll);
    }, [terminal]);

    // Socket listeners
    useEffect(() => {
        const listeners: Record<string, (s: string) => void> = {
            [SocketEvent.STATUS]: handlePowerChangeEvent,
            [SocketEvent.CONSOLE_OUTPUT]: handleConsoleOutput,
            [SocketEvent.INSTALL_OUTPUT]: handleConsoleOutput,
            [SocketEvent.TRANSFER_LOGS]: handleConsoleOutput,
            [SocketEvent.TRANSFER_STATUS]: handleTransferStatus,
            [SocketEvent.DAEMON_MESSAGE]: (line) => handleConsoleOutput(line, true),
            [SocketEvent.DAEMON_ERROR]: handleDaemonErrorOutput,
        };

        if (connected && instance) {
            if (!isTransferring) {
                terminal.clear();
            }

            Object.keys(listeners).forEach((key: string) => {
                instance.addListener(key, listeners[key]);
            });
            instance.send(SocketRequest.SEND_LOGS);
        }

        return () => {
            if (instance) {
                Object.keys(listeners).forEach((key: string) => {
                    instance.removeListener(key, listeners[key]);
                });
            }
        };
    }, [connected, instance]);

    return (
        <div className={classNames(styles.terminal, 'relative w-full h-full')}>
            <SpinnerOverlay visible={!connected} size={'large'} />
            <div className={classNames(styles.container, 'w-full h-full')}>
                <div id={styles.terminal} ref={ref} className={'w-full h-full'} />
            </div>
        </div>
    );
};
