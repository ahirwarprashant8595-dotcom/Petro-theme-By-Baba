import useInstalledSoftware from '@/components/runtime/useInstalledSoftware';
import React, { memo, useEffect, useState } from 'react';
import copy from 'copy-to-clipboard';
import { ServerContext } from '@/state/server';
import isEqual from 'react-fast-compare';
import Can from '@/components/elements/Can';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPlay, faSyncAlt, faSquare, faTrashAlt, faDownload, faCopy, faCheck, faTerminal, faArrowUp, faArrowDown, faMicrochip, faMemory, faHdd, faUsers, faGlobe } from '@fortawesome/free-solid-svg-icons';
import useWebsocketEvent from '@/plugins/useWebsocketEvent';
import { SocketEvent, SocketRequest } from '@/components/server/events';
import { bytesToString, ip, mbToBytes } from '@/lib/formatters';
import UptimeDuration from '@/components/server/UptimeDuration';
import Console from '@/components/server/console/Console';
import { Dialog } from '@/components/elements/dialog';
import Features from '@feature/Features';
import http, { httpErrorToHuman } from '@/api/http';
import { runtimeProfile } from '@/components/runtime/profile';
import RuntimeIcon from '@/components/runtime/RuntimeIcon';
import useMinecraftStatus from '@/components/runtime/useMinecraftStatus';

export type PowerAction = 'start' | 'restart' | 'stop' | 'kill';
interface Stats { memory: number; cpu: number; disk: number; uptime: number; rx: number; tx: number; }

const ServerConsoleContainer = () => {
    const server = ServerContext.useStoreState((s) => s.server.data!);
    const status = ServerContext.useStoreState((s) => s.status.value);
    const { connected, instance } = ServerContext.useStoreState((s) => s.socket);
    const setStatus = ServerContext.useStoreActions((s) => s.status.setServerStatus);
    const [stats, setStats] = useState<Stats | null>(null);
    const [command, setCommand] = useState('');
    const [autoScroll, setAutoScroll] = useState(true);
    const [copied, setCopied] = useState(false);
    const [killOpen, setKillOpen] = useState(false);
    const [pending, setPending] = useState(false);
    const [error, setError] = useState('');
    const installation = useInstalledSoftware(server.id, runtimeProfile(server).minecraft);
    const profile = runtimeProfile(server);
    const banner = server.bannerUrl || (profile.minecraft ? '/assets/eggs/minecraft_banner_new.png' : null);
    const minecraft = useMinecraftStatus(server.id, profile.minecraft);
    const allocation = server.allocations.find((a) => a.isDefault) || server.allocations[0];
    const address = allocation ? `${allocation.alias || ip(allocation.ip)}:${allocation.port}` : 'No allocation';
    const running = status === 'running';
    const stopping = status === 'stopping';
    const canCommand = connected && (running || status === 'starting');
    const label = !connected ? 'Connecting' : status ? status.charAt(0).toUpperCase() + status.slice(1) : 'Loading';

    useWebsocketEvent(SocketEvent.STATS, (data: string) => {
        try {
            const p = JSON.parse(data);
            setStats({ memory: p.memory_bytes || 0, cpu: p.cpu_absolute || 0, disk: p.disk_bytes || 0, uptime: p.uptime || 0, rx: p.network?.rx_bytes || 0, tx: p.network?.tx_bytes || 0 });
            if (['running', 'offline', 'starting', 'stopping'].includes(p.state)) setStatus(p.state);
        } catch (e) { console.error(e); }
    });
    useEffect(() => { if (connected && instance) instance.send(SocketRequest.SEND_STATS); }, [connected, instance]);
    useEffect(() => { if (!connected) setStats(null); }, [connected]);
    const power = (signal: PowerAction) => {
        if (!connected || pending) return;
        if (signal === 'kill') { setKillOpen(true); return; }
        sendPower(signal);
    };
    const sendPower = (signal: PowerAction) => {
        setPending(true); setError('');
        http.post(`/api/client/servers/${server.id}/power`, { signal })
            .catch((e) => setError(httpErrorToHuman(e))).finally(() => setPending(false));
    };
    const sendCommand = (e: React.FormEvent) => {
        e.preventDefault();
        if (!command.trim() || !instance || !canCommand) return;
        instance.send('send command', command); setCommand('');
    };
    const copyAddress = () => { if (allocation && copy(address)) { setCopied(true); setTimeout(() => setCopied(false), 2000); } };
    const limit = (v: number) => v ? bytesToString(mbToBytes(v)) : 'Unlimited';
    const percent = (v: number, max: number) => max > 0 ? Math.min(100, Math.max(0, v / max * 100)) : 0;
    const resource = (title: string, icon: any, value: string, max: string, fill: number) => (
        <div className={'bh-resource'}><div className={'bh-resource-label'}><span><FontAwesomeIcon icon={icon} />{title}</span><span>{max}</span></div><strong>{value}</strong><div className={'bh-meter'}><i style={{ width: `${fill}%` }} /></div></div>
    );
    return (
        <div className={'bh-server-page'}>
            <Dialog.Confirm open={killOpen} onClose={() => setKillOpen(false)} title={'Force stop server?'} confirm={'Force stop'} onConfirmed={() => { setKillOpen(false); sendPower('kill'); }}>This immediately stops the process. Unsaved data may be lost.</Dialog.Confirm>
            <section className={'bh-server-heading'}>
                {banner && <img className={'bh-heading-art'} src={banner} alt={''} />}
                <div className={'bh-server-identity'}><RuntimeIcon kind={profile.kind} src={server.iconUrl} size={48} /><div><div className={'bh-eyebrow'}>{server.nestName || 'Server management'}</div><h1>{server.name}</h1><div className={'bh-runtime-line'}><span title={server.installedSoftware ? `Installed jar: ${server.installedSoftware.path}` : undefined}>{profile.minecraft ? server.installedSoftware ? profile.label : 'Minecraft' : profile.label}</span>{profile.minecraft && <span>{minecraft?.available && minecraft.version ? `Live: ${minecraft.version}` : installation?.running?.available && installation.running.version ? `Live: ${installation.running.version}` : profile.runtimeLabel}</span>}
                        {allocation && (
                            <button
                                type={'button'}
                                className={'bh-ip-badge'}
                                onClick={copyAddress}
                                                            >
                                <FontAwesomeIcon icon={faGlobe} />
                                <span className={'bh-ip-value'}>{address}</span>
                                <FontAwesomeIcon icon={copied ? faCheck : faCopy} className={'bh-ip-copy'} />
                            </button>
                        )}
                    </div></div></div>
                <div className={'bh-heading-controls'}><span className={`bh-status bh-status-${connected ? status : 'connecting'}`}><i />{label}</span><div className={'bh-power'}>
                    <Can action={'control.start'}><button className={'bh-button bh-primary'} disabled={!connected || status !== 'offline' || pending} onClick={() => power('start')}><FontAwesomeIcon icon={faPlay} />Start</button></Can>
                    <Can action={'control.restart'}><button className={'bh-button'} disabled={!connected || !status || status === 'offline' || stopping || pending} onClick={() => power('restart')}><FontAwesomeIcon icon={faSyncAlt} />Restart</button></Can>
                    <Can action={'control.stop'}><button className={'bh-button bh-danger'} disabled={!connected || !status || status === 'offline' || pending} onClick={() => power(stopping ? 'kill' : 'stop')}><FontAwesomeIcon icon={faSquare} />{stopping ? 'Force stop' : 'Stop'}</button></Can>
                </div></div>
            </section>
            {error && <div className={'bh-error'} role={'alert'}>{error}</div>}
            <div className={'bh-console-layout'}>
                <div className={'bh-console-column'}>
                    <section className={'bh-panel bh-console-panel'}>
                        <div className={'bh-panel-heading'}><h2><FontAwesomeIcon icon={faTerminal} />Console</h2><div className={'bh-console-tools'}>
                            <label className={'bh-auto-scroll'}><input type={'checkbox'} checked={autoScroll} onChange={(e) => { setAutoScroll(e.target.checked); window.dispatchEvent(new CustomEvent('toggle-autoscroll', { detail: e.target.checked })); }} />Auto scroll</label>
                            <button className={'bh-icon-button'} title={'Clear console'} aria-label={'Clear console'} onClick={() => window.dispatchEvent(new CustomEvent('clear-terminal'))}><FontAwesomeIcon icon={faTrashAlt} /></button>
                            <button className={'bh-icon-button'} title={'Download logs'} aria-label={'Download logs'} onClick={() => window.dispatchEvent(new CustomEvent('download-terminal-logs'))}><FontAwesomeIcon icon={faDownload} /></button>
                        </div></div>
                        <div className={'bh-terminal'}><Console /></div>
                        <Can action={'control.console'}><form className={'bh-command'} onSubmit={sendCommand}><span>›</span><input aria-label={'Server command'} value={command} onChange={(e) => setCommand(e.target.value)} disabled={!canCommand} placeholder={canCommand ? 'Enter a command…' : 'Start the server to send commands'} autoComplete={'off'} /><button className={'bh-button'} disabled={!canCommand || !command.trim()} type={'submit'}>Send <FontAwesomeIcon icon={faArrowUp} /></button></form></Can>
                    </section>
                    <div className={`bh-summary-grid ${profile.minecraft ? 'bh-summary-minecraft' : ''}`}>
                        {profile.minecraft && <div className={'bh-panel bh-summary'}><span><FontAwesomeIcon icon={faUsers} />Players</span><strong>{minecraft?.available ? `${minecraft.online} / ${minecraft.max}` : '—'}</strong><small>{minecraft?.available ? 'Reported by server' : 'Status query unavailable'}</small></div>}
                        <div className={'bh-panel bh-summary'}><span><FontAwesomeIcon icon={faArrowDown} />Network received</span><strong>{stats ? bytesToString(stats.rx) : '—'}</strong><small>Total this session</small></div>
                        <div className={'bh-panel bh-summary'}><span><FontAwesomeIcon icon={faArrowUp} />Network sent</span><strong>{stats ? bytesToString(stats.tx) : '—'}</strong><small>Total this session</small></div>
                    </div>
                </div>
                <aside className={'bh-details-column'}>
                    <div className={'bh-companion'} aria-hidden={'true'}><span className={'bh-companion-star'}>✦</span><img src={'/assets/egg-art-20261027/console-companion.png'} alt={''} draggable={false} /><span className={'bh-companion-star bh-companion-star-small'}>✧</span></div>
                    <section className={'bh-panel'}><div className={'bh-panel-heading'}><h2>Resources</h2><span className={'bh-caption'}>{connected ? 'Live' : 'Waiting'}</span></div>
                        {resource('CPU', faMicrochip, stats ? `${stats.cpu.toFixed(1)}%` : '—', server.limits.cpu ? `${server.limits.cpu}%` : 'Unlimited', percent(stats?.cpu || 0, server.limits.cpu))}
                        {resource('Memory', faMemory, stats ? bytesToString(stats.memory) : '—', limit(server.limits.memory), percent(stats?.memory || 0, mbToBytes(server.limits.memory)))}
                        {resource('Storage', faHdd, stats ? bytesToString(stats.disk) : '—', limit(server.limits.disk), percent(stats?.disk || 0, mbToBytes(server.limits.disk)))}
                    </section>
                    <section className={'bh-panel bh-connection'}><h2>Connection</h2><span className={'bh-caption'}>Server address</span><button className={'bh-address'} onClick={copyAddress} title={'Copy server address'}><code>{address}</code><FontAwesomeIcon icon={copied ? faCheck : faCopy} /></button><div className={'bh-info-row'}><span>Uptime</span><strong>{stats ? <UptimeDuration uptime={stats.uptime / 1000} /> : '—'}</strong></div><div className={'bh-info-row'}><span>Node</span><strong>{server.node}</strong></div><div className={'bh-info-row'}><span>Runtime</span><strong>{profile.runtimeLabel}</strong></div><div className={'bh-info-row'}><span>Egg</span><strong>{profile.egg}</strong></div></section>
                </aside>
            </div>
            <Features enabled={server.eggFeatures} />
        </div>
    );
};
export default memo(ServerConsoleContainer, isEqual);
