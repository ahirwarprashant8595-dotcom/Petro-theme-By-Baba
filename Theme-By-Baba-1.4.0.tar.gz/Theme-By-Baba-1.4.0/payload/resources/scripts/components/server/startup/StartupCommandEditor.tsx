import React, { useEffect, useState } from 'react';
import http, { httpErrorToHuman } from '@/api/http';
import { usePermissions } from '@/plugins/usePermissions';

export default function StartupCommandEditor({ uuid, refresh }: { uuid: string; refresh: () => void }) {
    const [allowed] = usePermissions('startup.update');
    const [command, setCommand] = useState('');
    const [original, setOriginal] = useState('');
    const [ready, setReady] = useState(false);
    const [busy, setBusy] = useState(false);
    const [error, setError] = useState('');
    const [message, setMessage] = useState('');
    useEffect(() => {
        let active = true;
        http.get(`/api/client/servers/${uuid}/startup`).then(({ data }) => {
            if (active) { setCommand(data.meta.raw_startup_command); setOriginal(data.meta.raw_startup_command); setReady(true); }
        }).catch((e) => { if (active) setError(httpErrorToHuman(e)); });
        return () => { active = false; };
    }, [uuid]);
    const save = (reset = false) => {
        setBusy(true); setError(''); setMessage('');
        http.put(`/api/client/servers/${uuid}/startup/command`, reset ? { reset: true } : { command }).then(({ data }) => {
            setCommand(data.raw_startup_command); setOriginal(data.raw_startup_command);
            setMessage('Saved. The command takes effect on the next server restart.'); refresh();
        }).catch((e) => setError(httpErrorToHuman(e))).finally(() => setBusy(false));
    };
    if (!allowed) return null;
    return <div style={{ marginTop: 14 }}>
        <label htmlFor={'custom-startup-command'}>Custom startup command</label>
        <textarea id={'custom-startup-command'} value={command} disabled={!ready || busy} maxLength={10000}
            onChange={(e) => { setCommand(e.target.value); setMessage(''); }} rows={6}
            style={{ width: '100%', marginTop: 8, padding: 12, fontFamily: 'monospace', fontSize: 12, resize: 'vertical', background: '#09090b', color: '#e4e4e7', border: '1px solid #303034', borderRadius: 6 }} />
        <p style={{ fontSize: 12, marginTop: 8 }}>Use the container environment variables, for example $&#123;STARTUP_FILE&#125;. Python dependencies must be listed in your requirements file or Extra Python Packages.</p>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 12 }}>
            <button type={'button'} className={'bh-button bh-primary'} disabled={!ready || busy || !command.trim() || command === original} onClick={() => save()}>{busy ? 'Saving…' : 'Save command'}</button>
            <button type={'button'} className={'bh-button'} disabled={!ready || busy} onClick={() => save(true)}>Reset to Egg default</button>
        </div>
        {error && <p className={'bh-error'} role={'alert'}>{error}</p>}
        {message && <p role={'status'} style={{ marginTop: 10, fontSize: 12 }}>{message}</p>}
    </div>;
}
