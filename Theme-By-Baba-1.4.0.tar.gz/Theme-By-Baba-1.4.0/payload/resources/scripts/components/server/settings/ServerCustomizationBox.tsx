import React, { useEffect, useState } from 'react';
import http, { httpErrorToHuman } from '@/api/http';
import { ServerContext } from '@/state/server';
import { usePermissions } from '@/plugins/usePermissions';
import { Link } from 'react-router-dom';
interface Configuration { runtime_enabled: boolean; egg_id: number; eggs: {id: number; name: string}[]; icon_url: string | null; banner_url: string | null; can_switch: boolean; }
export default function ServerCustomizationBox() {
    const server = ServerContext.useStoreState((s) => s.server.data!);
    const updateServer = ServerContext.useStoreActions((s) => s.server.setServerFromState);
    const [artAllowed, createAllowed, updateAllowed, archiveAllowed] = usePermissions(['settings.rename','file.create','file.update','file.archive']);
    const [config, setConfig] = useState<Configuration | null>(null);
    const [egg, setEgg] = useState(''); const [confirmed, setConfirmed] = useState(false);
    const [url, setUrl] = useState(''); const [branch, setBranch] = useState('');
    const [busy, setBusy] = useState(''); const [progress, setProgress] = useState<number | null>(null);
    const [error, setError] = useState(''); const [message, setMessage] = useState('');
    const [directory, setDirectory] = useState('');
    const load = () => http.get(`/api/client/servers/${server.uuid}/customization`).then(({data}) => { setConfig(data); setEgg(String(data.egg_id)); });
    useEffect(() => { load().catch((e) => setError(httpErrorToHuman(e))); }, [server.uuid]);
    const start = (kind: string) => { setBusy(kind); setError(''); setMessage(''); };
    const art = (kind: 'icon'|'banner', file?: File) => {
        if (file && file.size > 5 * 1024 * 1024) { setError('Choose an image smaller than 5 MB.'); return; }
        const body = new FormData(); body.append('kind',kind); if (file) body.append('image',file); else body.append('reset','1');
        start(kind); setProgress(0);
        http.post(`/api/client/servers/${server.uuid}/customization/artwork`, body, { onUploadProgress: (e) => setProgress(e.total ? Math.min(99,Math.round(e.loaded/e.total*100)) : null) }).then(({data}) => {
            setConfig(data);updateServer((s) => ({...s, iconUrl:data.icon_url, bannerUrl:data.banner_url}));setMessage('Server artwork saved. Dashboard and console now use your images.');
        }).catch((e) => setError(httpErrorToHuman(e))).finally(() => {setBusy('');setProgress(null);});
    };
    const changeEgg = () => {
        start('egg');http.post(`/api/client/servers/${server.uuid}/customization/egg`,{egg_id:Number(egg),confirm:confirmed}).then(() => {window.location.reload();})
            .catch((e) => {setError(httpErrorToHuman(e));setBusy('');});
    };
    const importCode = () => {
        start('github');setDirectory('');http.post(`/api/client/servers/${server.uuid}/customization/github`,{url:url.trim(),branch:branch.trim() || null},{timeout:180000}).then(({data}) => {
            setDirectory(data.directory);setMessage(`Imported ${data.repository} at commit ${data.commit.slice(0,8)} into ${data.directory}. Existing files were preserved. Configure your Startup command to run from this folder.`);
        }).catch((e) => setError(httpErrorToHuman(e))).finally(() => setBusy(''));
    };
    return <>
        {artAllowed && <section className={'bh-panel bh-customization-box'}><h3>Server logo &amp; banner</h3><p>Applies only to this server. PNG, JPEG or WebP, up to 5 MB.</p>
            <div className={'bh-customization-art'}>{(['icon','banner'] as const).map((kind) => <div key={kind}>
                {config?.[`${kind}_url`] && <img src={config[`${kind}_url`]!} alt={`Server ${kind}`} className={`bh-customization-${kind}`} />}
                <label>{kind === 'icon' ? 'Server logo' : 'Server banner'}<input type={'file'} accept={'image/png,image/jpeg,image/webp'} disabled={!!busy} onChange={(e) => {const file=e.target.files?.[0];if(file)art(kind,file);e.target.value='';}} /></label>
                <button className={'bh-button'} disabled={!!busy} onClick={() => art(kind)}>Use Egg default</button>
            </div>)}</div>
        </section>}
        {config?.runtime_enabled && (config.can_switch || (createAllowed && updateAllowed && archiveAllowed)) && <section className={'bh-panel bh-customization-box'}><h3>Runtime &amp; GitHub code</h3>
            {config.can_switch && <div><label>Server Egg<select value={egg} disabled={!!busy} onChange={(e) => {setEgg(e.target.value);setConfirmed(false);}}>{config.eggs.map((e) => <option key={e.id} value={e.id}>{e.name}</option>)}</select></label>
                <p>Stop the server first. Switching changes the runtime image, startup command and variables to the new Egg defaults. Your files stay in place; installation scripts are not run.</p>
                <label className={'bh-customization-confirm'}><input type={'checkbox'} checked={confirmed} onChange={(e) => setConfirmed(e.target.checked)} disabled={!!busy} /> I understand startup variables will reset.</label>
                <button className={'bh-button bh-primary'} disabled={!!busy || !confirmed || Number(egg)===config.egg_id} onClick={changeEgg}>Change Egg</button></div>}
            {createAllowed && updateAllowed && archiveAllowed && <div className={'bh-customization-import'}><h4>Import from GitHub</h4>
                <label>Public repository URL<input type={'url'} value={url} disabled={!!busy} placeholder={'https://github.com/owner/repository'} onChange={(e) => setUrl(e.target.value)} /></label>
                <label>Branch (optional)<input value={branch} disabled={!!busy} placeholder={'Repository default branch'} onChange={(e) => setBranch(e.target.value)} /></label>
                <p>Server must be stopped. Imports into a new project folder without overwriting existing files. Maximum 20 MB ZIP / 50 MB extracted. Private repositories and symlinks are not supported.</p>
                <button className={'bh-button bh-primary'} disabled={!!busy || !url.trim()} onClick={importCode}>{busy==='github' ? 'Downloading & importing…' : 'Import code'}</button>
                {directory && <Link className={'bh-button'} to={`/server/${server.id}/files#${directory}`}>Open imported files</Link>}
            </div>}
        </section>}
        {busy && <p role={'status'} className={'bh-customization-status'}><span className={'bh-customization-spinner'} aria-hidden />{progress!==null ? `Uploading ${progress}% · processing image…` : 'Working… Please keep this page open.'}</p>}
        {error && <p className={'bh-error'} role={'alert'}>{error}</p>}{message && <p role={'status'} className={'bh-customization-status'}>{message}</p>}
    </>;
}
