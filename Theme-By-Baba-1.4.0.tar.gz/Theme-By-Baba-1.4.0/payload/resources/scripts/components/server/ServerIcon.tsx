import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
    faCube,
    faGamepad,
    faRobot,
    faServer,
} from '@fortawesome/free-solid-svg-icons';

interface Props {
    nestId?: number | null;
    eggId?: number | null;
    nestName?: string | null;
    eggName?: string | null;
    serverName?: string;
    iconUrl?: string | null;
    className?: string;
    imageClassName?: string;
}

export const getServerIcon = ({
    nestId,
    eggId,
    nestName,
    eggName,
    serverName,
    iconUrl,
}: Partial<Props>): { type: 'image' | 'icon'; src?: string; icon?: any; color?: string } => {
    // 1. Direct configured iconUrl
    if (iconUrl && iconUrl.trim().length > 0) {
        return { type: 'image', src: iconUrl };
    }

    const nName = (nestName || '').toLowerCase();
    const eName = (eggName || '').toLowerCase();
    const sName = (serverName || '').toLowerCase();

    // 2. Minecraft Check (Nest 1 or names)
    if (
        nestId === 1 ||
        nName.includes('minecraft') ||
        eName.includes('paper') ||
        eName.includes('spigot') ||
        eName.includes('purpur') ||
        eName.includes('forge') ||
        eName.includes('sponge') ||
        eName.includes('vanilla') ||
        eName.includes('bungee') ||
        eName.includes('velocity') ||
        sName.includes('minecraft') ||
        sName.includes('mc')
    ) {
        return { type: 'image', src: '/assets/eggs/minecraft_icon_new.png' };
    }

    // 3. Discord Bot Check (Nest 5 or name)
    if (
        nestId === 5 ||
        nName.includes('discord') ||
        eName.includes('discord') ||
        sName.includes('discord') ||
        sName.includes('bot')
    ) {
        // SVG Discord or icon
        return { type: 'image', src: '/assets/eggs/itc_icon.png' };
    }

    // 4. Python Check
    if (eName.includes('python') || nName.includes('python')) {
        return { type: 'image', src: '/assets/eggs/itc_icon.png' };
    }

    // 5. Source Engine Games (CS:GO, TF2, Rust, Garrys Mod)
    if (
        nestId === 2 ||
        nestId === 4 ||
        nName.includes('source') ||
        nName.includes('rust') ||
        eName.includes('rust') ||
        eName.includes('cs:go') ||
        eName.includes('team fortress')
    ) {
        return { type: 'icon', icon: faGamepad, color: '#ab8bfa' };
    }

    // 6. Voice (Teamspeak, Mumble)
    if (nestId === 3 || nName.includes('voice')) {
        return { type: 'icon', icon: faServer, color: '#ab8bfa' };
    }

    // Default: BABA HOST Cube Logo
    return { type: 'image', src: '/assets/baba_cube_logo.png' };
};

const ServerIcon: React.FC<Props> = ({
    nestId,
    eggId,
    nestName,
    eggName,
    serverName,
    iconUrl,
    className = 'w-7 h-7 flex items-center justify-center',
    imageClassName = 'w-full h-full object-contain',
}) => {
    const res = getServerIcon({ nestId, eggId, nestName, eggName, serverName, iconUrl });

    if (res.type === 'image' && res.src) {
        return (
            <div className={className}>
                <img src={res.src} alt={'Server Icon'} className={imageClassName} />
            </div>
        );
    }

    return (
        <div className={className} style={{ color: res.color || '#ab8bfa' }}>
            <FontAwesomeIcon icon={res.icon || faCube} className={'text-sm'} />
        </div>
    );
};

export default React.memo(ServerIcon);
