import MinecraftEggChanger from './MinecraftEggChanger';
import getServer from '@/api/server/getServer';
import { ServerContext } from '@/state/server';
import { mutate } from 'swr';
import { installedSoftwareKey } from '@/components/runtime/useInstalledSoftware';
import React, { useEffect, useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faFeatherAlt, faLeaf, faCube, faLayerGroup, faDownload } from '@fortawesome/free-solid-svg-icons';
import http, { httpErrorToHuman } from '@/api/http';
import Can from '@/components/elements/Can';
import { useServer, apiBase, useData, FeatureGate, PageHeading, LoadError, Empty } from './shared';
const choices = [ { id: 'paper', name: 'Paper', tag: 'Java · Plugins', description: 'A performance-focused Minecraft Java server.', icon: faFeatherAlt }, { id: 'purpur', name: 'Purpur', tag: 'Java · Customizable', description: 'A configurable Minecraft server built on Paper.', icon: faLeaf }, { id: 'vanilla', name: 'Vanilla', tag: 'Java · Official', description: 'The original server from Mojang. Release builds.', icon: faCube }, { id: 'fabric', name: 'Fabric', tag: 'Java · Mods', description: 'A lightweight loader for Fabric server mods.', icon: faLayerGroup } ];
const SoftwarePanel = () => {
    const setServer = ServerContext.useStoreActions(actions => actions.server.setServer);
    const server = useServer(); const base = apiBase(server.id); const [software, setSoftware] = useState('paper'); const [version, setVersion] = useState(''); const [pending, setPending] = useState(false); const [message, setMessage] = useState(''); const [failure, setFailure] = useState('');
    const { data, error } = useData<{ versions: string[] }>(`${base}/software/versions?software=${software}`);
    useEffect(() => { setVersion(''); setMessage(''); setFailure(''); }, [software]);
    const download = () => { if (!version || pending) return; if (!window.confirm(`Install ${software} ${version} as /server.jar? The server must be stopped. Any existing server.jar will be backed up.`)) return; setPending(true); setFailure(''); setMessage(''); http.post(`${base}/software/download`, { software, version }, { timeout: 240000 }).then(async ({ data }) => { setMessage(`Installed ${software} ${data.version} at /server.jar. Startup now uses server.jar.${data.backup ? ` Previous jar backup: ${data.backup}.` : ''} Start the server to run this version.`); const [updated] = await getServer(server.id); setServer(updated); await mutate(installedSoftwareKey(server.id)); window.dispatchEvent(new Event('minecraft-software-installed')); }).catch((e) => setFailure(httpErrorToHuman(e))).finally(() => setPending(false)); };

    return <div className={'mc-page'}><PageHeading title={'Software'} description={'Download server software directly into this server.'} /><div className={'mc-software-grid'}>{choices.map((c) => <button key={c.id} className={`bh-panel mc-software-card ${software === c.id ? 'selected' : ''}`} onClick={() => setSoftware(c.id)} disabled={pending}><div className={'mc-software-icon'}><FontAwesomeIcon icon={c.icon} /></div><span className={'mc-chip'}>{c.tag}</span><h2>{c.name}</h2><p>{c.description}</p><span className={'mc-select-label'}>{software === c.id ? 'Selected' : 'Choose software'}</span></button>)}</div>
        <section className={'bh-panel mc-download-panel'}><div><h2>{choices.find((s) => s.id === software)?.name} download</h2><p>Stop your server, then choose a Minecraft version. Installs to /server.jar and updates the startup jar automatically.</p></div><LoadError error={error} />{!data && !error ? <Empty>Loading official versions…</Empty> : <div className={'mc-download-controls'}><label>Minecraft version<select value={version} onChange={(e) => setVersion(e.target.value)} disabled={pending}><option value={''}>Select a version</option>{data?.versions.map((v) => <option key={v} value={v}>{v}</option>)}</select></label><Can action={'file.create'}><button className={'bh-button bh-primary'} disabled={!version || pending} onClick={download}><FontAwesomeIcon icon={faDownload} />{pending ? 'Installing server.jar…' : 'Install software'}</button></Can></div>}<p className={'mc-notice'}>Switching Java server families may also require a matching Egg and Java version. Worlds and plugins are preserved. Existing server.jar is backed up before replacement.</p></section>
        {failure && <div className={'bh-error'} role={'alert'}>{failure}</div>}{message && <div className={'mc-success'} role={'status'}>{message}</div>}
        <MinecraftEggChanger />
    </div>;
};
export default () => <FeatureGate><SoftwarePanel /></FeatureGate>;
