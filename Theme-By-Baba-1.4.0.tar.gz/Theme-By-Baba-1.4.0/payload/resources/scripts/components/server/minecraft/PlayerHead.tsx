import React, { useEffect, useState } from 'react';
export default ({name,uuid,skinUrl}:{name:string;uuid:string|null;skinUrl?:string|null}) => {
 const [failed,setFailed]=useState(false);useEffect(()=>setFailed(false),[name,uuid,skinUrl]);
 const realSkin=skinUrl && /^https:\/\/textures\.minecraft\.net\/texture\/[a-f0-9]+$/i.test(skinUrl);
 if(realSkin&&!failed)return <span className={'mc-player-avatar mc-player-head mcu-real-head'} title={'Skin texture reported by the server'}><img src={skinUrl!} alt={`${name} actual skin head`} onError={()=>setFailed(true)}/><img src={skinUrl!} alt={''} aria-hidden className={'mcu-head-hat'}/></span>;
 const valid=uuid && /^[a-f0-9-]{32,36}$/i.test(uuid) && uuid.replace(/-/g,'')[12] !== '3';
 if(!valid||failed)return <span className={'mc-player-avatar mc-player-head mcu-unknown-head'} title={'Player skin is unavailable; no skin was invented'} aria-label={`${name}: skin unavailable`}>?</span>;
 return <span className={'mc-player-avatar mc-player-head'} title={'Minecraft account skin lookup'}><img src={`https://mc-heads.net/avatar/${encodeURIComponent(uuid!)}/64`} alt={`${name} Minecraft account head`} loading={'lazy'} referrerPolicy={'no-referrer'} onError={()=>setFailed(true)}/></span>;
};
