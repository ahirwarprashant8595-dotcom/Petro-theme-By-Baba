import React from 'react';
import { ServerContext } from '@/state/server';
import { minecraftFeatures } from '@/components/runtime/profile';
import http, { httpErrorToHuman } from '@/api/http';
import useSWR from 'swr';
export const useServer = () => ServerContext.useStoreState((s) => s.server.data!);
export const apiBase = (id: string) => `/api/client/servers/${id}/minecraft`;
export const useData = <T,>(url: string | null, refreshInterval = 0) => useSWR<T>(url, () => http.get(url!).then((r) => r.data), { refreshInterval, revalidateOnFocus: false });
export const FeatureGate = ({ plugins = false, options = false, mods = false, children }: { plugins?: boolean; options?: boolean; mods?: boolean; children: React.ReactNode }) => {
    const f = minecraftFeatures(useServer());
    return (mods ? f.mods : plugins ? f.plugins : options ? f.options : f.minecraft) ? <>{children}</> : <div className={'mc-empty'}><h2>Unavailable for this server</h2><p>{plugins ? 'Plugins are available only for Paper and Spigot Eggs.' : 'This page is available only for Minecraft servers.'}</p></div>;
};
export const PageHeading = ({ title, description, children }: { title: string; description: string; children?: React.ReactNode }) => <header className={'mc-heading'}><div><div className={'bh-eyebrow'}>Minecraft workspace</div><h1>{title}</h1><p>{description}</p></div>{children}</header>;
export const LoadError = ({ error }: { error: unknown }) => error ? <div role={'alert'} className={'bh-error'}>{httpErrorToHuman(error)}</div> : null;
export const Empty = ({ children }: { children: React.ReactNode }) => <div className={'mc-empty'}>{children}</div>;
export const label = (id: string) => id.replace(/^minecraft:/, '').replace(/_/g, ' ');
