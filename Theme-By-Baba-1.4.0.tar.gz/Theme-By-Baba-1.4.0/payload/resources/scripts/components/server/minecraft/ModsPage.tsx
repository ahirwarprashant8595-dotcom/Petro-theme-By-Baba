import React from 'react';import {FeatureGate} from './shared';import {PluginsPanel} from './PluginsPage';
export default ()=><FeatureGate mods><PluginsPanel mods/></FeatureGate>;
