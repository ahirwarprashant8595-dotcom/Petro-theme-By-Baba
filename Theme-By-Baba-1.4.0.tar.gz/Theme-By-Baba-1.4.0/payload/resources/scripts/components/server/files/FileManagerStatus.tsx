import React from 'react';
import { ServerContext } from '@/state/server';
import { bytesToString } from '@/lib/formatters';
import { uploadPercent } from './uploadProgress';
export const UploadRing = ({ percent }: { percent: number }) => <svg className={'bh-upload-ring'} viewBox={'0 0 36 36'} aria-hidden={'true'}><circle cx={18} cy={18} r={15} fill={'none'} stroke={'currentColor'} strokeWidth={3} opacity={0.2}/><circle cx={18} cy={18} r={15} fill={'none'} stroke={'currentColor'} strokeWidth={3} strokeLinecap={'round'} strokeDasharray={Math.PI * 30} strokeDashoffset={Math.PI * 30 * (1-percent/100)} transform={'rotate(-90 18 18)'}/></svg>;
export default () => {
    const uploads=ServerContext.useStoreState(state=>state.files.uploads);
    const cancel=ServerContext.useStoreActions(actions=>actions.files.cancelFileUpload);
    const entries=Object.entries(uploads);
    if (!entries.length) return null;
    const pending=entries.filter(([,file])=>!file.completed).length;
    return <section className={'bh-upload-panel'} aria-label={'File uploads'}><header><strong>{pending ? `Uploading ${pending} file${pending===1?'':'s'}` : 'Upload complete'}</strong><span aria-live={'polite'}>{pending ? 'Keep this page open until finished' : 'File list refreshed'}</span></header>{entries.map(([name,file])=>{
        const percent=uploadPercent(file.loaded,file.total,file.completed);
        const phase=file.completed ? 'Uploaded' : file.loaded>=file.total ? 'Processing on server…' : 'Uploading…';
        return <div className={'bh-upload-row'} key={name}><div role={'progressbar'} aria-label={`Upload ${name}`} aria-valuemin={0} aria-valuemax={100} aria-valuenow={percent} aria-valuetext={`${percent}% — ${phase}`}><UploadRing percent={percent}/></div><div className={'bh-upload-info'}><strong title={name}>{name}</strong><span>{phase} · {bytesToString(Math.min(file.loaded,file.total))} / {bytesToString(file.total)}</span></div><b>{percent}%</b>{!file.completed && <button type={'button'} onClick={()=>cancel(name)} aria-label={`Cancel upload ${name}`} title={'Cancel upload'}>×</button>}</div>;
    })}</section>;
};
