export const isFileDrop = (data: DataTransfer | null): boolean => !!data && (Array.from(data.types || []).some(type => type.toLowerCase() === 'files') || data.files?.length > 0);
export const installFileDrop = (target: Window, callbacks: { hover: (active: boolean) => void; files: (files: FileList) => void; folder: () => void }): (() => void) => {
    const capture = { capture: true };
    let depth = 0;
    const reset = () => { depth = 0; callbacks.hover(false); };
    const enter = (event: DragEvent) => { if (!isFileDrop(event.dataTransfer)) return; event.preventDefault(); depth++; callbacks.hover(true); };
    const over = (event: DragEvent) => { if (!isFileDrop(event.dataTransfer)) return; event.preventDefault(); if (event.dataTransfer) event.dataTransfer.dropEffect = 'copy'; callbacks.hover(true); };
    const leave = (event: DragEvent) => { if (!isFileDrop(event.dataTransfer)) return; event.preventDefault(); depth = Math.max(0, depth - 1); if (!depth) callbacks.hover(false); };
    const drop = (event: DragEvent) => {
        if (!isFileDrop(event.dataTransfer)) return;
        event.preventDefault(); event.stopPropagation(); reset();
        const transfer = event.dataTransfer!;
        const folder = Array.from(transfer.items || []).some(item => item.webkitGetAsEntry?.()?.isDirectory);
        if (folder) { callbacks.folder(); return; }
        if (transfer.files?.length) callbacks.files(transfer.files);
    };
    const key = (event: KeyboardEvent) => { if (event.key === 'Escape') reset(); };
    target.addEventListener('dragenter', enter, capture); target.addEventListener('dragover', over, capture); target.addEventListener('dragleave', leave, capture); target.addEventListener('drop', drop, capture); target.addEventListener('dragend', reset); target.addEventListener('blur', reset); target.addEventListener('keydown', key);
    return () => { target.removeEventListener('dragenter', enter, capture); target.removeEventListener('dragover', over, capture); target.removeEventListener('dragleave', leave, capture); target.removeEventListener('drop', drop, capture); target.removeEventListener('dragend', reset); target.removeEventListener('blur', reset); target.removeEventListener('keydown', key); };
};
