import React, { memo } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faFileAlt, faFileArchive, faFileImport, faFolder } from '@fortawesome/free-solid-svg-icons';
import { encodePathSegments } from '@/helpers';
import { format } from 'date-fns';
import { FileObject } from '@/api/server/files/loadDirectory';
import FileDropdownMenu from '@/components/server/files/FileDropdownMenu';
import { ServerContext } from '@/state/server';
import { NavLink, useRouteMatch } from 'react-router-dom';
import isEqual from 'react-fast-compare';
import { usePermissions } from '@/plugins/usePermissions';
import { join } from 'pathe';
import { bytesToString } from '@/lib/formatters';

const Clickable: React.FC<{ file: FileObject; className?: string }> = memo(({ file, children, className }) => {
    const [canRead] = usePermissions(['file.read']);
    const [canReadContents] = usePermissions(['file.read-content']);
    const directory = ServerContext.useStoreState((state) => state.files.directory);
    const match = useRouteMatch();

    if ((file.isFile && (!file.isEditable() || !canReadContents)) || (!file.isFile && !canRead)) {
        return <div className={className}>{children}</div>;
    }

    return (
        <NavLink
            className={className}
            to={`${match.url}${file.isFile ? '/edit' : ''}#${encodePathSegments(join(directory, file.name))}`}
        >
            {children}
        </NavLink>
    );
}, isEqual);

const FileObjectRow = ({ file }: { file: FileObject }) => {
    const isChecked = ServerContext.useStoreState((state) => state.files.selectedFiles.indexOf(file.name) >= 0);
    const appendSelectedFile = ServerContext.useStoreActions((actions) => actions.files.appendSelectedFile);
    const removeSelectedFile = ServerContext.useStoreActions((actions) => actions.files.removeSelectedFile);

    const modeStr = file.mode ? file.mode : file.isFile ? '-rw-r--r--' : 'drwxr-xr-x';
    const formattedDate = format(file.modifiedAt, 'MMM dd, yyyy HH:mm');

    return (
        <div
            className={'bh-file-row h-12 px-4 flex items-center hover:bg-[#161618]/80 transition-colors group select-none'}
            key={file.name}
            onContextMenu={(e) => {
                e.preventDefault();
                window.dispatchEvent(new CustomEvent(`pterodactyl:files:ctx:${file.key}`, { detail: { x: e.clientX, y: e.clientY } }));
            }}
        >
            {/* 1. Selection Checkbox */}
            <div className={'w-7 flex items-center justify-center flex-shrink-0'}>
                <input
                    type={'checkbox'}
                    name={'selectedFiles'}
                    value={file.name}
                    checked={isChecked}
                    onChange={(e) => {
                        if (e.currentTarget.checked) {
                            appendSelectedFile(file.name);
                        } else {
                            removeSelectedFile(file.name);
                        }
                    }}
                    className={'w-4 h-4 rounded bg-[#161618] border border-[#303034] text-[#7762ac] focus:ring-0 focus:ring-offset-0 cursor-pointer accent-[#7762ac]'}
                />
            </div>

            {/* 2. File / Folder details */}
            <Clickable file={file} className={'bh-file-clickable flex-1 flex items-center min-w-0 no-underline cursor-pointer'}>
                {/* Purple Folder or Gray File Icon */}
                <div className={'w-7 flex items-center justify-center flex-shrink-0 ml-1'}>
                    {file.isFile ? (
                        <FontAwesomeIcon
                            icon={file.isSymlink ? faFileImport : file.isArchiveType() ? faFileArchive : faFileAlt}
                            className={'text-sm text-[#a1a1aa]'}
                        />
                    ) : (
                        <FontAwesomeIcon icon={faFolder} className={'text-base text-[#ab8bfa]'} />
                    )}
                </div>

                {/* Name */}
                <span className={'bh-file-name flex-1 text-xs font-semibold text-[#fafafa] truncate ml-2.5 group-hover:text-white'}>
                    {file.name}
                </span>

                {/* Size */}
                <span className={'bh-file-size w-24 text-left text-xs text-[#a1a1aa] hidden sm:block truncate'}>
                    {file.isFile ? bytesToString(file.size) : '-'}
                </span>

                {/* Last Modified */}
                <span className={'bh-file-date w-40 text-left text-xs text-[#a1a1aa] hidden md:block truncate'}>
                    {formattedDate}
                </span>

                {/* Permissions */}
                <span className={'bh-file-mode w-28 text-left text-xs font-mono text-[#a1a1aa]/80 hidden lg:block truncate'}>
                    {modeStr}
                </span>
            </Clickable>

            {/* 3. Action Menu (...) */}
            <div className={'w-10 flex justify-end flex-shrink-0'}>
                <FileDropdownMenu file={file} />
            </div>
        </div>
    );
};

export default memo(FileObjectRow, (prevProps, nextProps) => {
    return isEqual(prevProps.file, nextProps.file);
});
