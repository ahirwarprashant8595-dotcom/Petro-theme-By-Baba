import { installFileDrop } from './fileDrop';
import { usePermissions } from '@/plugins/usePermissions';
import FileManagerStatus from '@/components/server/files/FileManagerStatus';
import FlashMessageRender from '@/components/FlashMessageRender';
import React, { useEffect, useRef, useState } from 'react';
import { httpErrorToHuman } from '@/api/http';
import Spinner from '@/components/elements/Spinner';
import FileObjectRow from '@/components/server/files/FileObjectRow';
import FileManagerBreadcrumbs from '@/components/server/files/FileManagerBreadcrumbs';
import { FileObject } from '@/api/server/files/loadDirectory';
import { NavLink, useLocation } from 'react-router-dom';
import Can from '@/components/elements/Can';
import { ServerError } from '@/components/elements/ScreenBlock';
import { ServerContext } from '@/state/server';
import useFileManagerSwr from '@/plugins/useFileManagerSwr';
import MassActionsBar from '@/components/server/files/MassActionsBar';
import { useStoreActions } from '@/state/hooks';
import ErrorBoundary from '@/components/elements/ErrorBoundary';
import { hashToPath } from '@/helpers';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
    faFolder,
    faFileAlt,
    faUpload,
    faPlus,
    faSearch,
    faChevronDown,
    faFolderPlus,
    faTimes,
} from '@fortawesome/free-solid-svg-icons';
import axios from 'axios';
import getFileUploadUrl from '@/api/server/files/getFileUploadUrl';
import { useFlashKey } from '@/plugins/useFlash';
import createDirectory from '@/api/server/files/createDirectory';
import { Dialog } from '@/components/elements/dialog';

const sortFiles = (files: FileObject[], searchFilter: string): FileObject[] => {
    let filtered = files;
    if (searchFilter.trim().length > 0) {
        filtered = files.filter((f) => f.name.toLowerCase().includes(searchFilter.toLowerCase()));
    }
    const sorted = [...filtered]
        .sort((a, b) => a.name.localeCompare(b.name))
        .sort((a, b) => (a.isFile === b.isFile ? 0 : a.isFile ? 1 : -1));
    return sorted;
};

export default () => {
    const id = ServerContext.useStoreState((state) => state.server.data!.id);
    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid);
    const { hash } = useLocation();
    const { data: files, error, mutate } = useFileManagerSwr();
    const directory = ServerContext.useStoreState((state) => state.files.directory);
    const activeUploads = ServerContext.useStoreState((state) => state.files.uploads);
    const clearFlashes = useStoreActions((actions) => actions.flashes.clearFlashes);
    const setDirectory = ServerContext.useStoreActions((actions) => actions.files.setDirectory);

    const setSelectedFiles = ServerContext.useStoreActions((actions) => actions.files.setSelectedFiles);
    const selectedFilesLength = ServerContext.useStoreState((state) => state.files.selectedFiles.length);

    const { completeFileUpload, removeFileUpload, pushFileUpload, setUploadProgress } = ServerContext.useStoreActions(
        (actions) => actions.files
    );
    const { addError, clearAndAddHttpError } = useFlashKey('files');

    const [searchFilter, setSearchFilter] = useState('');
    const [dropActive, setDropActive] = useState(false);
    const [canUpload] = usePermissions('file.create');
    const submitDrop = useRef<(files: FileList) => void>(() => undefined);
    const [createDropdownOpen, setCreateDropdownOpen] = useState(false);
    const [newDirModalOpen, setNewDirModalOpen] = useState(false);
    const [newDirName, setNewDirName] = useState('');
    const [isCreatingDir, setIsCreatingDir] = useState(false);
    const [dirError, setDirError] = useState('');

    const fileUploadInput = useRef<HTMLInputElement>(null);

    useEffect(() => {
        clearFlashes('files');
        setSelectedFiles([]);
        setDirectory(hashToPath(hash));
    }, [hash]);

    useEffect(() => {
        mutate();
    }, [directory]);

    const onSelectAllClick = (e: React.ChangeEvent<HTMLInputElement>) => {
        setSelectedFiles(e.currentTarget.checked ? files?.map((file) => file.name) || [] : []);
    };

    const handleFileUpload = (fileList: FileList) => {
        clearAndAddHttpError();
        const list = Array.from(fileList);
        if (!list.length) return;
        if (list.some((file) => activeUploads[file.name])) return addError('A file with the same name is already uploading. Wait for it to finish.', 'Upload in progress');
        setSearchFilter('');
        const tasks = list.map(async (file) => {
            const controller = new AbortController();
            pushFileUpload({ name: file.name, data: { abort: controller, loaded: 0, total: file.size } });
            try {
                const url = await getFileUploadUrl(uuid);
                if (controller.signal.aborted) return;
                const data = new FormData();
                data.append('files', file, file.name);
                await axios.post(url, data, {
                    signal: controller.signal,
                    params: { directory },
                    onUploadProgress: (event) => setUploadProgress({ name: file.name, loaded: Math.min(file.size, event.loaded) }),
                });
                await mutate();
                completeFileUpload(file.name);
                setTimeout(() => removeFileUpload(file.name), 2000);
            } catch (err) {
                removeFileUpload(file.name);
                if (!controller.signal.aborted) addError(`${file.name}: ${httpErrorToHuman(err)}`, 'Upload failed');
            }
        });
        Promise.all(tasks).then(() => mutate()).catch((err) => clearAndAddHttpError(err));
    };

    submitDrop.current = (files) => {
        if (!canUpload) { addError('You do not have permission to upload files.', 'Upload unavailable'); return; }
        handleFileUpload(files);
    };
    useEffect(() => installFileDrop(window, {
        hover: setDropActive,
        files: (files) => submitDrop.current(files),
        folder: () => addError('Please upload files or a ZIP archive instead of a folder.', 'Folder upload unavailable'),
    }), []);

    const handleCreateDirectory = (e: React.FormEvent) => {
        e.preventDefault();
        if (!newDirName.trim()) return;

        setIsCreatingDir(true);
        setDirError('');

        createDirectory(uuid, directory, newDirName.trim())
            .then(() => {
                setIsCreatingDir(false);
                setNewDirModalOpen(false);
                setNewDirName('');
                mutate();
            })
            .catch((err) => {
                setIsCreatingDir(false);
                setDirError(httpErrorToHuman(err));
            });
    };

    if (error) {
        return <ServerError message={httpErrorToHuman(error)} onRetry={() => mutate()} />;
    }

    const displayedFiles = files ? sortFiles(files, searchFilter) : [];
    const allSelected = files && files.length > 0 && selectedFilesLength === files.length;

    return (
        <div className={'bh-files-page w-full flex flex-col gap-4 select-none'}>
            {dropActive && <div className={'bh-file-drop-overlay'} role={'status'}><div><FontAwesomeIcon icon={faUpload} /><strong>{canUpload ? 'Drop files to upload' : 'Upload permission required'}</strong><span>{canUpload ? `Destination: /home/container${directory === '/' ? '/' : directory}` : 'Ask the server owner for file access.'}</span></div></div>}
            {/* Hidden File Input for Upload */}
            <input
                type={'file'}
                ref={fileUploadInput}
                className={'hidden'}
                multiple
                onChange={(e) => {
                    if (e.currentTarget.files && e.currentTarget.files.length > 0) {
                        handleFileUpload(e.currentTarget.files);
                        if (fileUploadInput.current) fileUploadInput.current.value = '';
                    }
                }}
            />

            {/* Custom New Directory Modal */}
            {newDirModalOpen && (
                <div className={'fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm'}>
                    <div className={'w-full max-w-md bg-[#161618] border border-[#303034] rounded-2xl p-5 shadow-2xl relative'}>
                        <div className={'flex items-center justify-between pb-3 border-b border-[#303034]'}>
                            <div className={'flex items-center gap-2'}>
                                <FontAwesomeIcon icon={faFolderPlus} className={'text-[#ab8bfa]'} />
                                <h3 className={'text-base font-bold text-white m-0'}>Create Directory</h3>
                            </div>
                            <button
                                type={'button'}
                                onClick={() => setNewDirModalOpen(false)}
                                className={'text-[#a1a1aa] hover:text-white bg-transparent border-0 cursor-pointer'}
                            >
                                <FontAwesomeIcon icon={faTimes} className={'text-sm'} />
                            </button>
                        </div>

                        <form onSubmit={handleCreateDirectory} className={'mt-4 flex flex-col gap-3'}>
                            {dirError && (
                                <div className={'p-2.5 rounded-lg bg-red-950/40 border border-red-500/30 text-xs text-red-300'}>
                                    {dirError}
                                </div>
                            )}

                            <div>
                                <label className={'block text-xs font-semibold text-[#a1a1aa] mb-1.5'}>
                                    Directory Name
                                </label>
                                <input
                                    type={'text'}
                                    autoFocus
                                    value={newDirName}
                                    onChange={(e) => setNewDirName(e.target.value)}
                                    placeholder={'e.g. plugins, config, backup'}
                                    className={'w-full h-10 px-3 rounded-xl bg-[#101012] border border-[#303034] text-white text-xs outline-none focus:border-[#7762ac] transition'}
                                />
                            </div>

                            <p className={'text-[11px] text-[#a1a1aa]/70 m-0'}>
                                Will be created in: <code className={'text-[#ab8bfa]'}>/home/container/{directory.replace(/^\/+/, '')}</code>
                            </p>

                            <div className={'flex items-center justify-end gap-2 mt-2 pt-3 border-t border-[#303034]'}>
                                <button
                                    type={'button'}
                                    onClick={() => setNewDirModalOpen(false)}
                                    className={'h-8 px-4 rounded-xl bg-transparent hover:bg-[#201a30] text-[#a1a1aa] hover:text-white text-xs font-medium border border-[#303034] transition cursor-pointer'}
                                >
                                    Cancel
                                </button>
                                <button
                                    type={'submit'}
                                    disabled={!newDirName.trim() || isCreatingDir}
                                    className={'h-8 px-4 rounded-xl bg-[#7762ac] hover:bg-[#ab8bfa] disabled:opacity-40 text-white text-xs font-semibold border-0 transition cursor-pointer shadow-md'}
                                >
                                    {isCreatingDir ? 'Creating...' : 'Create'}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            {/* 1. TOP HEADER ROW */}
            <div className={'flex flex-col sm:flex-row sm:items-center justify-between gap-3'}>
                {/* Title & Subtitle with Purple Folder Icon */}
                <div className={'flex items-center gap-3'}>
                    <div className={'w-10 h-10 rounded-xl bg-[#7762ac]/20 border border-[#7762ac]/30 flex items-center justify-center text-[#ab8bfa]'}>
                        <FontAwesomeIcon icon={faFolder} className={'text-lg'} />
                    </div>
                    <div>
                        <h1 className={'text-xl font-bold text-white tracking-tight leading-tight m-0'}>Files</h1>
                        <p className={'text-xs text-[#a1a1aa] mt-0.5 m-0'}>Manage your server files easily</p>
                    </div>
                </div>

                {/* Action Buttons: New File, Upload, + Create v */}
                <div className={'flex items-center gap-2 flex-wrap'}>
                    <Can action={'file.create'}>
                        {/* 1. New File Button */}
                        <NavLink
                            to={`/server/${id}/files/new${window.location.hash}`}
                            className={'h-8 px-3 rounded-xl bg-[#161618] hover:bg-[#211933] border border-[#303034] text-[#fafafa] text-xs font-medium flex items-center gap-1.5 transition no-underline shadow-sm'}
                        >
                            <FontAwesomeIcon icon={faFileAlt} className={'text-[11px] text-[#a1a1aa]'} />
                            <span>New File</span>
                        </NavLink>

                        {/* 2. Upload Button */}
                        <button
                            type={'button'}
                            onClick={() => fileUploadInput.current && fileUploadInput.current.click()}
                            className={'h-8 px-3 rounded-xl bg-[#161618] hover:bg-[#211933] border border-[#303034] text-[#fafafa] text-xs font-medium flex items-center gap-1.5 transition cursor-pointer shadow-sm'}
                        >
                            <FontAwesomeIcon icon={faUpload} className={'text-[11px] text-[#a1a1aa]'} />
                            <span>Upload</span>
                        </button>

                        {/* 3. + Create Dropdown */}
                        <div className={'relative'}>
                            <button
                                type={'button'}
                                onClick={() => setCreateDropdownOpen((p) => !p)}
                                className={'h-8 px-3.5 rounded-xl bg-[#7762ac] hover:bg-[#ab8bfa] text-white text-xs font-semibold flex items-center gap-1.5 transition border-0 cursor-pointer shadow-md'}
                            >
                                <FontAwesomeIcon icon={faPlus} className={'text-[10px]'} />
                                <span>Create</span>
                                <FontAwesomeIcon icon={faChevronDown} className={'text-[9px] ml-0.5'} />
                            </button>

                            {createDropdownOpen && (
                                <div className={'absolute right-0 top-full mt-1.5 w-40 bg-[#161618] border border-[#303034] rounded-xl shadow-2xl py-1.5 z-40'}>
                                    <button
                                        type={'button'}
                                        onClick={() => {
                                            setCreateDropdownOpen(false);
                                            setNewDirModalOpen(true);
                                        }}
                                        className={'w-full flex items-center gap-2 px-3 py-1.5 text-xs text-[#a1a1aa] hover:text-white hover:bg-[#211933] transition border-0 bg-transparent text-left cursor-pointer'}
                                    >
                                        <FontAwesomeIcon icon={faFolderPlus} className={'text-[11px] text-[#ab8bfa]'} />
                                        <span>New Folder</span>
                                    </button>

                                    <NavLink
                                        to={`/server/${id}/files/new${window.location.hash}`}
                                        className={'flex items-center gap-2 px-3 py-1.5 text-xs text-[#a1a1aa] hover:text-white hover:bg-[#211933] transition no-underline'}
                                        onClick={() => setCreateDropdownOpen(false)}
                                    >
                                        <FontAwesomeIcon icon={faFileAlt} className={'text-[11px] text-[#a1a1aa]'} />
                                        <span>New File</span>
                                    </NavLink>
                                </div>
                            )}
                        </div>
                    </Can>
                </div>
            </div>

            {/* 2. BREADCRUMBS & SEARCH IN FILES BAR */}
            <div className={'grid grid-cols-1 md:grid-cols-12 gap-3 items-center'}>
                {/* Breadcrumbs */}
                <div className={'md:col-span-8 h-10 px-3.5 rounded-xl bg-[#161618] border border-[#303034] flex items-center overflow-x-auto text-xs text-[#a1a1aa]'}>
                    <FileManagerBreadcrumbs />
                </div>

                {/* Search In Files */}
                <div className={'bh-unified-search md:col-span-4 h-10 px-3.5 rounded-xl bg-[#161618] border border-[#303034] flex items-center gap-2 focus-within:border-[#7762ac] transition'}>
                    <FontAwesomeIcon icon={faSearch} className={'text-xs text-[#a1a1aa]'} />
                    <input
                        type={'text'}
                        value={searchFilter}
                        onChange={(e) => setSearchFilter(e.target.value)}
                        placeholder={'Search in files...'}
                        className={'w-full bg-transparent border-0 outline-none text-xs text-[#fafafa] placeholder-[#a1a1aa]/60'}
                    />
                </div>
            </div>

            <FlashMessageRender byKey={'files'} />
            <FileManagerStatus />
            {/* 3. FILE LIST TABLE */}
            <div className={'bh-file-table bg-[#101012] border border-[#303034] rounded-2xl overflow-hidden shadow-lg'}>
                {/* Table Column Headers */}
                <div className={'bh-file-table-head h-10 px-4 flex items-center border-b border-[#303034] bg-[#161618]/70 text-xs font-semibold text-[#a1a1aa]'}>
                    {/* Select All Checkbox */}
                    <div className={'w-6 flex items-center justify-center flex-shrink-0'}>
                        <Can action={'file.create'}>
                            <input
                                type={'checkbox'}
                                checked={allSelected}
                                onChange={onSelectAllClick}
                                className={'w-4 h-4 rounded bg-[#161618] border border-[#303034] text-[#7762ac] focus:ring-0 focus:ring-offset-0 cursor-pointer accent-[#7762ac]'}
                            />
                        </Can>
                    </div>

                    {/* Spacer for File/Folder Icon */}
                    <div className={'w-6 flex-shrink-0 ml-1'} />

                    {/* Column Titles */}
                    <span className={'flex-1 text-left ml-2'}>Name</span>
                    <span className={'bh-file-size w-24 text-left hidden sm:block'}>Size</span>
                    <span className={'bh-file-date w-40 text-left hidden md:block'}>Last Modified</span>
                    <span className={'bh-file-mode w-28 text-left hidden lg:block'}>Permissions</span>
                    <span className={'w-10 text-right'}></span>
                </div>

                {/* Table Rows */}
                {!files ? (
                    <div className={'py-12 flex justify-center items-center'}>
                        <Spinner size={'large'} centered />
                    </div>
                ) : displayedFiles.length === 0 ? (
                    <div className={'py-12 text-center text-xs text-[#a1a1aa]'}>
                        {searchFilter ? 'No files match your search query.' : 'This directory seems to be empty.'}
                    </div>
                ) : (
                    <div className={'divide-y divide-[#303034]/40'}>
                        {displayedFiles.map((file) => (
                            <FileObjectRow key={file.key} file={file} />
                        ))}
                    </div>
                )}
            </div>

            {/* Mass Actions Bar (sticky footer when items selected) */}
            <MassActionsBar />
        </div>
    );
};
