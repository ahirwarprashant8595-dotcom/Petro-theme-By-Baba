export const uploadPercent = (loaded: number, total: number, completed = false): number => {
    if (completed) return 100;
    if (!Number.isFinite(loaded) || !Number.isFinite(total) || total <= 0) return 0;
    return Math.max(0, Math.min(99, Math.floor((loaded / total) * 100)));
};
