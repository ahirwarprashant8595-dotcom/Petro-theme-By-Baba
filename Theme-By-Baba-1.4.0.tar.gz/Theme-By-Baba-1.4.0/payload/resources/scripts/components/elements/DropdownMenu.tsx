import React, { createRef } from 'react';
import { createPortal } from 'react-dom';
import styled from 'styled-components/macro';
import tw from 'twin.macro';
interface Props { children: React.ReactNode; renderToggle: (onClick: (e: React.MouseEvent<any, MouseEvent>) => void) => React.ReactChild; }
export const DropdownButtonRow = styled.button<{ danger?: boolean }>`
    ${tw`p-2 flex items-center rounded w-full text-neutral-200`};
    transition: 150ms background-color ease;
    &:hover { ${(props) => props.danger ? tw`text-red-300 bg-red-900` : tw`text-neutral-100 bg-neutral-700`}; }
`;
interface State { posX: number; posY: number; visible: boolean; }
class DropdownMenu extends React.PureComponent<Props, State> {
    menu = createRef<HTMLDivElement>(); toggle = createRef<HTMLDivElement>();
    state: State = { posX: 0, posY: 0, visible: false };
    componentWillUnmount() { this.removeListeners(); }
    componentDidUpdate(_props: Readonly<Props>, before: Readonly<State>) {
        if (this.state.visible && !before.visible) {
            this.position(); document.addEventListener('mousedown', this.outside, true); document.addEventListener('contextmenu', this.outside, true); document.addEventListener('keydown', this.keyboard); window.addEventListener('resize', this.close); window.addEventListener('scroll', this.scrolled, true);
        } else if (!this.state.visible && before.visible) this.removeListeners();
    }
    position = () => { const menu = this.menu.current; if (!menu) return; const width = menu.getBoundingClientRect().width; const height = menu.getBoundingClientRect().height; const left = Math.max(8, Math.min(this.state.posX - width, window.innerWidth - width - 8)); const top = this.state.posY + 6 + height > window.innerHeight - 8 ? Math.max(8, this.state.posY - height - 6) : this.state.posY + 6; menu.style.left = `${Math.round(left)}px`; menu.style.top = `${Math.round(top)}px`; };
    removeListeners = () => { document.removeEventListener('mousedown', this.outside, true); document.removeEventListener('contextmenu', this.outside, true); document.removeEventListener('keydown', this.keyboard); window.removeEventListener('resize', this.close); window.removeEventListener('scroll', this.scrolled, true); };
    close = () => this.setState({ visible: false });
    outside = (e: MouseEvent) => { if (!this.menu.current?.contains(e.target as Node) && !this.toggle.current?.contains(e.target as Node)) this.close(); };
    scrolled = (e: Event) => { if (!this.menu.current?.contains(e.target as Node)) this.close(); };
    keyboard = (e: KeyboardEvent) => { if (e.key === 'Escape') { this.close(); this.toggle.current?.querySelector('button')?.focus(); } };
    triggerMenu = (posX: number, posY?: number) => { const rect = this.toggle.current?.getBoundingClientRect(); this.setState((s) => ({ posX: posX || rect?.right || 8, posY: posY ?? rect?.bottom ?? 8, visible: !s.visible })); };
    onClickHandler = (e: React.MouseEvent<any, MouseEvent>) => { e.preventDefault(); e.stopPropagation(); this.triggerMenu(e.clientX, this.toggle.current?.getBoundingClientRect().bottom); };
    render() { return <div ref={this.toggle}>{this.props.renderToggle(this.onClickHandler)}{this.state.visible && typeof document !== 'undefined' && createPortal(<div className={'bh-dropdown-menu'} ref={this.menu} onClick={(e) => { e.stopPropagation(); this.close(); }} style={{ position: 'fixed', left: this.state.posX, top: this.state.posY, width: 192, maxWidth: 'calc(100vw - 16px)', maxHeight: 'calc(100dvh - 16px)' }}>{this.props.children}</div>, document.body)}</div>; }
}
export default DropdownMenu;
