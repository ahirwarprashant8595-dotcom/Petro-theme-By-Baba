import React, { useState } from 'react';
import { useStoreState } from 'easy-peasy';
export default function PersonalTheme() {
    const uuid = useStoreState((s) => s.user.data!.uuid);
    const key = `${uuid}:personal-panel-theme`;
    const base = typeof window === 'undefined' ? {} : (window as Window & {PanelTheme?: Record<string,string>}).PanelTheme || {};
    const defaults = {accent:base.accent || '#7f50f2',background:base.background || '#09090b',surface:base.surface || '#111113',sidebar:base.sidebar || '#0d0d10'};
    const [colours,setColours] = useState(() => {try{return {...defaults,...JSON.parse(localStorage.getItem(key)||'{}')};}catch{return defaults;}});
    const [message,setMessage] = useState('');
    const save = (reset=false) => {try {if(reset){localStorage.removeItem(key);setColours(defaults);}else localStorage.setItem(key,JSON.stringify(colours));window.dispatchEvent(new Event('baba-personal-theme'));setMessage(reset?'Panel default colours restored.':'Your colours are saved in this browser.');}catch{setMessage('Browser storage is unavailable.');}};
    return <section className={'bh-panel bh-customization-box'}><h3>My panel colours</h3><p>Personal colours for your account in this browser. Other users and the administrator theme are unaffected.</p>
        <div className={'bh-personal-colours'}>{(Object.keys(defaults) as (keyof typeof defaults)[]).map((key) => <label key={key}>{key}<input type={'color'} value={colours[key]} onChange={(e) => setColours({...colours,[key]:e.target.value})} /></label>)}</div>
        <button className={'bh-button bh-primary'} onClick={() => save()}>Save colours</button><button className={'bh-button'} onClick={() => save(true)}>Use panel defaults</button>{message && <p role={'status'}>{message}</p>}
    </section>;
}
