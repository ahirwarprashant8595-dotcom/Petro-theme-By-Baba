import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import AccountAvatar, { accountAvatarVariant } from '@/components/dashboard/AccountAvatar';
test('an account keeps its Steve/Alex assignment across sessions and renders', () => {
    const id = '17c2aacf-e048-4d29-bf6a-1a745dbdef56';
    expect(accountAvatarVariant(id)).toBe(accountAvatarVariant(id));
    expect(renderToStaticMarkup(<AccountAvatar accountId={id} username={'baba'} />)).toBe(renderToStaticMarkup(<AccountAvatar accountId={id} username={'renamed'} />).replace('>R<', '>B<'));
});
test('account IDs distribute between Steve and Alex', () => {
    const choices = new Set(Array.from({ length: 64 }, (_, i) => accountAvatarVariant('account-' + i)));
    expect(choices).toEqual(new Set(['steve', 'alex']));
});
test('avatar uses local face and overlay layers instead of the old clipped image', () => {
    const html = renderToStaticMarkup(<AccountAvatar accountId={'account-1'} username={'baba'} />);
    if (process.env.PANEL_AVATAR_PREVIEW) {
        const fs = require('fs');
        const css = fs.readFileSync('resources/scripts/assets/matte.css', 'utf8') + fs.readFileSync('resources/scripts/assets/workspace-fixes.css', 'utf8');
        const id = (kind: string) => Array.from({ length: 64 }, (_, i) => 'account-' + i).find((x) => accountAvatarVariant(x) === kind)!;
        const sample = renderToStaticMarkup(<div className={'bh-app'}><header className={'bh-topbar'}><div style={{ display: 'flex', alignItems: 'center', gap: 22 }}>{['steve', 'alex'].map((kind) => <div key={kind} style={{ display: 'flex', alignItems: 'center', gap: 9 }}><AccountAvatar accountId={id(kind)} username={kind} /><span style={{ color: '#e1d6ec', fontSize: 12 }}>{kind === 'steve' ? 'Steve account' : 'Alex account'}</span></div>)}</div><button className={'bh-button bh-primary'}>Purple #9E00FE</button></header></div>);
        fs.writeFileSync('/tmp/panel-avatar-preview.html', '<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>Avatar preview</title><style>*{box-sizing:border-box}body{margin:0}' + css + '</style></head><body>' + sample + '</body></html>');
    }
    expect(html).toContain('/assets/avatars/'); expect(html).toContain('bh-account-face'); expect(html).toContain('bh-account-hat'); expect(html).not.toContain('header_user_avatar.png');
});
