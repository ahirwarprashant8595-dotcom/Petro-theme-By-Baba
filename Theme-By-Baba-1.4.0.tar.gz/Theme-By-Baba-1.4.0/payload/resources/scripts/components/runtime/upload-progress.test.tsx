import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { createStore } from 'easy-peasy';
import files from '@/state/server/files';
import FileManagerStatus from '@/components/server/files/FileManagerStatus';
import { uploadPercent } from '@/components/server/files/uploadProgress';
let mockUploads: any = {};
jest.mock('@/state/server', () => ({ ServerContext: { useStoreState: (selector: any) => selector({files:{uploads:mockUploads}}), useStoreActions: () => jest.fn() } }));
test('progress handles empty files, clamps multipart bytes and waits for server acknowledgment',()=>{
 expect(uploadPercent(0,0)).toBe(0);expect(uploadPercent(30,100)).toBe(30);expect(uploadPercent(150,100)).toBe(99);expect(uploadPercent(0,0,true)).toBe(100);expect(uploadPercent(NaN,100)).toBe(0);
});
test('upload status exposes filename, progress and cancellation while processing',()=>{
 mockUploads={'world.zip':{loaded:100,total:100,abort:new AbortController()}};
 const html=renderToStaticMarkup(<FileManagerStatus/>);expect(html).toContain('world.zip');expect(html).toContain('aria-valuenow="99"');expect(html).toContain('Processing on server');expect(html).toContain('Cancel upload world.zip');
 mockUploads['world.zip'].completed=true;const complete=renderToStaticMarkup(<FileManagerStatus/>);expect(complete).toContain('aria-valuenow="100"');expect(complete).toContain('Uploaded');expect(complete).not.toContain('Cancel upload world.zip');
});
test('cancelling one upload preserves other uploads and completion state',()=>{
 const store=createStore({files});const a=new AbortController(),b=new AbortController();
 store.getActions().files.pushFileUpload({name:'a',data:{loaded:0,total:10,abort:a}});store.getActions().files.pushFileUpload({name:'b',data:{loaded:5,total:20,abort:b}});
 store.getActions().files.cancelFileUpload('a');expect(a.signal.aborted).toBe(true);expect(b.signal.aborted).toBe(false);expect(store.getState().files.uploads.b.loaded).toBe(5);
 store.getActions().files.completeFileUpload('b');expect(store.getState().files.uploads.b.completed).toBe(true);expect(store.getState().files.uploads.b.loaded).toBe(20);
});
