import fs from 'fs';
import path from 'path';
import ts from 'typescript';

it('mounts the theme state consumer inside the application StoreProvider', () => {
    const source = ts.createSourceFile('App.tsx', fs.readFileSync(path.join(process.cwd(), 'resources/scripts/components/App.tsx'), 'utf8'), ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
    let themes = 0;
    const visit = (node: ts.Node, insideStore: boolean) => {
        const inProvider = insideStore || (ts.isJsxElement(node) && node.openingElement.tagName.getText(source) === 'StoreProvider');
        if (ts.isJsxSelfClosingElement(node) && node.tagName.getText(source) === 'ThemeRuntime') {
            themes++;
            expect(inProvider).toBe(true);
        }
        node.forEachChild(child => visit(child, inProvider));
    };
    visit(source, false);
    expect(themes).toBe(1);
});

it('renders ThemeRuntime with the real application store context', () => {
    const React = require('react');
    const { renderToStaticMarkup } = require('react-dom/server');
    const { createStore, StoreProvider } = require('easy-peasy');
    const ThemeRuntime = require('@/components/theme/PanelTheme').default;
    const store = createStore({ user: { data: { uuid: 'provider-regression-check' } } });
    const html = renderToStaticMarkup(React.createElement(StoreProvider, { store }, React.createElement(ThemeRuntime)));
    expect(html).toContain('Open navigation');
});
