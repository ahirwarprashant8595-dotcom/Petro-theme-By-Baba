import React from 'react';import {renderToStaticMarkup} from 'react-dom/server';import {PlayerControls,BridgeNotice} from '@/components/server/minecraft/PlayerWidgets';
let mockLive=true;
jest.mock('@/components/server/minecraft/shared',()=>({useServer:()=>({id:'test',uuid:'test'}),apiBase:()=>'/test',useData:()=>({data:{live:mockLive,state:{worlds:[]}}}),LoadError:()=>null}));
jest.mock('@/components/elements/Can',()=>({__esModule:true,default:({children}:any)=><>{children}</>}));
jest.mock('@/plugins/usePermissions',()=>({usePermissions:()=>[true]}));
jest.mock('@/components/elements/dialog',()=>({Dialog:Object.assign(()=>null,{Confirm:()=>null})}));
test('known offline players retain moderation controls while the bridge is running',()=>{mockLive=true;const html=renderToStaticMarkup(<PlayerControls uuid={'700f1910-e032-324a-81dc-df1cc582a849'} detail={{live:false,operator:false,whitelisted:true,banned:true}} onUpdated={()=>undefined}/>);expect(html).toContain('Access &amp; moderation');expect(html).toContain('banned');expect(html).not.toContain('<h3>Player controls</h3>');});
test('offline controls are unavailable when there is no live bridge',()=>{mockLive=false;const html=renderToStaticMarkup(<PlayerControls uuid={'700f1910-e032-324a-81dc-df1cc582a849'} detail={{live:false}} onUpdated={()=>undefined}/>);expect(html).not.toContain('Access &amp; moderation');});

test('connected bridge does not show an operational status banner',()=>{mockLive=true;expect(renderToStaticMarkup(<BridgeNotice/>)).toBe('');});
test('bridge installation help remains available when disconnected',()=>{mockLive=false;expect(renderToStaticMarkup(<BridgeNotice/>)).toContain('Live player integration');});
