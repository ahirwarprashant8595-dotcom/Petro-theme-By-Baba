import { useEffect } from 'react';
import useSWR from 'swr';
import http from '@/api/http';
import { InstalledSoftware } from '@/api/server/getServer';
import { ServerContext } from '@/state/server';
export const installedSoftwareKey = (id: string) => `/api/client/servers/${id}/minecraft/software/status`;
export default (id: string, enabled: boolean) => {
 const setServer=ServerContext.useStoreActions(actions=>actions.server.setServerFromState);
 const {data}=useSWR<{installed: InstalledSoftware|null;running:{available:boolean;version?:string}|null}>(enabled ? installedSoftwareKey(id) : null,()=>http.get(installedSoftwareKey(id)).then(r=>r.data),{refreshInterval:5000,revalidateOnFocus:true});
 useEffect(()=>{if(data)setServer(s=>s.id===id && JSON.stringify(s.installedSoftware)!==JSON.stringify(data.installed) ? {...s,installedSoftware:data.installed} : s);},[data,id]);
 return data;
};
