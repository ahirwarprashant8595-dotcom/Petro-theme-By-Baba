import { installFileDrop } from '@/components/server/files/fileDrop';
const event = (type: string, data: any) => { const e=new Event(type,{cancelable:true,bubbles:true}); Object.defineProperty(e,'dataTransfer',{value:data});return e; };
test('PC file drop prevents browser navigation and hands files to uploader once',()=>{
 const target=new EventTarget(),files={0:{name:'paper.jar',type:'',size:50000000},length:1};const onFiles=jest.fn(),hover=jest.fn();const cleanup=installFileDrop(target as Window,{files:onFiles,hover,folder:jest.fn()});const data={types:['Files'],files,items:[],dropEffect:''};
 const over=event('dragover',data);target.dispatchEvent(over);expect(over.defaultPrevented).toBe(true);expect(data.dropEffect).toBe('copy');
 const drop=event('drop',data);target.dispatchEvent(drop);expect(drop.defaultPrevented).toBe(true);expect(onFiles).toHaveBeenCalledTimes(1);expect(onFiles).toHaveBeenCalledWith(files);expect(hover).toHaveBeenLastCalledWith(false);
 cleanup();target.dispatchEvent(event('drop',data));expect(onFiles).toHaveBeenCalledTimes(1);
});
test('folder drop is rejected visibly and ordinary text drags remain untouched',()=>{
 const target=new EventTarget(),files=jest.fn(),folder=jest.fn();const cleanup=installFileDrop(target as Window,{files,folder,hover:jest.fn()});const drop=event('drop',{types:['Files'],files:{length:0},items:[{webkitGetAsEntry:()=>({isDirectory:true})}]});target.dispatchEvent(drop);expect(drop.defaultPrevented).toBe(true);expect(folder).toHaveBeenCalledTimes(1);expect(files).not.toHaveBeenCalled();const text=event('drop',{types:['text/plain'],files:{length:0}});target.dispatchEvent(text);expect(text.defaultPrevented).toBe(false);cleanup();
});
