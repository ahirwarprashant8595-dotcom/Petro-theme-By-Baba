import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCube, faServer } from '@fortawesome/free-solid-svg-icons';
export default ({ kind, src, size = 40 }: { kind: string; src?: string | null; size?: number }) => (
    <span className={`runtime-icon runtime-${kind}`} style={{ width: size, height: size }}>
        {kind === 'python' ? <span>Py</span> : kind === 'node' ? <span>JS</span> : <FontAwesomeIcon icon={kind === 'minecraft' ? faCube : faServer} />}
        {src && <img src={src} alt={kind} onError={(e) => { e.currentTarget.style.display = 'none'; }} />}
    </span>
);
