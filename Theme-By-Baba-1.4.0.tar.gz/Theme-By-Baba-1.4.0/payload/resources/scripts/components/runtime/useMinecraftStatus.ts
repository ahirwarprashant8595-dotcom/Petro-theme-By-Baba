import useSWR from 'swr';
import getServerResourceUsage from '@/api/server/getServerResourceUsage';
export default (id: string, minecraft: boolean) => {
    const { data } = useSWR(minecraft ? ['minecraft-status', id] : null, () => getServerResourceUsage(id), { refreshInterval: 5000, revalidateOnFocus: false });
    return data?.minecraft || null;
};
