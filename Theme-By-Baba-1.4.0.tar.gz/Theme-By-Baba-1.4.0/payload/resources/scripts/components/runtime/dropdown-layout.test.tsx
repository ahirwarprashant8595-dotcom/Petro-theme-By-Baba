import React from 'react';
import DropdownMenu from '@/components/elements/DropdownMenu';
jest.mock('twin.macro', () => ({ __esModule: true, default: () => [] }));
jest.mock('styled-components/macro', () => ({ __esModule: true, default: { button: () => () => null } }));
const makeMenu = (x: number, y: number, width = 192, height = 230) => {
    const instance = new DropdownMenu({ renderToggle: () => <button />, children: null });
    instance.state = { posX: x, posY: y, visible: true };
    const style: any = {};
    (instance.menu as any).current = { style, getBoundingClientRect: () => ({ width, height }), contains: () => false };
    return { instance, style };
};
test('file action menus stay within the viewport near every edge', () => {
    (global as any).window = { innerWidth: 1360, innerHeight: 650 };
    for (const [x, y] of [[1355, 640], [5, 3], [500, 300], [2, 640]]) {
        const { instance, style } = makeMenu(x, y); instance.position();
        expect(parseInt(style.left)).toBeGreaterThanOrEqual(8); expect(parseInt(style.left) + 192).toBeLessThanOrEqual(1352);
        expect(parseInt(style.top)).toBeGreaterThanOrEqual(8); expect(parseInt(style.top) + 230).toBeLessThanOrEqual(642);
    }
    delete (global as any).window;
});
test('Escape closes the file menu and returns focus to its toggle', () => {
    const { instance } = makeMenu(200, 100); const focus = jest.fn(); instance.close = jest.fn();
    (instance.toggle as any).current = { querySelector: () => ({ focus }) };
    instance.keyboard({ key: 'Escape' } as KeyboardEvent); expect(instance.close).toHaveBeenCalled(); expect(focus).toHaveBeenCalled();
});
