import { Server } from '@/api/server/getServer';

export const runtimeProfile = (server: Pick<Server, 'eggName' | 'nestName' | 'dockerImage' | 'variables' | 'installedSoftware'>) => {
    const installed = server.installedSoftware;
    const egg = installed ? ({ paper: 'Paper', purpur: 'Purpur', vanilla: 'Vanilla', fabric: 'Fabric' } as Record<string,string>)[installed.software] || installed.software : server.eggName || 'Server';
    const identity = `${server.nestName || ''} ${egg}`.toLowerCase();
    const image = server.dockerImage || '';
    const minecraft = /minecraft|paper|spigot|bungeecord|waterfall|velocity|purpur|fabric|forge|bedrock/.test(identity);
    const python = !minecraft && /python/.test(`${identity} ${image}`);
    const node = !minecraft && !python && /nodejs|node\.js|node[_:-]?\d|node_|javascript|typescript/.test(`${identity} ${image}`);
    const kind = minecraft ? 'minecraft' : python ? 'python' : node ? 'node' : 'server';
    const runtime = minecraft ? 'Minecraft' : python ? 'Python' : node ? 'Node.js' : egg;
    const imageVersion = image.match(/(?:python|nodejs|node|java)[_:-](\d+(?:\.\d+){0,2})/i)?.[1];
    const versionVar = server.variables.find((v) => /^(MINECRAFT_VERSION|MC_VERSION|SERVER_VERSION|PAPER_VERSION|BUNGEE_VERSION|VELOCITY_VERSION|PYTHON_VERSION|NODE_VERSION)$/.test(v.envVariable));
    const configured = versionVar?.serverValue || versionVar?.defaultValue;
    const version = installed?.version || (configured && /^\d+(?:\.\d+){0,3}$/.test(configured) ? configured : undefined);
    const runtimeLabel = minecraft ? (imageVersion ? `Java ${imageVersion}` : runtime) : imageVersion ? `${runtime} ${imageVersion}` : runtime;
    return { kind, minecraft, runtime, runtimeLabel, egg, version, label: minecraft ? `${egg}${version ? ` ${version}` : ''}` : runtimeLabel };
};

export const minecraftFeatures = (server: Pick<Server, 'eggName' | 'nestName' | 'dockerImage' | 'variables' | 'installedSoftware'>) => {
    const profile = runtimeProfile(server);
    const minecraft = profile.minecraft && !/python|nodejs|node_/i.test(server.dockerImage || '');
    const paper = minecraft && /\bpaper(?:mc)?\b/i.test(profile.egg || '');
    const spigot = minecraft && /\bspigot\b/i.test(profile.egg || '');
    const modLoader = minecraft ? /neoforge/i.test(profile.egg) ? 'neoforge' : /fabric/i.test(profile.egg) ? 'fabric' : /forge/i.test(profile.egg) ? 'forge' : null : null;
    return { mods: !!modLoader, modLoader, minecraft, options: minecraft && !/bungee|waterfall|velocity|bedrock/i.test(profile.egg || ''), plugins: paper || spigot, loader: paper ? 'paper' : spigot ? 'spigot' : null };
};
