import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { MemoryRouter } from 'react-router-dom';
import ServerRow from '@/components/dashboard/ServerRow';
import ServerConsole from '@/components/server/console/ServerConsoleContainer';
import { Server } from '@/api/server/getServer';

let mockServer: Server;
jest.mock('@/state/server', () => ({ ServerContext: {
    useStoreState: (selector: any) => selector({ server: { data: mockServer }, status: { value: 'running' }, socket: { connected: true, instance: null } }),
    useStoreActions: () => jest.fn(),
} }));
jest.mock('@/components/elements/Can', () => ({ __esModule: true, default: ({ children }: any) => <>{children}</> }));
jest.mock('@/plugins/useWebsocketEvent', () => ({ __esModule: true, default: jest.fn() }));
jest.mock('@/components/runtime/useMinecraftStatus', () => ({ __esModule: true, default: () => null }));
jest.mock('@/components/server/console/Console', () => ({ __esModule: true, default: () => <div>Console stream</div> }));
jest.mock('@/components/elements/dialog', () => ({ Dialog: { Confirm: () => null } }));
jest.mock('@feature/Features', () => ({ __esModule: true, default: () => null }));
const makeServer = (minecraft = false) => ({ id: 'test', name: 'Test service', eggName: minecraft ? 'Paper' : 'Python', nestName: minecraft ? 'Minecraft' : 'Discord Bots', dockerImage: minecraft ? 'ghcr.io/pterodactyl/yolks:java_25' : 'ghcr.io/parkervcp/yolks:python_3.11', variables: [], allocations: [], limits: { cpu: 100, memory: 1024, disk: 5120 }, node: 'Node 1', eggFeatures: [] } as unknown as Server);

test('Python card and console never render Minecraft labels or player counters', () => {
    mockServer = makeServer();
    const card = renderToStaticMarkup(<MemoryRouter><ServerRow server={mockServer} /></MemoryRouter>);
    const console = renderToStaticMarkup(<MemoryRouter><ServerConsole /></MemoryRouter>);
    for (const html of [card, console]) {
        expect(html).toContain('Python 3.11');
        expect(html).not.toMatch(/Players|Minecraft|Paper 1\.20\.4|TPS|3 \/ 20|0 \/ 70|1\.2 MB\/s/);
    }
});
test('Minecraft card and console show unavailable player data honestly', () => {
    mockServer = makeServer(true);
    const card = renderToStaticMarkup(<MemoryRouter><ServerRow server={mockServer} /></MemoryRouter>);
    const console = renderToStaticMarkup(<MemoryRouter><ServerConsole /></MemoryRouter>);
    expect(card).toContain('Players'); expect(console).toContain('Players');
    expect(console).toContain('Java 25');
    expect(console).toContain('Status query unavailable');
    expect(console).not.toMatch(/Paper 1\.20\.4|3 \/ 20|20\.0|1\.2 MB\/s/);
});

test('render neutral management layout for visual review', () => {
    if (!process.env.PANEL_UI_PREVIEW) return;
    mockServer = { ...makeServer(), name: 'Discord Auth Bot', bannerUrl: '/assets/egg-art-20261027/python-banner.png', iconUrl: '/assets/egg-art-20261027/python-icon.png' };
    const Sidebar = require('@/components/server/BABAHostServerSidebar').default;
    const fs = require('fs');
    const css = fs.readFileSync('resources/scripts/assets/matte.css', 'utf8') + fs.readFileSync('resources/scripts/assets/login-match.css', 'utf8').replace(/@import[^;]+;/g, '') + fs.readFileSync('resources/scripts/assets/cute-panel.css', 'utf8');
    const html = renderToStaticMarkup(<MemoryRouter initialEntries={['/server/preview']}><div className={'bh-app'} style={{ display: 'flex', minHeight: '100vh', background: '#0c0c0e' }}><Sidebar serverId={'preview'} /><div style={{ flex: 1, minWidth: 0 }}><header className={'bh-topbar'}><span style={{ color: '#92929b', fontSize: 12 }}>BABA HOST / Server management</span><span style={{ color: '#92929b', fontSize: 12 }}>baba</span></header><main className={'bh-main'}><ServerConsole /></main></div></div></MemoryRouter>);
    fs.writeFileSync('/tmp/panel-matte-preview.html', '<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>Server UI visual review</title><style>*{box-sizing:border-box}body{margin:0}a{text-decoration:none}svg.svg-inline--fa{height:1em;display:inline-block;vertical-align:-.125em}' + css + '</style></head><body>' + html + '</body></html>');
    const cards = renderToStaticMarkup(<MemoryRouter><div className={'bh-app'} style={{ minHeight: '100vh', padding: 30 }}><h1 style={{ color: '#fff', fontSize: 24, marginBottom: 24 }}>Your servers</h1><div className={'bh-server-grid'}><ServerRow server={mockServer} /><ServerRow server={{ ...mockServer, id: 'test-2', name: 'Python Workspace' }} /></div></div></MemoryRouter>);
    fs.writeFileSync('/tmp/panel-cards-preview.html', '<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>Server card review</title><style>*{box-sizing:border-box}body{margin:0}a{text-decoration:none}svg.svg-inline--fa{height:1em;display:inline-block;vertical-align:-.125em}' + css + '</style></head><body>' + cards + '</body></html>');
    expect(html).toContain('Python 3.11');
});

test('per-Egg banner and icon render with readable console/settings actions', () => {
    const server = { ...makeServer(), bannerUrl: '/assets/custom-python-banner.png', iconUrl: '/assets/custom-python-icon.png' };
    const html = renderToStaticMarkup(<MemoryRouter><ServerRow server={server} /></MemoryRouter>);
    expect(html).toContain('/assets/custom-python-banner.png');
    expect(html).toContain('/assets/custom-python-icon.png');
    expect(html).toContain('<span>Console</span>');
    expect(html).toContain('<span>Settings</span>');
    expect(html).not.toContain('minecraft_banner_new.png');
});
