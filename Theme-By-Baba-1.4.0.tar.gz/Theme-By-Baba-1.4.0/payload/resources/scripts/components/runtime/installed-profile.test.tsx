import React from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {runtimeProfile,minecraftFeatures} from './profile';
import PlayerHead from '@/components/server/minecraft/PlayerHead';
test('installed Paper overrides an old Bungeecord Egg label and capabilities',()=>{const server:any={eggName:'Bungeecord',nestName:'Minecraft',dockerImage:'yolks:java_25',variables:[],installedSoftware:{software:'paper',version:'26.1.2',path:'/server.jar'}};expect(runtimeProfile(server).label).toBe('Paper 26.1.2');expect(minecraftFeatures(server).plugins).toBe(true);expect(minecraftFeatures(server).options).toBe(true);});
test('player heads use online UUIDs and do not invent offline-mode skins',()=>{
 const online=renderToStaticMarkup(<PlayerHead name={'Player'} uuid={'069a79f4-44e9-4726-a5be-fca90e38aaf5'}/>);
 expect(online).toContain('mc-heads.net/avatar/069a79f4-44e9-4726-a5be-fca90e38aaf5/64');
 const offline=renderToStaticMarkup(<PlayerHead name={'Player'} uuid={'069a79f4-44e9-3726-a5be-fca90e38aaf5'}/>);
 expect(offline).toContain('skin unavailable');expect(offline).not.toContain('mc-heads.net');
 const actual=renderToStaticMarkup(<PlayerHead name={'Player'} uuid={null} skinUrl={'https://textures.minecraft.net/texture/abcdef123456'}/>);
 expect(actual).toContain('textures.minecraft.net/texture/abcdef123456');expect(actual).toContain('actual skin head');
 const invalid=renderToStaticMarkup(<PlayerHead name={'Player'} uuid={null} skinUrl={'https://example.invalid/skin.png'}/>);
 expect(invalid).not.toContain('example.invalid');
});
