import { runtimeProfile } from './profile';
const server = (eggName: string, nestName: string, dockerImage: string, variables: any[] = []) => ({ eggName, nestName, dockerImage, variables });
test('Python bot uses configured image version and never enables Minecraft metrics', () => {
    expect(runtimeProfile(server('Python', 'Discord Bots', 'ghcr.io/parkervcp/yolks:python_3.11'))).toMatchObject({ kind: 'python', minecraft: false, label: 'Python 3.11' });
});
test('Node runtime reads version from image', () => {
    expect(runtimeProfile(server('Node.js', 'Discord Bots', 'ghcr.io/parkervcp/yolks:nodejs_22'))).toMatchObject({ kind: 'node', minecraft: false, label: 'Node.js 22' });
});
test('Minecraft displays configured game version independently of Java version', () => {
    expect(runtimeProfile(server('Paper', 'Minecraft', 'ghcr.io/pterodactyl/yolks:java_25', [{ envVariable: 'MINECRAFT_VERSION', serverValue: '1.21.4' }]))).toMatchObject({ minecraft: true, label: 'Paper 1.21.4', runtimeLabel: 'Java 25' });
});
test('unknown game version is never replaced with a fabricated version', () => {
    expect(runtimeProfile(server('Paper', 'Minecraft', 'ghcr.io/pterodactyl/yolks:java_25', [{ envVariable: 'MINECRAFT_VERSION', serverValue: 'latest' }])).label).toBe('Paper');
});
test('non-Minecraft services do not inherit game metrics', () => {
    expect(runtimeProfile(server('Generic', 'Services', 'alpine:latest'))).toMatchObject({ minecraft: false, kind: 'server', label: 'Generic' });
});

test('plugin tools are restricted to Paper or Spigot, never other Minecraft Eggs', () => {
    const { minecraftFeatures } = require('./profile');
    for (const egg of ['Paper', 'Spigot']) expect(minecraftFeatures(server(egg, 'Minecraft', 'yolks:java_21'))).toMatchObject({ minecraft: true, plugins: true });
    for (const egg of ['Vanilla', 'Purpur', 'Fabric', 'Forge', 'Bungeecord', 'Velocity', 'Bedrock']) expect(minecraftFeatures(server(egg, 'Minecraft', 'yolks:java_21')).plugins).toBe(false);
    expect(minecraftFeatures(server('Python', 'Discord Bots', 'yolks:python_3.11'))).toMatchObject({ minecraft: false, plugins: false });
    expect(minecraftFeatures(server('Node.js', 'Discord Bots', 'yolks:nodejs_22'))).toMatchObject({ minecraft: false, plugins: false });
});

test('mod and modpack tools only appear for their actual mod loader', () => {
    const { minecraftFeatures } = require('./profile');
    for (const egg of ['Paper','Spigot','Vanilla','Bungeecord']) expect(minecraftFeatures(server(egg,'Minecraft','yolks:java_21')).mods).toBe(false);
    for (const [egg,loader] of [['Fabric','fabric'],['Forge Minecraft','forge'],['NeoForge','neoforge']]) expect(minecraftFeatures(server(egg,'Minecraft','yolks:java_21'))).toMatchObject({mods:true,modLoader:loader,plugins:false});
    expect(minecraftFeatures(server('Python','Discord Bots','yolks:python_3.11')).minecraft).toBe(false);
});
