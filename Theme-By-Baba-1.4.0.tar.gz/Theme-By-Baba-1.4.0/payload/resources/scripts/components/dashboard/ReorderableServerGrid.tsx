import React, { useEffect, useRef, useState } from 'react';
import { Server } from '@/api/server/getServer';
import ServerRow from './ServerRow';
import { moveCard, readOrder, sortCards } from './cardOrder';

export default function ReorderableServerGrid({ items, storageKey }: { items: Server[]; storageKey: string }) {
    const [order, setOrder] = useState<string[]>(() => {
        try { return readOrder(JSON.parse(localStorage.getItem(storageKey) || '[]')); } catch { return []; }
    });
    const dragging = useRef<string | null>(null);
    const preview = useRef<HTMLElement | null>(null);
    const offset = useRef({ x: 28, y: 28 });
    const removePreview = () => { preview.current?.remove(); preview.current = null; };
    useEffect(() => {
        const followPointer = (event: DragEvent) => {
            if (preview.current) preview.current.style.transform = `translate3d(${event.clientX - offset.current.x}px, ${event.clientY - offset.current.y}px, 0)`;
        };
        document.addEventListener('dragover', followPointer, true);
        document.addEventListener('dragend', removePreview, true);
        document.addEventListener('drop', removePreview, true);
        return () => {
            removePreview();
            document.removeEventListener('dragover', followPointer, true);
            document.removeEventListener('dragend', removePreview, true);
            document.removeEventListener('drop', removePreview, true);
        };
    }, []);
    const [target, setTarget] = useState<string | null>(null);
    const [announcement, setAnnouncement] = useState('');
    const sorted = sortCards(items, order);
    const reorder = (source: string, destination: string) => {
        const ids = moveCard(sorted.map((s) => s.uuid), source, destination);
        // Preserve ordering on other pagination pages too.
        const visible = new Set(ids);
        const next = [...ids, ...order.filter((id) => !visible.has(id))];
        setOrder(next);
        try { localStorage.setItem(storageKey, JSON.stringify(next)); } catch { /* Session ordering still works when storage is unavailable. */ }
        setAnnouncement('Server order updated.');
    };
    return <>
        <span className={'sr-only'} role={'status'} aria-live={'polite'}>{announcement}</span>
        <div className={'bh-server-grid'}>
            {sorted.map((server, index) => <ServerRow key={server.uuid} server={server}
                className={target === server.uuid ? 'bh-reorder-target' : ''}
                reorder={{
                    heading: {
                        draggable: true,
                        title: 'Drag to rearrange server cards',
                        onDragStart: (event) => {
                            if ((event.target as HTMLElement).closest('a,button')) { event.preventDefault(); return; }
                            dragging.current = server.uuid;
                            event.dataTransfer.effectAllowed = 'move';
                            event.dataTransfer.setData('application/x-baba-server', server.uuid);
                            event.dataTransfer.setData('text/plain', server.name);
                            removePreview();
                            const card = event.currentTarget.parentElement!;
                            const rect = card.getBoundingClientRect();
                            offset.current = { x: event.clientX - rect.left, y: event.clientY - rect.top };
                            const clone = card.cloneNode(true) as HTMLElement;
                            clone.classList.remove('bh-reorder-target');
                            clone.classList.add('bh-drag-preview');
                            clone.setAttribute('aria-hidden', 'true');
                            clone.removeAttribute('id');
                            clone.querySelectorAll('[id]').forEach((node) => node.removeAttribute('id'));
                            Object.assign(clone.style, {
                                position: 'fixed', left: '0', top: '0', width: `${rect.width}px`,
                                height: `${rect.height}px`, margin: '0', zIndex: '9999',
                                pointerEvents: 'none', transform: `translate3d(${rect.left}px, ${rect.top}px, 0)`,
                            });
                            card.closest('.bh-app')!.appendChild(clone);
                            preview.current = clone;
                            // Use our full-opacity preview rather than a browser-faded snapshot.
                            const empty = document.createElement('canvas');
                            empty.width = empty.height = 1;
                            event.dataTransfer.setDragImage(empty, 0, 0);
                        },
                        onDragEnd: () => { removePreview(); dragging.current = null; setTarget(null); },
                    },
                    article: {
                        onDragOver: (event) => {
                            if (!dragging.current) return;
                            event.preventDefault(); event.dataTransfer.dropEffect = 'move';
                            if (dragging.current !== server.uuid) setTarget(server.uuid);
                        },
                        onDrop: (event) => {
                            if (!dragging.current) return;
                            event.preventDefault();
                            reorder(dragging.current, server.uuid);
                            dragging.current = null; setTarget(null);
                        },
                    },
                    previous: index > 0 ? () => reorder(server.uuid, sorted[index - 1].uuid) : undefined,
                    next: index < sorted.length - 1 ? () => reorder(server.uuid, sorted[index + 1].uuid) : undefined,
                }} />)}
        </div>
    </>;
}
