import React, { memo, useEffect, useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPlay, faSyncAlt, faSquare, faCopy, faCheck, faTerminal, faCog, faEllipsisH, faUsers, faMicrochip, faMemory, faHdd } from '@fortawesome/free-solid-svg-icons';
import { Link } from 'react-router-dom';
import copy from 'copy-to-clipboard';
import { Server } from '@/api/server/getServer';
import getServerResourceUsage, { ServerStats } from '@/api/server/getServerResourceUsage';
import { bytesToString, ip, mbToBytes } from '@/lib/formatters';
import http, { httpErrorToHuman } from '@/api/http';
import { runtimeProfile } from '@/components/runtime/profile';
import RuntimeIcon from '@/components/runtime/RuntimeIcon';

interface CardReorder {
    heading: React.HTMLAttributes<HTMLDivElement>;
    article: React.HTMLAttributes<HTMLElement>;
    previous?: () => void;
    next?: () => void;
}
const ServerRow = ({ server, className = '', reorder }: { server: Server; className?: string; reorder?: CardReorder }) => {
    const [stats, setStats] = useState<ServerStats | null>(null);
    const [copied, setCopied] = useState(false);
    const [pending, setPending] = useState(false);
    const [error, setError] = useState('');
    const [unavailable, setUnavailable] = useState(false);
    const profile = runtimeProfile(server);
    const suspended = server.status === 'suspended' || stats?.isSuspended;
    useEffect(() => {
        if (suspended || server.isNodeUnderMaintenance) return;
        let cancelled = false;
        const load = () => getServerResourceUsage(server.id).then((s) => { if (!cancelled) { setStats(s); setUnavailable(false); } }).catch(() => { if (!cancelled) setUnavailable(true); });
        load(); const timer = setInterval(load, 30000);
        return () => { cancelled = true; clearInterval(timer); };
    }, [server.id, suspended, server.isNodeUnderMaintenance]);
    const allocation = server.allocations.find((a) => a.isDefault) || server.allocations[0];
    const address = allocation ? `${allocation.alias || ip(allocation.ip)}:${allocation.port}` : 'No allocation';
    const state = suspended ? 'suspended' : server.isNodeUnderMaintenance ? 'maintenance' : unavailable ? 'unavailable' : stats?.status || 'loading';
    const power = (signal: 'start' | 'restart' | 'stop') => {
        setPending(true); setError('');
        http.post(`/api/client/servers/${server.id}/power`, { signal }).then(() => getServerResourceUsage(server.id)).then(setStats).catch((e) => setError(httpErrorToHuman(e))).finally(() => setPending(false));
    };
    const disabled = !stats || suspended || server.isNodeUnderMaintenance || pending || unavailable;
    const copyAddress = () => { if (allocation && copy(address)) { setCopied(true); setTimeout(() => setCopied(false), 2000); } };
    const metric = (label: string, icon: any, value: string, percent: number) => <div className={'bh-card-metric'} title={label}><span><FontAwesomeIcon icon={icon} />{label}</span><strong>{value}</strong><div className={'bh-meter'}><i style={{ width: `${Math.min(100, Math.max(0, percent))}%` }} /></div></div>;
    const banner = server.bannerUrl || (profile.minecraft ? '/assets/eggs/minecraft_banner_new.png' : null);
    return <article {...reorder?.article} className={`bh-panel bh-server-card ${className}`}>
        <div {...reorder?.heading} className={`bh-card-heading ${banner ? 'bh-card-with-art' : ''}`}>
            {banner && <img draggable={false} className={'bh-card-art'} src={banner} alt={''} />}
            <div className={'bh-card-identity'}><RuntimeIcon kind={profile.kind} src={server.iconUrl || (profile.minecraft ? '/assets/eggs/minecraft_icon_new.png' : null)} /><div><Link className={'bh-card-name'} to={`/server/${server.id}`}>{server.name}</Link><span className={`bh-status bh-status-${state}`} title={profile.label}><i />{state === 'running' ? 'Online' : state.charAt(0).toUpperCase() + state.slice(1)}</span></div></div>

        </div>

        <div className={`bh-card-metrics ${profile.minecraft ? 'bh-card-minecraft' : ''}`}>
            {profile.minecraft && metric('Players', faUsers, stats?.minecraft?.available ? `${stats.minecraft.online} / ${stats.minecraft.max}` : '—', stats?.minecraft?.available && stats.minecraft.max ? (stats.minecraft.online || 0) / stats.minecraft.max * 100 : 0)}
            {metric('CPU', faMicrochip, stats ? `${stats.cpuUsagePercent.toFixed(1)}%` : '—', stats && server.limits.cpu ? stats.cpuUsagePercent / server.limits.cpu * 100 : 0)}
            {metric('Memory', faMemory, stats ? bytesToString(stats.memoryUsageInBytes) : '—', stats && server.limits.memory ? stats.memoryUsageInBytes / mbToBytes(server.limits.memory) * 100 : 0)}
            {metric('Storage', faHdd, stats ? bytesToString(stats.diskUsageInBytes) : '—', stats && server.limits.disk ? stats.diskUsageInBytes / mbToBytes(server.limits.disk) * 100 : 0)}
        </div>
        {error && <p className={'bh-error'} role={'alert'}>{error}</p>}
        <div className={'bh-card-power bh-card-compact-actions'}>
            <button className={'bh-button bh-primary'} disabled={!!disabled || state !== 'offline'} onClick={() => power('start')}><FontAwesomeIcon icon={faPlay} /><span>Start</span></button>
            <Link className={'bh-button'} to={`/server/${server.id}/settings`}><FontAwesomeIcon icon={faCog} /><span>Settings</span></Link>
            <details className={'bh-card-more'} onBlur={(e) => { if (!e.currentTarget.contains(e.relatedTarget as Node)) (e.currentTarget as HTMLDetailsElement).open = false; }} onKeyDown={(e) => { if (e.key === 'Escape') (e.currentTarget as HTMLDetailsElement).open = false; }}>
                <summary aria-label={'More server actions'} ><FontAwesomeIcon icon={faEllipsisH} /></summary>
                <div className={'bh-card-menu'}>
                    {reorder && <>
                        <button disabled={!reorder.previous} onClick={reorder.previous}>↑ Move earlier</button>
                        <button disabled={!reorder.next} onClick={reorder.next}>↓ Move later</button>
                    </>}
                    <Link to={`/server/${server.id}`}><FontAwesomeIcon icon={faTerminal} /><span>Console</span></Link>
                    <button disabled={!!disabled || !['running', 'starting'].includes(state)} onClick={() => power('restart')}><FontAwesomeIcon icon={faSyncAlt} />Restart</button>
                    <button disabled={!!disabled || !['running', 'starting'].includes(state)} onClick={() => power('stop')}><FontAwesomeIcon icon={faSquare} />Stop</button>
                    <button onClick={copyAddress} title={address}><FontAwesomeIcon icon={copied ? faCheck : faCopy} />{copied ? 'Copied' : 'Copy address'}</button>
                </div>
            </details>
        </div>
    </article>;
};
export default memo(ServerRow);
