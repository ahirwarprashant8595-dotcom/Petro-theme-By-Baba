import { ThemeBrand } from '@/components/theme/PanelTheme';
import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCogs, faLayerGroup, faSearch, faSignOutAlt, faUser } from '@fortawesome/free-solid-svg-icons';
import { useStoreState } from 'easy-peasy';
import { ApplicationStore } from '@/state';
import http from '@/api/http';
import SpinnerOverlay from '@/components/elements/SpinnerOverlay';
export default ({ onOpenSearch }: { onOpenSearch: () => void }) => {
    const rootAdmin = useStoreState((s: ApplicationStore) => s.user.data!.rootAdmin);
    const [loggingOut, setLoggingOut] = useState(false);
    const logout = () => { setLoggingOut(true); http.post('/auth/logout').finally(() => window.location.assign('/')); };
    return <aside className={'bh-sidebar'}><SpinnerOverlay visible={loggingOut} /><NavLink to={'/'} className={'bh-brand'} title={'BABA HOST'}><ThemeBrand /></NavLink><nav className={'bh-nav'} aria-label={'Workspace navigation'}>
        <NavLink to={'/'} exact className={'bh-nav-link'} activeClassName={'bh-nav-active'} title={'Dashboard'}><FontAwesomeIcon icon={faLayerGroup} /><span>Dashboard</span></NavLink>
        <NavLink to={'/account'} className={'bh-nav-link'} activeClassName={'bh-nav-active'} title={'Account'}><FontAwesomeIcon icon={faUser} /><span>Account</span></NavLink>
        {rootAdmin && <a href={'/admin'} className={'bh-nav-link'} title={'Administration'}><FontAwesomeIcon icon={faCogs} /><span>Admin</span></a>}
        <button className={'bh-nav-link'} onClick={onOpenSearch} title={'Search servers'}><FontAwesomeIcon icon={faSearch} /><span>Search</span></button>
    </nav><button className={'bh-back-dashboard'} onClick={logout} title={'Sign out'}><FontAwesomeIcon icon={faSignOutAlt} /><span>Sign out</span></button></aside>;
};
