import React from 'react';
// A UUID-seeded choice is stable across sessions/devices and distributes accounts
// between the two defaults without changing on every render.
export const accountAvatarVariant = (accountId: string): 'steve' | 'alex' => {
    let hash = 2166136261;
    for (let i = 0; i < accountId.length; i++) hash = Math.imul(hash ^ accountId.charCodeAt(i), 16777619);
    hash ^= hash >>> 16;
    return (hash >>> 0) % 2 === 0 ? 'steve' : 'alex';
};
export default ({ accountId, username }: { accountId: string; username: string }) => {
    const variant = accountAvatarVariant(accountId);
    const skin = { backgroundImage: `url('/assets/avatars/${variant}-skin.png')` };
    return <span className={`bh-account-avatar bh-avatar-${variant}`} data-avatar={variant} title={variant === 'steve' ? 'Steve' : 'Alex'} aria-hidden={'true'}>{username.slice(0, 1).toUpperCase()}<span className={'bh-account-face'} style={skin} /><span className={'bh-account-hat'} style={skin} /></span>;
};
