import React, { useEffect, useRef, useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCogs, faSearch, faSignOutAlt, faUser } from '@fortawesome/free-solid-svg-icons';
import { useStoreState } from 'easy-peasy';
import { ApplicationStore } from '@/state';
import { Link, useLocation } from 'react-router-dom';
import http from '@/api/http';
import SpinnerOverlay from '@/components/elements/SpinnerOverlay';
import AccountAvatar from './AccountAvatar';
export default ({ onOpenSearch }: { onOpenSearch: () => void }) => {
    const user = useStoreState((s: ApplicationStore) => s.user.data);
    const [open, setOpen] = useState(false); const [loggingOut, setLoggingOut] = useState(false); const ref = useRef<HTMLDivElement>(null); const location = useLocation();
    useEffect(() => { const outside = (e: MouseEvent) => { if (!ref.current?.contains(e.target as Node)) setOpen(false); }; document.addEventListener('mousedown', outside); return () => document.removeEventListener('mousedown', outside); }, []);
    useEffect(() => { setOpen(false); }, [location.pathname]);
    useEffect(() => { const shortcut = (e: KeyboardEvent) => { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); onOpenSearch(); } }; window.addEventListener('keydown', shortcut); return () => window.removeEventListener('keydown', shortcut); }, [onOpenSearch]);
    const logout = () => { setLoggingOut(true); http.post('/auth/logout').finally(() => window.location.assign('/')); };
    return <header className={'bh-topbar'}><SpinnerOverlay visible={loggingOut} /><button className={'bh-search-trigger'} onClick={onOpenSearch} aria-label={'Search servers'}><FontAwesomeIcon icon={faSearch} /><span>Search servers…</span><kbd>Ctrl K</kbd></button><div className={'bh-account-control'} ref={ref} onKeyDown={(e) => { if (e.key === 'Escape') setOpen(false); }}><button className={'bh-account-trigger'} aria-expanded={open} aria-label={'Account menu'} onClick={() => setOpen(!open)}><AccountAvatar accountId={user?.uuid || user?.username || 'guest'} username={user?.username || 'User'} /><span className={'bh-account-name'}><strong>{user?.username || 'User'}</strong><small>Account</small></span></button>{open && <div className={'bh-account-menu'}><div className={'bh-account-menu-heading'}><strong>{user?.username}</strong><span>{user?.email}</span></div><Link to={'/account'}><FontAwesomeIcon icon={faUser} />Account settings</Link>{user?.rootAdmin && <a href={'/admin'}><FontAwesomeIcon icon={faCogs} />Administration</a>}<button onClick={logout}><FontAwesomeIcon icon={faSignOutAlt} />Sign out</button></div>}</div></header>;
};
