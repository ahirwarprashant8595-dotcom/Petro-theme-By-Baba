export const readOrder = (value: unknown): string[] => Array.isArray(value) ? Array.from(new Set(value.filter((id): id is string => typeof id === 'string'))) : [];
export const sortCards = <T extends { uuid: string }>(items: T[], order: string[]): T[] => {
    const ranks = new Map(order.map((id, index) => [id, index]));
    return items.map((item, index) => ({ item, index })).sort((a, b) =>
        (ranks.get(a.item.uuid) ?? order.length + a.index) - (ranks.get(b.item.uuid) ?? order.length + b.index)
    ).map(({ item }) => item);
};
export const moveCard = (ids: string[], source: string, target: string): string[] => {
    if (source === target || !ids.includes(source) || !ids.includes(target)) return ids;
    const next = ids.filter((id) => id !== source);
    next.splice(ids.indexOf(target), 0, source);
    return next;
};
