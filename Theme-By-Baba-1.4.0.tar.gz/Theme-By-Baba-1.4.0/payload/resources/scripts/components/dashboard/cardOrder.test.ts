import { moveCard, readOrder, sortCards } from './cardOrder';
describe('dashboard card order', () => {
    it('moves in both directions without losing cards', () => {
        expect(moveCard(['a','b','c'], 'a', 'c')).toEqual(['b','c','a']);
        expect(moveCard(['a','b','c'], 'c', 'a')).toEqual(['c','a','b']);
        expect(moveCard(['a','b'], 'missing', 'b')).toEqual(['a','b']);
    });
    it('keeps new servers visible and ignores deleted servers in saved order', () => {
        const items = [{uuid:'new'}, {uuid:'a'}, {uuid:'b'}];
        expect(sortCards(items, ['deleted','b','a']).map(s => s.uuid)).toEqual(['b','a','new']);
        expect(items.map(s => s.uuid)).toEqual(['new','a','b']);
    });
    it('ignores malformed saved preferences and duplicate IDs', () => {
        expect(readOrder({a:1})).toEqual([]);
        expect(readOrder(['a',null,'a',2,'b'])).toEqual(['a','b']);
    });
});
