import React, { useEffect, useState } from 'react';
import { Server } from '@/api/server/getServer';
import getServers from '@/api/getServers';
import ReorderableServerGrid from '@/components/dashboard/ReorderableServerGrid';
import Spinner from '@/components/elements/Spinner';
import useFlash from '@/plugins/useFlash';
import { useStoreState } from 'easy-peasy';
import { usePersistedState } from '@/plugins/usePersistedState';
import useSWR from 'swr';
import { PaginatedResult } from '@/api/http';
import Pagination from '@/components/elements/Pagination';
import { useLocation } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPlus } from '@fortawesome/free-solid-svg-icons';

export default () => {
    const { search } = useLocation();
    const defaultPage = Number(new URLSearchParams(search).get('page') || '1');

    const [page, setPage] = useState(!isNaN(defaultPage) && defaultPage > 0 ? defaultPage : 1);
    const { clearFlashes, clearAndAddHttpError } = useFlash();
    const uuid = useStoreState((state) => state.user.data!.uuid);
    const rootAdmin = useStoreState((state) => state.user.data!.rootAdmin);
    const [showOnlyAdmin, setShowOnlyAdmin] = usePersistedState(`${uuid}:show_all_servers`, false);

    const { data: servers, error } = useSWR<PaginatedResult<Server>>(
        ['/api/client/servers', showOnlyAdmin && rootAdmin, page],
        () => getServers({ page, type: showOnlyAdmin && rootAdmin ? 'admin' : undefined })
    );

    useEffect(() => {
        setPage(1);
    }, [showOnlyAdmin]);

    useEffect(() => {
        if (!servers) return;
        if (servers.pagination.currentPage > 1 && !servers.items.length) {
            setPage(1);
        }
    }, [servers?.pagination.currentPage]);

    useEffect(() => {
        window.history.replaceState(null, document.title, `/${page <= 1 ? '' : `?page=${page}`}`);
    }, [page]);

    useEffect(() => {
        if (error) clearAndAddHttpError({ key: 'dashboard', error });
        if (!error) clearFlashes('dashboard');
    }, [error]);

    return (
        <div className={'bh-dashboard-page w-full select-none'}>
            {/* Header: Title + Subtitle + Toggle + Create Button */}
            <div className={'flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4'}>
                <div>
                    <h1 className={'text-[19px] font-bold text-[#f4f4f5] tracking-tight leading-tight'}>
                        Dashboard
                    </h1>
                    <p className={'text-[11px] text-[#a1a1aa] mt-0.5'}>
                        Manage your game servers.
                    </p>
                </div>

                <div className={'flex items-center gap-3'}>
                    {/* SHOWING YOUR SERVERS Toggle */}
                    {rootAdmin && (
                        <div className={'flex items-center gap-2'}>
                            <span className={'text-[10px] font-semibold text-[#a1a1aa] uppercase tracking-wider'}>
                                {showOnlyAdmin ? "Showing others' servers" : 'Showing your servers'}
                            </span>
                            <button
                                type={'button'}
                                onClick={() => setShowOnlyAdmin((s) => !s)}
                                className={`w-8 h-[18px] rounded-full transition-colors relative cursor-pointer border-0 ${
                                    showOnlyAdmin ? 'bg-[#8d7abb]' : 'bg-[#303034]'
                                }`}
                                title={'Toggle Servers View'}
                            >
                                <span
                                    className={`w-3.5 h-3.5 rounded-full bg-white absolute top-[2px] transition-all shadow-sm ${
                                        showOnlyAdmin ? 'left-[16px]' : 'left-[2px]'
                                    }`}
                                />
                            </button>
                        </div>
                    )}

                    {/* + Create Server Button (for root admin or configured) */}
                    {rootAdmin && (
                        <a
                            href={'/admin/servers/new'}
                            className={'bh-dashboard-create h-7 px-3 bg-[#8d7abb] hover:bg-[#7f50f2] text-white text-[11px] font-semibold rounded-[6px] flex items-center gap-1.5 transition no-underline shadow-sm cursor-pointer'}
                        >
                            <FontAwesomeIcon icon={faPlus} className={'text-[10px]'} />
                            <span>Create Server</span>
                        </a>
                    )}
                </div>
            </div>

            {/* Server List in STRICT 2-Card Compact Grid */}
            {!servers ? (
                <div className={'py-16 flex justify-center'}>
                    <Spinner size={'large'} />
                </div>
            ) : (
                <Pagination data={servers} onPageSelect={setPage}>
                    {({ items }) =>
                        items.length > 0 ? (
                            <ReorderableServerGrid key={`${uuid}:${showOnlyAdmin}:${page}`} items={items} storageKey={`${uuid}:server-card-order:${showOnlyAdmin ? 'admin' : 'own'}`} />
                        ) : (
                            <div className={'text-center py-16 px-4 bg-[#171719] border border-[#303034] rounded-xl text-[#a1a1aa] text-sm w-full'}>
                                No servers found.
                            </div>
                        )
                    }
                </Pagination>
            )}
        </div>
    );
};
