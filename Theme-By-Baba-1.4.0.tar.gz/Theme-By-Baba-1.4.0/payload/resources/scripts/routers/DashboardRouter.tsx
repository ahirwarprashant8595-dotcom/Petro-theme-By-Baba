import { ThemeAnnouncement, ThemeFooter } from '@/components/theme/PanelTheme';
import React, { useState } from 'react';
import { NavLink, Route, Switch, useLocation } from 'react-router-dom';
import DashboardContainer from '@/components/dashboard/DashboardContainer';
import { NotFound } from '@/components/elements/ScreenBlock';
import TransitionRouter from '@/TransitionRouter';
import SubNavigation from '@/components/elements/SubNavigation';
import Spinner from '@/components/elements/Spinner';
import routes from '@/routers/routes';
import BABAHostSidebar from '@/components/dashboard/BABAHostSidebar';
import BABAHostHeader from '@/components/dashboard/BABAHostHeader';
import SearchModal from '@/components/dashboard/search/SearchModal';

export default () => {
    const location = useLocation();
    const [searchModalOpen, setSearchModalOpen] = useState(false);

    return (
        <div className={'bh-app min-h-screen flex bg-[#0c0c0e] text-[#f4f4f5]'}>
            {/* BABA HOST Left Navigation Sidebar */}
            <BABAHostSidebar onOpenSearch={() => setSearchModalOpen(true)} />

            {/* Main Content Area */}
            <div className={'bh-workspace flex-1 flex flex-col min-w-0 bg-[#0c0c0e]'}>
                {/* Top Header */}
                <BABAHostHeader onOpenSearch={() => setSearchModalOpen(true)} />

                {/* Account SubNavigation (if on account pages) */}
                {location.pathname.startsWith('/account') && (
                    <nav className={'bh-account-tabs'} aria-label={'Account sections'}>
                        <div>
                            {routes.account
                                .filter((route) => !!route.name)
                                .map(({ path, name, exact = false }) => (
                                    <NavLink key={path} to={`/account/${path}`.replace('//', '/')} exact={exact}>
                                        {name}
                                    </NavLink>
                                ))}
                        </div>
                    </nav>
                )}

                {/* Dashboard Page Content */}
                <main className={'bh-main'}><ThemeAnnouncement />
                    <TransitionRouter>
                        <React.Suspense fallback={<Spinner centered />}>
                            <Switch location={location}>
                                <Route path={'/'} exact>
                                    <DashboardContainer />
                                </Route>
                                {routes.account.map(({ path, component: Component }) => (
                                    <Route key={path} path={`/account/${path}`.replace('//', '/')} exact>
                                        <Component />
                                    </Route>
                                ))}
                                <Route path={'*'}>
                                    <NotFound />
                                </Route>
                            </Switch>
                        </React.Suspense>
                    </TransitionRouter>
                <ThemeFooter /></main>
            </div>

            {/* Global Search Modal */}
            {searchModalOpen && (
                <SearchModal appear visible={searchModalOpen} onDismissed={() => setSearchModalOpen(false)} />
            )}
        </div>
    );
};
