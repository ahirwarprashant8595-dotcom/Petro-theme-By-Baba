import { ThemeAnnouncement, ThemeFooter } from '@/components/theme/PanelTheme';
import TransferListener from '@/components/server/TransferListener';
import React, { useEffect, useState } from 'react';
import { Route, Switch, useRouteMatch } from 'react-router-dom';
import TransitionRouter from '@/TransitionRouter';
import WebsocketHandler from '@/components/server/WebsocketHandler';
import { ServerContext } from '@/state/server';
import Spinner from '@/components/elements/Spinner';
import { NotFound, ServerError } from '@/components/elements/ScreenBlock';
import { httpErrorToHuman } from '@/api/http';
import InstallListener from '@/components/server/InstallListener';
import ErrorBoundary from '@/components/elements/ErrorBoundary';
import { useLocation } from 'react-router';
import ConflictStateRenderer from '@/components/server/ConflictStateRenderer';
import PermissionRoute from '@/components/elements/PermissionRoute';
import routes from '@/routers/routes';
import BABAHostServerSidebar from '@/components/server/BABAHostServerSidebar';
import BABAHostHeader from '@/components/dashboard/BABAHostHeader';
import SearchModal from '@/components/dashboard/search/SearchModal';
import { useStoreState } from 'easy-peasy';

export default () => {
    const match = useRouteMatch<{ id: string }>();
    const location = useLocation();
    const rootAdmin = useStoreState((state) => state.user.data!.rootAdmin);
    const [error, setError] = useState('');
    const [searchModalOpen, setSearchModalOpen] = useState(false);

    const id = ServerContext.useStoreState((state) => state.server.data?.id);
    const uuid = ServerContext.useStoreState((state) => state.server.data?.uuid);
    const inConflictState = ServerContext.useStoreState((state) => state.server.inConflictState);
    const getServer = ServerContext.useStoreActions((actions) => actions.server.getServer);
    const clearServerState = ServerContext.useStoreActions((actions) => actions.clearServerState);

    const to = (value: string, url = false) => {
        if (value === '/') {
            return url ? match.url : match.path;
        }
        return `${(url ? match.url : match.path).replace(/\/*$/, '')}/${value.replace(/^\/+/, '')}`;
    };

    useEffect(() => {
        setError('');
        getServer(match.params.id).catch((error) => {
            console.error(error);
            setError(httpErrorToHuman(error));
        });

        return () => {
            clearServerState();
        };
    }, [match.params.id]);

    return (
        <div className={'bh-app min-h-screen flex bg-[#0c0c0e] text-[#fafafa] select-none'}>
            {!uuid || !id ? (
                error ? (
                    <div className={'w-full h-screen flex items-center justify-center'}>
                        <ServerError message={error} />
                    </div>
                ) : (
                    <div className={'w-full h-screen flex items-center justify-center'}>
                        <Spinner size={'large'} centered />
                    </div>
                )
            ) : (
                <>
                    {/* BABA HOST Server Navigation Sidebar */}
                    <BABAHostServerSidebar serverId={match.params.id} />

                    {/* Main Content Area */}
                    <div className={'bh-workspace flex-1 flex flex-col min-w-0 bg-[#0c0c0e]'}>
                        {/* Top Header */}
                        <BABAHostHeader onOpenSearch={() => setSearchModalOpen(true)} />

                        {/* Listeners */}
                        <InstallListener />
                        <TransferListener />
                        <WebsocketHandler />

                        {/* Page Content */}
                        <main className={'bh-main'}><ThemeAnnouncement />
                            {inConflictState && (!rootAdmin || (rootAdmin && !location.pathname.endsWith(`/server/${id}`))) ? (
                                <ConflictStateRenderer />
                            ) : (
                                <ErrorBoundary>
                                    <TransitionRouter>
                                        <Switch location={location}>
                                            {routes.server.map(({ path, permission, component: Component }) => (
                                                <PermissionRoute key={path} permission={permission} path={to(path)} exact>
                                                    <Spinner.Suspense>
                                                        <Component />
                                                    </Spinner.Suspense>
                                                </PermissionRoute>
                                            ))}
                                            <Route path={'*'} component={NotFound} />
                                        </Switch>
                                    </TransitionRouter>
                                </ErrorBoundary>
                            )}
                        <ThemeFooter /></main>
                    </div>

                    {/* Search Modal */}
                    {searchModalOpen && (
                        <SearchModal appear visible={searchModalOpen} onDismissed={() => setSearchModalOpen(false)} />
                    )}
                </>
            )}
        </div>
    );
};
