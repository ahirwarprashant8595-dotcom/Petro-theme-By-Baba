import React from 'react';
import { Route } from 'react-router';
// Mount the destination immediately. Only the new page fades in; no exit wait
// and no transform on the page container (fixed dialogs keep their viewport).
const TransitionRouter: React.FC = ({ children }) => <Route render={({location}) => <div className={'bh-route-transition'} key={location.pathname + location.search}>{children}</div>} />;
export default TransitionRouter;
