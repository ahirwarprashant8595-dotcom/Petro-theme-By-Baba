<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>BABA HOST - Panel</title>
    <link rel="icon" type="image/png" href="/favicons/favicon-32x32.png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-color: #0b0712;
            --card-bg: rgba(14, 16, 24, 0.94);
            --card-border: rgba(255, 255, 255, 0.08);
            --text-white: #ffffff;
            --text-muted: #9ca3af;
            --text-dim: #6b7280;
            --purple-primary: #6f38f3;
            --purple-accent: #8b5cf6;
            --input-bg: #0b0c10;
            --input-border: #1f242f;
            --input-border-focus: #8b5cf6;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            -webkit-font-smoothing: antialiased;
        }

        html, body {
            width: 100%;
            height: 100%;
            min-height: 100vh;
            background-color: var(--bg-color);
            background-image: url('/assets/baba_datacenter_art.png?v=4.0');
            background-size: cover;
            background-position: center center;
            background-repeat: no-repeat;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            color: var(--text-white);
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            overflow-x: hidden;
        }

        /* Shared Grid Alignment Container */
        .grid-container {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 40px;
        }

        /* Top Bar */
        .top-navbar {
            width: 100%;
            height: 72px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 10;
        }

        .brand-link {
            display: flex;
            align-items: center;
            gap: 12px;
            text-decoration: none;
        }

        .brand-logo-img {
            width: 28px;
            height: 28px;
            object-fit: contain;
        }

        .brand-title-text {
            font-size: 17px;
            font-weight: 800;
            letter-spacing: 0.6px;
            color: #ffffff;
            text-transform: uppercase;
        }

        .nav-links {
            display: flex;
            align-items: center;
            gap: 32px;
        }

        .nav-link-item {
            font-size: 14px;
            font-weight: 500;
            color: var(--text-muted);
            text-decoration: none;
            transition: color 0.15s ease;
        }

        .nav-link-item:hover {
            color: #ffffff;
        }

        /* Main Viewport Content */
        .page-content-wrapper {
            flex: 1;
            width: 100%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 48px;
            padding-top: 16px;
            padding-bottom: 24px;
        }

        /* Left Hero Section */
        .left-hero-section {
            display: flex;
            flex-direction: column;
            max-width: 540px;
        }

        .hero-tagline {
            font-size: 12px;
            font-weight: 700;
            letter-spacing: 2px;
            color: #94a3b8;
            text-transform: uppercase;
            margin-bottom: 14px;
        }

        .hero-headline {
            font-size: clamp(34px, 4vw, 48px);
            font-weight: 800;
            line-height: 1.12;
            letter-spacing: -1px;
            color: #ffffff;
            margin-bottom: 16px;
        }

        .headline-purple {
            color: var(--purple-accent);
        }

        .hero-description {
            font-size: 15px;
            line-height: 1.6;
            color: var(--text-muted);
            margin-bottom: 28px;
        }

        /* Features List */
        .features-list {
            display: flex;
            flex-direction: column;
            gap: 16px;
            margin-bottom: 32px;
        }

        .feature-row {
            display: flex;
            align-items: center;
            gap: 14px;
        }

        .feature-icon-wrapper {
            width: 44px;
            height: 44px;
            background: #13151f;
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }

        .feature-text-block {
            display: flex;
            flex-direction: column;
            gap: 2px;
        }

        .feature-name {
            font-size: 15px;
            font-weight: 600;
            color: #ffffff;
        }

        .feature-sub {
            font-size: 12.5px;
            color: var(--text-dim);
        }

        /* Stats Row */
        .stats-container {
            display: flex;
            align-items: center;
            gap: 48px;
        }

        .stat-item {
            display: flex;
            flex-direction: column;
            gap: 3px;
        }

        .stat-num {
            font-size: 22px;
            font-weight: 700;
            color: #ffffff;
        }

        .stat-label {
            font-size: 12.5px;
            color: var(--text-dim);
        }

        /* Right Card Container */
        .login-card-container {
            width: clamp(360px, 34vw, 420px);
            background: var(--card-bg);
            border: 1px solid var(--card-border);
            border-radius: 12px;
            padding: 32px 30px 28px 30px;
            display: flex;
            flex-direction: column;
            align-items: center;
            box-shadow: 0 16px 40px rgba(0, 0, 0, 0.6);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            flex-shrink: 0;
        }

        .card-logo-img {
            width: 32px;
            height: 38px;
            object-fit: contain;
            margin-bottom: 8px;
        }

        .card-brand-title {
            font-size: 15px;
            font-weight: 800;
            letter-spacing: 0.5px;
            color: #ffffff;
            text-transform: uppercase;
            margin-bottom: 4px;
        }

        .card-welcome-heading {
            font-size: 21px;
            font-weight: 700;
            color: #ffffff;
            margin-bottom: 4px;
        }

        .card-welcome-sub {
            font-size: 13px;
            color: var(--text-dim);
            margin-bottom: 22px;
        }

        .auth-form {
            width: 100%;
            display: flex;
            flex-direction: column;
        }

        .input-group {
            display: flex;
            flex-direction: column;
            gap: 6px;
            margin-bottom: 16px;
        }

        .input-label {
            font-size: 13px;
            font-weight: 500;
            color: #d1d5db;
        }

        .input-box-relative {
            position: relative;
            width: 100%;
        }

        .input-lead-icon {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            display: flex;
            align-items: center;
            justify-content: center;
            pointer-events: none;
        }

        .text-input-field {
            width: 100%;
            height: 42px;
            background: var(--input-bg);
            border: 1px solid var(--input-border);
            border-radius: 7px;
            color: #ffffff;
            font-size: 13.5px;
            padding: 0 42px 0 42px;
            outline: none;
            transition: border-color 0.15s ease;
            font-family: inherit;
        }

        .text-input-field:focus {
            border-color: var(--input-border-focus);
        }

        /* Prevent browser autofill from turning inputs yellow/white */
        input:-webkit-autofill,
        input:-webkit-autofill:hover, 
        input:-webkit-autofill:focus, 
        input:-webkit-autofill:active {
            -webkit-box-shadow: 0 0 0 1000px #0b0c10 inset !important;
            box-shadow: 0 0 0 1000px #0b0c10 inset !important;
            -webkit-text-fill-color: #ffffff !important;
            color: #ffffff !important;
            caret-color: #ffffff !important;
            border-color: #1f242f !important;
            transition: background-color 5000s ease-in-out 0s;
        }

        .password-toggle-btn {
            position: absolute;
            right: 14px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            cursor: pointer;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .remember-forgot-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 12.5px;
            margin-top: -2px;
            margin-bottom: 18px;
        }

        .remember-label {
            display: flex;
            align-items: center;
            gap: 7px;
            color: var(--text-muted);
            cursor: pointer;
            user-select: none;
        }

        .remember-checkbox {
            width: 13px;
            height: 13px;
            accent-color: var(--purple-accent);
            cursor: pointer;
        }

        .forgot-link {
            color: var(--purple-accent);
            text-decoration: none;
        }

        .forgot-link:hover {
            text-decoration: underline;
        }

        .btn-submit-login {
            width: 100%;
            height: 42px;
            background: var(--purple-primary);
            border: none;
            border-radius: 7px;
            color: #ffffff;
            font-size: 14.5px;
            font-weight: 600;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            margin-bottom: 16px;
            transition: opacity 0.15s ease;
            font-family: inherit;
        }

        .btn-submit-login:hover {
            opacity: 0.95;
        }

        .or-divider-row {
            display: flex;
            align-items: center;
            gap: 12px;
            width: 100%;
            margin-bottom: 16px;
        }

        .divider-line {
            flex: 1;
            height: 1px;
            background: #1f242f;
        }

        .divider-text {
            font-size: 10.5px;
            color: var(--text-dim);
            font-weight: 600;
            text-transform: uppercase;
        }

        .btn-discord-login {
            width: 100%;
            height: 42px;
            background: #13151c;
            border: 1px solid #1a1d25;
            border-radius: 7px;
            color: #ffffff;
            font-size: 13.5px;
            font-weight: 500;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            text-decoration: none;
            transition: background 0.15s ease;
        }

        .btn-discord-login:hover {
            background: #181b24;
        }

        /* Bottom Footer */
        .bottom-page-footer {
            width: 100%;
            height: 56px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 10;
        }

        .footer-copyright {
            font-size: 12.5px;
            color: var(--text-dim);
        }

        .footer-nav-links {
            display: flex;
            align-items: center;
            gap: 24px;
        }

        .footer-nav-link {
            font-size: 12.5px;
            color: var(--text-dim);
            text-decoration: none;
            transition: color 0.15s ease;
        }

        .footer-nav-link:hover {
            color: #ffffff;
        }

        .error-banner {
            width: 100%;
            padding: 9px 12px;
            background: rgba(239, 68, 68, 0.1);
            border: 1px solid rgba(239, 68, 68, 0.3);
            border-radius: 6px;
            color: #fca5a5;
            font-size: 12px;
            line-height: 1.4;
            display: none;
            margin-bottom: 12px;
        }

        @media (max-width: 820px) {
            .grid-container {
                padding: 0 20px;
            }
            .page-content-wrapper {
                flex-direction: column;
                align-items: center;
                gap: 32px;
                padding: 20px 0;
            }
            .left-hero-section {
                text-align: center;
                align-items: center;
                width: 100%;
                padding-top: 10px;
            }
            .features-list {
                align-items: center;
            }
            .stats-container {
                justify-content: center;
            }
            .bottom-page-footer {
                flex-direction: column;
                gap: 8px;
                height: auto;
                padding: 12px 0 20px 0;
                text-align: center;
            }
        }
    </style>
</head>
<body>
    <!-- Top Bar Navigation (Inside aligned container) -->
    <div class="grid-container">
        <header class="top-navbar">
            <a href="/" class="brand-link">
                <img src="/assets/baba_logo.png" alt="BABA HOST Logo" class="brand-logo-img">
                <span class="brand-title-text">BABA HOST</span>
            </a>
            <nav class="nav-links">
                <a href="#" class="nav-link-item">Support</a>
                <a href="#" class="nav-link-item">Status</a>
                <a href="#" class="nav-link-item">Docs</a>
            </nav>
        </header>
    </div>

    <!-- Main Viewport Content (Inside aligned container) -->
    <div class="grid-container" style="flex: 1; display: flex;">
        <main class="page-content-wrapper">
            <!-- Left Hero Section -->
            <section class="left-hero-section">
                <div class="hero-tagline">GAME SERVER CONTROL PANEL</div>
                <h1 class="hero-headline">
                    Powerful Server<br>
                    <span class="headline-purple">Management</span>
                </h1>
                <p class="hero-description">
                    Deploy, manage, and scale your game servers<br>
                    with a modern and powerful control panel.
                </p>

                <!-- 3 Stacked Features -->
                <div class="features-list">
                    <div class="feature-row">
                        <div class="feature-icon-wrapper">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#8b5cf6" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg>
                        </div>
                        <div class="feature-text-block">
                            <span class="feature-name">Fast &amp; Reliable</span>
                            <span class="feature-sub">High performance infrastructure</span>
                        </div>
                    </div>

                    <div class="feature-row">
                        <div class="feature-icon-wrapper">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#8b5cf6" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                        </div>
                        <div class="feature-text-block">
                            <span class="feature-name">Secure</span>
                            <span class="feature-sub">Enterprise grade security</span>
                        </div>
                    </div>

                    <div class="feature-row">
                        <div class="feature-icon-wrapper">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#8b5cf6" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>
                        </div>
                        <div class="feature-text-block">
                            <span class="feature-name">Full Control</span>
                            <span class="feature-sub">Manage files, console and more</span>
                        </div>
                    </div>
                </div>

                <!-- Stats Row -->
                <div class="stats-container">
                    <div class="stat-item">
                        <span class="stat-num">99.9%</span>
                        <span class="stat-label">Uptime</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-num">Global</span>
                        <span class="stat-label">Locations</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-num">24/7</span>
                        <span class="stat-label">Support</span>
                    </div>
                </div>
            </section>

            <!-- Right Login Card -->
            <section class="login-card-container">
                <img src="/assets/baba_logo.png" alt="BABA HOST" class="card-logo-img">
                <div class="card-brand-title">BABA HOST</div>
                <h2 class="card-welcome-heading">Welcome Back</h2>
                <div class="card-welcome-sub">Login to your BABA HOST account</div>

                <div id="errorMessage" class="error-banner"></div>

                <form id="loginForm" class="auth-form">
                    <div class="input-group">
                        <label class="input-label" for="userInput">Email Address</label>
                        <div class="input-box-relative">
                            <span class="input-lead-icon">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#6b7280" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
                            </span>
                            <input type="text" id="userInput" name="user" class="text-input-field" placeholder="you@example.com" required autocomplete="email">
                        </div>
                    </div>

                    <div class="input-group">
                        <label class="input-label" for="passwordInput">Password</label>
                        <div class="input-box-relative">
                            <span class="input-lead-icon">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#6b7280" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                            </span>
                            <input type="password" id="passwordInput" name="password" class="text-input-field" placeholder="••••••••" required autocomplete="current-password">
                            <button type="button" id="togglePasswordBtn" class="password-toggle-btn" aria-label="Toggle password visibility">
                                <svg id="eyeIconSvg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#6b7280" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                            </button>
                        </div>
                    </div>

                    <div class="remember-forgot-row">
                        <label class="remember-label">
                            <input type="checkbox" id="rememberMe" class="remember-checkbox">
                            <span>Remember me</span>
                        </label>
                        <a href="/auth/password" class="forgot-link">Forgot password?</a>
                    </div>

                    <button type="submit" id="submitLoginBtn" class="btn-submit-login">
                        <span>Login</span>
                        <span style="font-size: 16px;">&rarr;</span>
                    </button>

                    <div class="or-divider-row">
                        <span class="divider-line"></span>
                        <span class="divider-text">OR</span>
                        <span class="divider-line"></span>
                    </div>

                    <a href="/auth/discord" class="btn-discord-login">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="#ffffff"><path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994.021-.041.001-.09-.041-.106a13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.929 1.793 8.18 1.793 12.061 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.894.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.028zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/></svg>
                        <span>Login with Discord</span>
                    </a>
                </form>
            </section>
        </main>
    </div>

    <!-- Bottom Page Footer (Inside aligned container) -->
    <div class="grid-container">
        <footer class="bottom-page-footer">
            <div class="footer-copyright">
                &copy; 2025 - 2026 BABA HOST | Powered by Pterodactyl Software
            </div>
            <div class="footer-nav-links">
                <a href="#" class="footer-nav-link">Terms of Service</a>
                <a href="#" class="footer-nav-link">Privacy Policy</a>
                <a href="#" class="footer-nav-link">Contact</a>
            </div>
        </footer>
    </div>

    <!-- Functional Scripts -->
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            var toggleBtn = document.getElementById('togglePasswordBtn');
            var passwordInput = document.getElementById('passwordInput');
            var eyeSvg = document.getElementById('eyeIconSvg');
            var form = document.getElementById('loginForm');
            var errorBanner = document.getElementById('errorMessage');
            var submitBtn = document.getElementById('submitLoginBtn');
            var csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

            // Password toggle
            toggleBtn.addEventListener('click', function () {
                if (passwordInput.type === 'password') {
                    passwordInput.type = 'text';
                    eyeSvg.innerHTML = '<path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/>';
                } else {
                    passwordInput.type = 'password';
                    eyeSvg.innerHTML = '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>';
                }
            });

            // Authentication Form Submission
            form.addEventListener('submit', function (e) {
                e.preventDefault();
                errorBanner.style.display = 'none';
                errorBanner.innerText = '';
                submitBtn.disabled = true;
                submitBtn.style.opacity = '0.7';

                var payload = {
                    user: document.getElementById('userInput').value,
                    password: passwordInput.value,
                    remember: document.getElementById('rememberMe').checked
                };

                fetch('/auth/login', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                        'X-CSRF-TOKEN': csrfToken
                    },
                    body: JSON.stringify(payload)
                })
                .then(function (response) {
                    return response.json().then(function (data) {
                        return { status: response.status, data: data };
                    });
                })
                .then(function (res) {
                    if (res.status === 200 && res.data.data && res.data.data.complete) {
                        window.location.href = res.data.data.intended || '/';
                    } else if (res.status === 200 && res.data.data && res.data.data.two_factor) {
                        window.location.href = '/auth/login/checkpoint';
                    } else {
                        submitBtn.disabled = false;
                        submitBtn.style.opacity = '1';
                        var msg = 'The credentials provided do not match our records.';
                        if (res.data.errors && res.data.errors[0] && res.data.errors[0].detail) {
                            msg = res.data.errors[0].detail;
                        }
                        errorBanner.innerText = msg;
                        errorBanner.style.display = 'block';
                    }
                })
                .catch(function (err) {
                    submitBtn.disabled = false;
                    submitBtn.style.opacity = '1';
                    errorBanner.innerText = 'An unexpected error occurred. Please try again.';
                    errorBanner.style.display = 'block';
                });
            });
        });
    </script>
</body>
</html>