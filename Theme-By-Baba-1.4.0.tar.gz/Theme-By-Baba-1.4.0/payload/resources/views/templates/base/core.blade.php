@extends('templates/wrapper', [
    'css' => ['body' => 'bg-[#0B0B13]'],
])

@section('container')
    <div id="modal-portal"></div>
    <div id="app"></div>
@endsection
