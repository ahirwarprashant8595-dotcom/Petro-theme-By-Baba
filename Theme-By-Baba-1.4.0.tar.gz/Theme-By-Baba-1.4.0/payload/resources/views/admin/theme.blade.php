@extends('layouts.admin')
@section('title', 'Edit Theme')
@section('content-header')<h1>Edit Theme</h1>@endsection
@section('content')
<link rel="stylesheet" href="/assets/theme-editor-admin.css?v=20261027-4">
<div class="theme-editor">
<nav class="editor-rail" aria-label="Theme settings"><a href="/admin" title="Back to administration"><i class="fa fa-arrow-left"></i><span>Admin</span></a>
@foreach(['branding'=>['fa-magic','Branding'],'colours'=>['fa-paint-brush','Colours'],'images'=>['fa-image','Images'],'layout'=>['fa-th-large','Layout'],'announcement'=>['fa-bullhorn','Announcement'],'links'=>['fa-link','Support links']] as $key=>$item)<button type="button" data-tab="{{ $key }}" title="{{ $item[1] }}"><i class="fa {{ $item[0] }}"></i><span>{{ $item[1] }}</span></button>@endforeach
</nav>
<form method="POST" enctype="multipart/form-data" action="{{ route('admin.theme') }}" id="theme-editor" class="editor-controls">{!! csrf_field() !!}
<header class="editor-title"><div><small>{{ $theme['name'] }}</small><h2>Edit Theme</h2></div><span id="save-status">Saved theme</span></header>
@if(session('status'))<div class="alert alert-success">{{ session('status') }}</div>@endif
@if($errors->any())<div class="alert alert-danger"><ul>@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul></div>@endif
<div class="editor-fields"><div class="box" data-section="branding"><div class="box-header with-border"><h3 class="box-title">Branding</h3></div><div class="box-body theme-fields">
<div><label for="theme-name">Panel name</label><input id="theme-name" class="form-control" name="name" maxlength="60" value="{{ old('name',$theme['name']) }}" required></div>
<div><label for="theme-footer">Footer text</label><input id="theme-footer" class="form-control" name="footer" maxlength="200" value="{{ old('footer',$theme['footer']) }}"></div>
<div><label for="theme-footer_url">Footer link (optional)</label><input id="theme-footer_url" class="form-control" type="url" name="footer_url" value="{{ old('footer_url',$theme['footer_url']) }}" placeholder="https://example.com"></div>
</div></div>
<div class="box" data-section="colours"><div class="box-header with-border"><h3 class="box-title">Colours & shape</h3></div><div class="box-body theme-fields">
@foreach(['accent'=>'Accent / buttons','background'=>'Page background','surface'=>'Cards / panels','sidebar'=>'Sidebar / header','text'=>'Main text','muted'=>'Secondary text','border'=>'Borders'] as $key=>$label)
<div><label for="theme-{{ $key }}">{{ $label }}</label><input id="theme-{{ $key }}" type="color" name="{{ $key }}" value="{{ old($key,$theme[$key]) }}"><small>{{ $theme[$key] }}</small></div>
@endforeach
<div><label for="theme-radius">Corner radius (0–24px)</label><input id="theme-radius" class="form-control" type="number" name="radius" min="0" max="24" value="{{ old('radius',$theme['radius']) }}" required></div>
<div><label><input type="checkbox" name="companion" value="1" {{ old('companion',$theme['companion']) ? 'checked' : '' }}> Show console character</label></div>
</div></div>
<div class="box" data-section="images"><div class="box-header with-border"><h3 class="box-title">Images</h3></div><div class="box-body theme-fields">
@foreach(['logo'=>'Sidebar logo','icon'=>'Browser icon','wallpaper'=>'Workspace background'] as $key=>$label)
<div><label>{{ $label }}</label>@if($theme[$key])<img class="asset-preview" src="{{ $theme[$key] }}" alt="{{ $label }}">@endif<input type="file" name="{{ $key }}" accept="image/png,image/jpeg,image/webp"><p class="text-muted">PNG, JPG or WebP. Maximum 5 MB.</p><label><input type="checkbox" name="remove_{{ $key }}" value="1"> {{ $key==='logo' ? 'Restore default logo' : 'Remove image' }}</label></div>
@endforeach
</div></div>

<div class="box" data-section="layout"><div class="box-header"><h3 class="box-title">Layout & components</h3></div><div class="box-body">
@foreach(['card_style'=>['Server cards',['banner'=>'Banner','flat'=>'Flat','compact'=>'Compact']],'nav_style'=>['Navigation highlight',['outline'=>'Outline','filled'=>'Filled','minimal'=>'Minimal']],'density'=>['Spacing',['comfortable'=>'Comfortable','compact'=>'Compact']],'stats_style'=>['Console statistics',['default'=>'Default','reversed'=>'Reversed','minimal'=>'Minimal']]] as $key=>$config)
<fieldset class="style-choices"><legend>{{ $config[0] }}</legend><div>@foreach($config[1] as $value=>$label)<label class="style-choice"><input type="radio" name="{{ $key }}" value="{{ $value }}" {{ old($key,$theme[$key])===$value ? 'checked' : '' }}><span class="choice-sketch {{ $value }}"><i></i><b></b><em></em></span><span>{{ $label }}</span></label>@endforeach</div></fieldset>
@endforeach
<p class="editor-hint">Desktop keeps two cards per row. Mobile uses one card and a slide-out navigation menu.</p>
</div></div>
<div class="box" data-section="announcement"><div class="box-header"><h3 class="box-title">Announcement</h3></div><div class="box-body">
<label class="toggle-field">Enable announcement<input type="checkbox" name="announcement_enabled" value="1" {{ old('announcement_enabled',$theme['announcement_enabled']) ? 'checked' : '' }}></label>
<label>Message<textarea name="announcement" maxlength="1000" rows="4" class="form-control">{{ old('announcement',$theme['announcement']) }}</textarea></label>
<label>Announcement colour<input type="color" name="announcement_color" value="{{ old('announcement_color',$theme['announcement_color']) }}"></label>
<label>Icon<select name="announcement_icon" class="form-control">@foreach(['info'=>'ⓘ Information','megaphone'=>'⚑ Announcement','check'=>'✓ Success','warning'=>'⚠ Warning','fire'=>'🔥 Offer'] as $value=>$label)<option value="{{ $value }}" {{ old('announcement_icon',$theme['announcement_icon'])===$value ? 'selected' : '' }}>{{ $label }}</option>@endforeach</select></label>
<label class="toggle-field">Allow users to dismiss<input type="checkbox" name="announcement_dismissible" value="1" {{ old('announcement_dismissible',$theme['announcement_dismissible']) ? 'checked' : '' }}></label>
<h4>Call to action</h4><label>Button title<input name="cta_label" class="form-control" maxlength="60" value="{{ old('cta_label',$theme['cta_label']) }}" placeholder="Check now"></label><label>Button link<input name="cta_url" class="form-control" type="url" value="{{ old('cta_url',$theme['cta_url']) }}" placeholder="https://example.com"></label>
</div></div>
<div class="box" data-section="links"><div class="box-header"><h3 class="box-title">Support links</h3></div><div class="box-body">
@foreach(['support_label'=>'Support link title','support_url'=>'Support centre URL','discord_url'=>'Discord invite URL'] as $key=>$label)<label>{{ $label }}<input class="form-control" name="{{ $key }}" type="{{ $key==='support_label' ? 'text' : 'url' }}" value="{{ old($key,$theme[$key]) }}"></label>@endforeach
<p class="editor-hint">Links appear above the workspace content. Leave the URLs blank to hide them.</p>
<a class="editor-link" href="/admin/nests">Manage per-Egg banners & icons →</a><p class="editor-hint">Login appearance is preserved.</p>
</div></div>
</div><div class="editor-save"><button class="btn btn-primary" type="submit">Save Changes</button><button type="submit" name="action" value="reset" class="editor-reset" onclick="return confirm('Restore all theme defaults?')">Restore defaults</button></div>
</form>
<section class="editor-preview"><header class="preview-toolbar"><div role="group" aria-label="Preview viewport"><button type="button" data-device="desktop" aria-pressed="true"><i class="fa fa-desktop"></i> Desktop</button><button type="button" data-device="tablet" aria-pressed="false"><i class="fa fa-tablet"></i> Tablet</button><button type="button" data-device="mobile" aria-pressed="false"><i class="fa fa-mobile"></i> Mobile</button></div><a href="/" target="_blank" rel="noopener" title="Open panel"><i class="fa fa-external-link"></i></a></header>
<div class="preview-pages"><button type="button" data-preview-path="/" class="active">Dashboard</button><button type="button" data-preview-path="/account">Account</button>@if($previewServer)<button type="button" data-preview-path="/server/{{ $previewServer }}">Console</button>@endif<span>Live preview · unsaved changes</span></div>
<div class="preview-stage" id="preview-stage"><iframe id="panel-preview" title="Live panel theme preview" src="/" referrerpolicy="same-origin"></iframe></div>
</section></div>
<script src="/assets/theme-editor-admin.js?v=20261027-4" defer></script>
@endsection
