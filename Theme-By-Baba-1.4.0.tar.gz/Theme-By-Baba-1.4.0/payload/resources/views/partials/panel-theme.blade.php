@php($panelTheme = app(\Pterodactyl\Services\Theme\PanelTheme::class)->get())
<script>window.PanelTheme = {!! json_encode($panelTheme, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) !!};</script>

<link rel="icon" sizes="any" href="{{ $panelTheme['icon'] ?: $panelTheme['logo'] }}">
