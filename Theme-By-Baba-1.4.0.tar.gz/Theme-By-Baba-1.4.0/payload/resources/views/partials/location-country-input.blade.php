<div class="form-group">
    <label>Country</label>
    <select name="country_code" class="form-control" aria-label="Location country">
        <option value="">Not specified</option>
        @foreach(\Pterodactyl\Services\Locations\LocationCountry::countries() as $code => $name)
            <option value="{{ $code }}" {{ old('country_code', isset($location) ? \Pterodactyl\Services\Locations\LocationCountry::code($location) : '') === $code ? 'selected' : '' }}>{{ $name }} ({{ strtoupper($code) }})</option>
        @endforeach
    </select>
    <p class="help-block small">Select the actual country of the nodes in this location. This is administrator-provided location data, not IP geolocation.</p>
</div>
