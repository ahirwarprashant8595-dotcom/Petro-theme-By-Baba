@php($countryCode = \Pterodactyl\Services\Locations\LocationCountry::code($location))
@if($countryCode)
<span class="ba-location-country"><img src="/assets/flags/{{ $countryCode }}.svg" alt="" width="24" height="18"> {{ \Pterodactyl\Services\Locations\LocationCountry::countries()[$countryCode] }}</span>
@else
<span class="text-muted"><i class="fa fa-globe" aria-hidden="true"></i> Not specified</span>
@endif
