<?php

use Pterodactyl\Enum\ResourceLimit;
use Illuminate\Support\Facades\Route;
use Pterodactyl\Http\Controllers\Api\Client;
use Pterodactyl\Http\Middleware\Activity\ServerSubject;
use Pterodactyl\Http\Middleware\Activity\AccountSubject;
use Pterodactyl\Http\Middleware\RequireTwoFactorAuthentication;
use Pterodactyl\Http\Middleware\Api\Client\Server\ResourceBelongsToServer;
use Pterodactyl\Http\Middleware\Api\Client\Server\AuthenticateServerAccess;

/*
|--------------------------------------------------------------------------
| Client Control API
|--------------------------------------------------------------------------
|
| Endpoint: /api/client
|
*/
Route::get('/', [Client\ClientController::class, 'index'])->name('api:client.index');
Route::get('/permissions', [Client\ClientController::class, 'permissions']);

Route::prefix('/account')->middleware(AccountSubject::class)->group(function () {
    Route::prefix('/')->withoutMiddleware(RequireTwoFactorAuthentication::class)->group(function () {
        Route::get('/', [Client\AccountController::class, 'index'])->name('api:client.account');
        Route::get('/two-factor', [Client\TwoFactorController::class, 'index']);
        Route::post('/two-factor', [Client\TwoFactorController::class, 'store']);
        Route::post('/two-factor/disable', [Client\TwoFactorController::class, 'delete']);
    });

    Route::put('/email', [Client\AccountController::class, 'updateEmail'])
        ->middleware('throttle')
        ->name('api:client.account.update-email');
    Route::put('/password', [Client\AccountController::class, 'updatePassword'])->name('api:client.account.update-password');

    Route::get('/activity', Client\ActivityLogController::class)->name('api:client.account.activity');

    Route::get('/api-keys', [Client\ApiKeyController::class, 'index']);
    Route::post('/api-keys', [Client\ApiKeyController::class, 'store']);
    Route::delete('/api-keys/{identifier}', [Client\ApiKeyController::class, 'delete']);

    Route::prefix('/ssh-keys')->group(function () {
        Route::get('/', [Client\SSHKeyController::class, 'index']);
        Route::post('/', [Client\SSHKeyController::class, 'store']);
        Route::post('/remove', [Client\SSHKeyController::class, 'delete']);
    });
});

/*
|--------------------------------------------------------------------------
| Client Control API
|--------------------------------------------------------------------------
|
| Endpoint: /api/client/servers/{server}
|
*/
Route::group([
    'prefix' => '/servers/{server}',
    'middleware' => [
        ServerSubject::class,
        AuthenticateServerAccess::class,
        ResourceBelongsToServer::class,
    ],
], function () {
    Route::get('/', [Client\Servers\ServerController::class, 'index'])->name('api:client:server.view');
    Route::middleware([ResourceLimit::Websocket->middleware()])
        ->get('/websocket', Client\Servers\WebsocketController::class)
        ->name('api:client:server.ws');
    Route::get('/resources', Client\Servers\ResourceUtilizationController::class)->name('api:client:server.resources');
    Route::get('/customization', [Client\Servers\CustomizationController::class, 'index']);
    Route::post('/customization/artwork', [Client\Servers\CustomizationController::class, 'artwork'])->middleware('throttle:12,1');
    Route::post('/customization/egg', [Client\Servers\CustomizationController::class, 'egg'])->middleware('throttle:4,1');
    Route::post('/customization/github', [Client\Servers\CustomizationController::class, 'github'])->middleware('throttle:3,1');
    Route::prefix('minecraft')->group(function () {
        Route::get('/modpacks', [Client\Servers\MinecraftPacksController::class, 'search']);
        Route::post('/modpacks/prepare', [Client\Servers\MinecraftPacksController::class, 'prepare'])->middleware('throttle:2,1');
        Route::post('/modpacks/jobs/{job}/apply', [Client\Servers\MinecraftPacksController::class, 'apply'])->middleware('throttle:2,1');
        Route::get('/modpacks/jobs/{job}', [Client\Servers\MinecraftPacksController::class, 'status']);
        Route::get('/eggs', [Client\Servers\MinecraftEggController::class, 'index']);
        Route::post('/eggs/reset', [Client\Servers\MinecraftEggController::class, 'reset'])->middleware('throttle:2,1');
        Route::get('/mods', [Client\Servers\MinecraftModsController::class, 'search']);
        Route::get('/mods/{project}/versions', [Client\Servers\MinecraftModsController::class, 'versions']);
        Route::post('/mods/install', [Client\Servers\MinecraftModsController::class, 'install'])->middleware('throttle:6,1');
        Route::get('/utils', [Client\Servers\MinecraftUtilsController::class, 'state']);
        Route::post('/utils/install', [Client\Servers\MinecraftUtilsController::class, 'install'])->middleware('throttle:3,1');
        Route::post('/players/{uuid}/action', [Client\Servers\MinecraftUtilsController::class, 'action'])->middleware('throttle:30,1');
        Route::delete('/players/{uuid}/data', [Client\Servers\MinecraftUtilsController::class, 'deletePlayer'])->middleware('throttle:3,1');
        Route::get('/map/{uuid}', [Client\Servers\MinecraftUtilsController::class, 'map']);
        Route::post('/map', [Client\Servers\MinecraftUtilsController::class, 'worldMap'])->middleware('throttle:6,1');
        Route::get('/worlds', [Client\Servers\MinecraftUtilsController::class, 'worlds']);
        Route::get('/options', [Client\Servers\MinecraftController::class, 'options']);
        Route::put('/options', [Client\Servers\MinecraftController::class, 'saveOptions'])->middleware('throttle:10,1');
        Route::get('/players', [Client\Servers\MinecraftController::class, 'players']);
        Route::get('/players/{uuid}', [Client\Servers\MinecraftController::class, 'player']);
        Route::get('/software/status', [Client\Servers\MinecraftController::class, 'installedSoftware']);
        Route::get('/software/versions', [Client\Servers\MinecraftController::class, 'versions']);
        Route::get('/game-versions', [Client\Servers\MinecraftController::class, 'gameVersions']);
        Route::post('/software/download', [Client\Servers\MinecraftController::class, 'softwareDownload'])->middleware('throttle:6,1');
        Route::get('/plugins', [Client\Servers\MinecraftController::class, 'pluginSearch']);
        Route::get('/plugins/{project}/versions', [Client\Servers\MinecraftController::class, 'pluginVersions']);
        Route::post('/plugins/install', [Client\Servers\MinecraftController::class, 'pluginInstall'])->middleware('throttle:6,1');
    });

    Route::get('/activity', Client\Servers\ActivityLogController::class)->name('api:client:server.activity');

    Route::post('/command', [Client\Servers\CommandController::class, 'index']);
    Route::post('/power', [Client\Servers\PowerController::class, 'index']);

    Route::group(['prefix' => '/databases'], function () {
        Route::get('/', [Client\Servers\DatabaseController::class, 'index']);
        Route::middleware([ResourceLimit::Database->middleware()])
            ->post('/', [Client\Servers\DatabaseController::class, 'store']);
        Route::post('/{database}/rotate-password', [Client\Servers\DatabaseController::class, 'rotatePassword']);
        Route::delete('/{database}', [Client\Servers\DatabaseController::class, 'delete']);
    });

    Route::group(['prefix' => '/files'], function () {
        Route::get('/list', [Client\Servers\FileController::class, 'directory']);
        Route::get('/contents', [Client\Servers\FileController::class, 'contents']);
        Route::get('/download', [Client\Servers\FileController::class, 'download']);
        Route::put('/rename', [Client\Servers\FileController::class, 'rename']);
        Route::post('/copy', [Client\Servers\FileController::class, 'copy']);
        Route::post('/write', [Client\Servers\FileController::class, 'write']);
        Route::post('/compress', [Client\Servers\FileController::class, 'compress']);
        Route::post('/decompress', [Client\Servers\FileController::class, 'decompress']);
        Route::post('/delete', [Client\Servers\FileController::class, 'delete']);
        Route::post('/create-folder', [Client\Servers\FileController::class, 'create']);
        Route::post('/chmod', [Client\Servers\FileController::class, 'chmod']);
        Route::middleware([ResourceLimit::FilePull->middleware()])
            ->post('/pull', [Client\Servers\FileController::class, 'pull']);
        Route::get('/upload', Client\Servers\FileUploadController::class);
    });

    Route::group(['prefix' => '/schedules'], function () {
        Route::get('/', [Client\Servers\ScheduleController::class, 'index']);
        Route::middleware([ResourceLimit::Schedule->middleware()])
            ->post('/', [Client\Servers\ScheduleController::class, 'store']);
        Route::get('/{schedule}', [Client\Servers\ScheduleController::class, 'view']);
        Route::post('/{schedule}', [Client\Servers\ScheduleController::class, 'update']);
        Route::post('/{schedule}/execute', [Client\Servers\ScheduleController::class, 'execute']);
        Route::delete('/{schedule}', [Client\Servers\ScheduleController::class, 'delete']);

        Route::post('/{schedule}/tasks', [Client\Servers\ScheduleTaskController::class, 'store']);
        Route::post('/{schedule}/tasks/{task}', [Client\Servers\ScheduleTaskController::class, 'update']);
        Route::delete('/{schedule}/tasks/{task}', [Client\Servers\ScheduleTaskController::class, 'delete']);
    });

    Route::group(['prefix' => '/network'], function () {
        Route::get('/allocations', [Client\Servers\NetworkAllocationController::class, 'index']);
        Route::middleware([ResourceLimit::Allocation->middleware()])
            ->post('/allocations', [Client\Servers\NetworkAllocationController::class, 'store']);
        Route::post('/allocations/{allocation}', [Client\Servers\NetworkAllocationController::class, 'update']);
        Route::post('/allocations/{allocation}/primary', [Client\Servers\NetworkAllocationController::class, 'setPrimary']);
        Route::delete('/allocations/{allocation}', [Client\Servers\NetworkAllocationController::class, 'delete']);
    });

    Route::group(['prefix' => '/users'], function () {
        Route::get('/', [Client\Servers\SubuserController::class, 'index']);
        Route::middleware([ResourceLimit::Subuser->middleware()])
            ->post('/', [Client\Servers\SubuserController::class, 'store']);
        Route::get('/{user}', [Client\Servers\SubuserController::class, 'view']);
        Route::post('/{user}', [Client\Servers\SubuserController::class, 'update']);
        Route::delete('/{user}', [Client\Servers\SubuserController::class, 'delete']);
    });

    Route::group(['prefix' => '/backups'], function () {
        Route::get('/', [Client\Servers\BackupController::class, 'index']);
        Route::post('/', [Client\Servers\BackupController::class, 'store']);
        Route::get('/{backup}', [Client\Servers\BackupController::class, 'view']);
        Route::get('/{backup}/download', [Client\Servers\BackupController::class, 'download']);
        Route::post('/{backup}/lock', [Client\Servers\BackupController::class, 'toggleLock']);
        Route::middleware([ResourceLimit::Backup->middleware()])
            ->post('/{backup}/restore', [Client\Servers\BackupController::class, 'restore']);
        Route::delete('/{backup}', [Client\Servers\BackupController::class, 'delete']);
    });

    Route::group(['prefix' => '/startup'], function () {
        Route::get('/', [Client\Servers\StartupController::class, 'index']);
        Route::put('/variable', [Client\Servers\StartupController::class, 'update']);
        Route::put('/command', [Client\Servers\StartupController::class, 'command']);
    });

    Route::group(['prefix' => '/settings'], function () {
        Route::post('/rename', [Client\Servers\SettingsController::class, 'rename']);
        Route::post('/reinstall', [Client\Servers\SettingsController::class, 'reinstall']);
        Route::put('/docker-image', [Client\Servers\SettingsController::class, 'dockerImage']);
    });
});
