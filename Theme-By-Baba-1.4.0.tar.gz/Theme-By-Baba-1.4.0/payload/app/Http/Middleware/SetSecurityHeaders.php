<?php

namespace Pterodactyl\Http\Middleware;

use Illuminate\Http\Request;

class SetSecurityHeaders
{
    private static array $headers = [
        'X-Frame-Options' => 'DENY',
        'X-Content-Type-Options' => 'nosniff',
        'X-XSS-Protection' => '1; mode=block',
        'Referrer-Policy' => 'no-referrer-when-downgrade',
    ];

    public function handle(Request $request, \Closure $next): mixed
    {
        $response = $next($request);
        foreach (static::$headers as $key => $value) {
            if (!$response->headers->has($key)) $response->headers->set($key, $value);
        }
        // The admin theme editor embeds only the same-origin client pages.
        if ($request->isMethod('GET') && $request->user()?->root_admin
            && $request->is('/', 'account', 'account/*', 'server/*')) {
            $response->headers->set('X-Frame-Options', 'SAMEORIGIN');
            $policy = $response->headers->get('Content-Security-Policy', '');
            if (!str_contains(strtolower($policy), 'frame-ancestors')) {
                $response->headers->set('Content-Security-Policy', rtrim($policy, '; ') . ($policy ? '; ' : '') . "frame-ancestors 'self'");
            }
        }
        return $response;
    }
}
