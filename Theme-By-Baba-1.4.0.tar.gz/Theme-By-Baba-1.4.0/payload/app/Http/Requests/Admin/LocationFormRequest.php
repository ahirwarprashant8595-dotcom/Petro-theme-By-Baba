<?php

namespace Pterodactyl\Http\Requests\Admin;

use Pterodactyl\Models\Location;

class LocationFormRequest extends AdminFormRequest
{
    /**
     * Set up the validation rules to use for these requests.
     */
    public function rules(): array
    {
        if ($this->method() === 'PATCH') {
            return array_merge(Location::getRulesForUpdate($this->route()->parameter('location')->id), ['country_code' => ['nullable', \Illuminate\Validation\Rule::in(array_keys(\Pterodactyl\Services\Locations\LocationCountry::countries()))]]); // @phpstan-ignore property.nonObject
        }

        return array_merge(Location::getRules(), ['country_code' => ['nullable', \Illuminate\Validation\Rule::in(array_keys(\Pterodactyl\Services\Locations\LocationCountry::countries()))]]);
    }
}
