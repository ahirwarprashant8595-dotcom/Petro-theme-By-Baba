<?php
namespace Pterodactyl\Http\Requests\Api\Client\Servers\Startup;
use Pterodactyl\Models\Permission;
use Pterodactyl\Http\Requests\Api\Client\ClientApiRequest;
class UpdateStartupCommandRequest extends ClientApiRequest
{
    public function permission(): string { return Permission::ACTION_STARTUP_UPDATE; }
    public function rules(): array
    {
        return ['command' => 'required_unless:reset,true|string|min:1|max:10000', 'reset' => 'sometimes|boolean'];
    }
}
