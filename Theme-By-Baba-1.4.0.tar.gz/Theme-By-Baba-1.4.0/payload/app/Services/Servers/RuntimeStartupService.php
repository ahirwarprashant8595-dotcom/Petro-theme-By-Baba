<?php
namespace Pterodactyl\Services\Servers;
use Pterodactyl\Models\Egg;
class RuntimeStartupService {
 public static function resolve(Egg $egg,?string $startup):string {
  if(!$startup || !trim($startup))return $egg->startup;
  if($startup===$egg->startup)return $startup;
  $legacy='if [ -f ./{{REQUIREMENTS_FILE}} ]; then pip install --no-cache-dir -r {{REQUIREMENTS_FILE}}; fi; python3 {{STARTUP_FILE}}';
  $foreign=Egg::where('id','!=',$egg->id)->where('startup',$startup)->exists();
  if($foreign || $startup===$legacy)return $egg->startup;
  return $startup;
 }
}
