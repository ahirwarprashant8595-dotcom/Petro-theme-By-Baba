<?php
namespace Pterodactyl\Services\Minecraft;
use Illuminate\Support\Facades\Http;
class CatalogService
{
    public const AGENT = 'BABAHostPanel/1.0 (https://panel.itzmebaba.in)';
    public function json(string $url, array $query = []): array
    {
        $response = Http::withHeaders(['User-Agent'=>self::AGENT, 'Accept'=>'application/json'])->connectTimeout(5)->timeout(20)->get($url, $query);
        abort_unless($response->successful(), 502, 'The download provider is unavailable. Please try again.');
        $data = $response->json(); abort_unless(is_array($data), 502, 'Invalid response from download provider.'); return $data;
    }
    public function softwareVersions(string $kind): array
    {
        return cache()->remember('mc-catalog-versions:'.$kind, 300, function () use ($kind) {
            if ($kind === 'paper') { $data=$this->json('https://fill.papermc.io/v3/projects/paper'); return array_values(array_filter(array_merge(...array_values($data['versions'] ?? [])), fn($v)=>preg_match('/^\d+(?:\.\d+){1,2}$/',$v))); }
            if ($kind === 'purpur') { return array_reverse($this->json('https://api.purpurmc.org/v2/purpur')['versions'] ?? []); }
            if ($kind === 'vanilla') { return array_values(array_map(fn($v)=>$v['id'], array_filter($this->json('https://piston-meta.mojang.com/mc/game/version_manifest_v2.json')['versions'] ?? [], fn($v)=>$v['type']==='release'))); }
            if ($kind === 'fabric') { return array_values(array_column(array_filter($this->json('https://meta.fabricmc.net/v2/versions/game'),fn($v)=>$v['stable'] ?? false),'version')); }
            abort(422, 'Unknown server software.');
        });
    }
    public function resolveSoftware(string $kind, string $version): array
    {
        abort_unless(in_array($version, $this->softwareVersions($kind), true), 422, 'Choose an available stable version.');
        if ($kind === 'paper') {
            $builds = $this->json('https://fill.papermc.io/v3/projects/paper/versions/'.rawurlencode($version).'/builds');
            $build = collect($builds)->first(fn($b)=>in_array(strtoupper($b['channel'] ?? ''),['STABLE','RECOMMENDED'],true) && isset($b['downloads']['server:default']['url']));
            abort_unless($build, 422, 'No stable build is available for this version.'); $d=$build['downloads']['server:default'];
            return ['url'=>$d['url'],'filename'=>$d['name'],'version'=>$version,'build'=>(string)$build['id'],'sha256'=>$d['checksums']['sha256'] ?? null];
        }
        if ($kind === 'purpur') {
            $d=$this->json('https://api.purpurmc.org/v2/purpur/'.$version.'/latest');abort_unless(isset($d['build']),502,'No Purpur build available.');
            return ['url'=>'https://api.purpurmc.org/v2/purpur/'.$version.'/'.$d['build'].'/download','filename'=>'purpur-'.$version.'-'.$d['build'].'.jar','version'=>$version,'build'=>(string)$d['build']];
        }
        if ($kind === 'vanilla') {
            $manifest=$this->json('https://piston-meta.mojang.com/mc/game/version_manifest_v2.json');$v=collect($manifest['versions'])->firstWhere('id',$version);$this->allowUrl($v['url'],['piston-meta.mojang.com','launchermeta.mojang.com']);$d=$this->json($v['url'])['downloads']['server'] ?? null;abort_unless($d,422,'No server download for this version.');
            return ['url'=>$d['url'],'filename'=>'vanilla-'.$version.'.jar','version'=>$version,'build'=>'release','sha1'=>$d['sha1'] ?? null];
        }
        $loaders=$this->json('https://meta.fabricmc.net/v2/versions/loader/'.$version);$loader=collect($loaders)->first(fn($l)=>$l['loader']['stable'] ?? false)['loader']['version'] ?? null;
        $installer=collect($this->json('https://meta.fabricmc.net/v2/versions/installer'))->first(fn($i)=>$i['stable'] ?? false)['version'] ?? null;abort_unless($loader && $installer,422,'No stable Fabric loader for this version.');
        return ['url'=>'https://meta.fabricmc.net/v2/versions/loader/'.$version.'/'.$loader.'/'.$installer.'/server/jar','filename'=>'fabric-'.$version.'-'.$loader.'.jar','version'=>$version,'build'=>$loader];
    }
    public function pluginSearch(string $query, string $loader, string $version, int $offset): array
    {
        $loaders=$loader==='paper' ? ['paper','spigot','bukkit'] : ($loader==='spigot'?['spigot','bukkit']:[$loader]);
        $facets=[[in_array($loader,['forge','fabric','neoforge'],true)?'project_type:mod':'project_type:plugin'],array_map(fn($l)=>'categories:'.$l,$loaders),['versions:'.$version]];
        $d=$this->json('https://api.modrinth.com/v2/search',['query'=>$query,'facets'=>json_encode($facets),'limit'=>12,'offset'=>$offset,'index'=>'downloads']);
        return ['total'=>(int)($d['total_hits'] ?? 0),'items'=>array_map(fn($p)=>['id'=>$p['project_id'],'slug'=>$p['slug'],'title'=>$p['title'],'description'=>$p['description'],'author'=>$p['author'],'downloads'=>$p['downloads'],'icon'=>$this->safeIcon($p['icon_url'] ?? null)],$d['hits'] ?? [])];
    }
    public function pluginVersions(string $project, string $loader, string $version): array
    {
        $loaders=$loader==='paper' ? ['paper','spigot','bukkit'] : ($loader==='spigot'?['spigot','bukkit']:[$loader]);
        $versions=$this->json('https://api.modrinth.com/v2/project/'.rawurlencode($project).'/version',['loaders'=>json_encode($loaders),'game_versions'=>json_encode([$version]),'include_changelog'=>'false']);
        return array_values(array_map(fn($v)=>['id'=>$v['id'],'name'=>$v['name'],'number'=>$v['version_number'],'published'=>$v['date_published'],'game_versions'=>$v['game_versions'],'loaders'=>$v['loaders'],'dependencies'=>array_values(array_filter($v['dependencies'] ?? [],fn($d)=>$d['dependency_type']==='required'))],array_filter($versions,fn($v)=>($v['version_type'] ?? '')==='release')));
    }
    public function resolvePlugin(string $project, string $id, string $loader, string $gameVersion): array
    {
        $v=$this->json('https://api.modrinth.com/v2/version/'.rawurlencode($id));
        abort_unless(($v['project_id'] ?? '')===$project && ($v['version_type'] ?? '')==='release',422,'Select a stable version from this project.');
        $loaders=$loader==='paper' ? ['paper','spigot','bukkit'] : ($loader==='spigot'?['spigot','bukkit']:[$loader]);
        abort_unless(in_array($gameVersion,$v['game_versions'] ?? [],true) && count(array_intersect($loaders,$v['loaders'] ?? [])),422,'This plugin version is not compatible with the selected server type and game version.');
        $file=collect($v['files'] ?? [])->first(fn($f)=>($f['primary'] ?? false) && str_ends_with(strtolower($f['filename']),'.jar')) ?? collect($v['files'] ?? [])->first(fn($f)=>str_ends_with(strtolower($f['filename']),'.jar'));
        abort_unless($file,422,'No installable JAR file in this release.');
        return ['url'=>$file['url'],'filename'=>$project.'-'.$id.'-'.basename($file['filename']),'version'=>$v['version_number'],'dependencies'=>array_values(array_filter($v['dependencies'] ?? [],fn($d)=>$d['dependency_type']==='required'))];
    }
    public function allowUrl(string $url, ?array $hosts=null): void
    {
        $hosts ??= ['fill-data.papermc.io','downloads.papermc.io','api.purpurmc.org','piston-data.mojang.com','launcher.mojang.com','meta.fabricmc.net','cdn.modrinth.com'];
        abort_unless(parse_url($url,PHP_URL_SCHEME)==='https' && in_array(strtolower(parse_url($url,PHP_URL_HOST) ?? ''),$hosts,true) && !parse_url($url,PHP_URL_USER) && !parse_url($url,PHP_URL_PASS),422,'The provider returned an unsupported download host.');
    }
    private function safeIcon(?string $url): ?string { return $url && parse_url($url,PHP_URL_SCHEME)==='https' && parse_url($url,PHP_URL_HOST)==='cdn.modrinth.com' ? $url : null; }
}
