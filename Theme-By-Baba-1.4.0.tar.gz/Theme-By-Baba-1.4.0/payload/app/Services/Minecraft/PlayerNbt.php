<?php
namespace Pterodactyl\Services\Minecraft;
class PlayerNbt
{
    private string $data=''; private int $offset=0; private int $nodes=0;
    public function decode(string $data): array
    {
        if (str_starts_with($data,"\x1f\x8b")) { $data=@gzdecode($data,4194304); }
        if (!is_string($data) || strlen($data)>4194304) throw new \RuntimeException('Player data is too large or invalid.');
        $this->data=$data;$this->offset=0;$this->nodes=0;
        if ($this->byte()!==10) throw new \RuntimeException('Invalid player data root.');
        $this->text();return $this->tag(10,0);
    }
    private function take(int $n): string { if($n<0 || $this->offset+$n>strlen($this->data))throw new \RuntimeException('Incomplete player data.');$s=substr($this->data,$this->offset,$n);$this->offset+=$n;return $s; }
    private function byte(): int { return ord($this->take(1)); }
    private function text(): string { return $this->take(unpack('n',$this->take(2))[1]); }
    private function length(): int { $n=unpack('N',$this->take(4))[1];if($n>100000)throw new \RuntimeException('Player collection is too large.');return $n; }
    private function tag(int $type,int $depth): mixed
    {
        if($depth>32 || ++$this->nodes>100000)throw new \RuntimeException('Player data nesting limit.');
        switch($type){
            case 1:$v=$this->byte();return $v>127?$v-256:$v;
            case 2:$v=unpack('n',$this->take(2))[1];return $v>32767?$v-65536:$v;
            case 3:$v=unpack('N',$this->take(4))[1];return $v>2147483647?$v-4294967296:$v;
            case 4:return unpack('J',$this->take(8))[1];
            case 5:return unpack('G',$this->take(4))[1];
            case 6:return unpack('E',$this->take(8))[1];
            case 7:return $this->take($this->length());
            case 8:return $this->text();
            case 9:$child=$this->byte();$n=$this->length();if($child<1 || $child>12){if($n===0)return [];throw new \RuntimeException('Invalid player list.');}$out=[];for($i=0;$i<$n;$i++)$out[]=$this->tag($child,$depth+1);return $out;
            case 10:$out=[];while(($child=$this->byte())!==0){$name=$this->text();$out[$name]=$this->tag($child,$depth+1);}return $out;
            case 11:$n=$this->length();$this->take($n*4);return [];
            case 12:$n=$this->length();$this->take($n*8);return [];
            default:throw new \RuntimeException('Unknown player data tag.');
        }
    }
}
