<?php
namespace Pterodactyl\Services\Minecraft;
use Pterodactyl\Models\Server;
use Pterodactyl\Repositories\Wings\{DaemonFileRepository,DaemonCommandRepository};
use Illuminate\Support\Facades\Cache;
class LivePlayerRoster {
 public function __construct(private DaemonFileRepository $files,private DaemonCommandRepository $commands){}
 public static function parse(string $text):?array {
  $text=preg_replace('/\x1b\[[0-9;]*m|§./u','',$text);
  if(!preg_match_all('/There are (\d+) of a max(?:imum)?(?: of)? (\d+) players online:[ \t]*([^\r\n]*)/i',$text,$matches,PREG_SET_ORDER))return null;
  $last=end($matches);$names=array_filter(array_map('trim',explode(',',$last[3])));$players=[];
  foreach($names as $name){if(!preg_match('/^[a-zA-Z0-9_]{1,16}$/',$name))return null;$players[]=['name'=>$name];}
  if(count($players)!==(int)$last[1])return null;
  return ['available'=>true,'online'=>(int)$last[1],'max'=>(int)$last[2],'players'=>$players,'source'=>'live server list'];
 }
 public function query(Server $s):?array {
  return Cache::remember('minecraft-roster:'.$s->uuid,8,function()use($s){
   $lock=Cache::lock('minecraft-roster-lock:'.$s->uuid,10);if(!$lock->get())return null;
   try{$repo=$this->files->setServer($s);$before=$repo->getContent('/logs/latest.log',4194304);$this->commands->setServer($s)->send('minecraft:list');
    for($attempt=0;$attempt<3;$attempt++){usleep(200000);$after=$repo->getContent('/logs/latest.log',4194304);if(str_starts_with($after,$before)){$result=self::parse(substr($after,strlen($before)));if($result)return $result;}}
   }catch(\Throwable $e){}finally{$lock->release();}return null;
  });
 }
}
