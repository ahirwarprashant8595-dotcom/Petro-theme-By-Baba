<?php
namespace Pterodactyl\Services\Minecraft;
use Pterodactyl\Models\Server;
class MinecraftAccess
{
    public static function capabilities(Server $server): array
    {
        $installed=app(SoftwareInstallation::class)->installed($server);
        $egg = strtolower(trim($installed['software'] ?? $server->egg->name ?? ''));
        $nest = strtolower($server->egg->nest->name ?? '');
        $image = strtolower($server->image ?? '');
        $minecraft = !preg_match('/python|nodejs|node_/', $image) && (str_contains($nest, 'minecraft') || (bool) preg_match('/^(paper(?:mc)?|spigot|vanilla|minecraft|purpur|fabric|forge|neoforge|bungeecord|waterfall|velocity|bedrock|folia)(?:\b|\s)/', $egg));
        $paper = $minecraft && (bool) preg_match('/\bpaper(?:mc)?\b/', $egg);
        $spigot = $minecraft && (bool) preg_match('/\bspigot\b/', $egg);
        $modLoader=$minecraft?(preg_match('/neoforge/i',$egg)?'neoforge':(preg_match('/fabric/i',$egg)?'fabric':(preg_match('/forge/i',$egg)?'forge':null))):null;
        return ['mods'=>$modLoader!==null,'mod_loader'=>$modLoader,'minecraft'=>$minecraft, 'options'=>$minecraft && !preg_match('/bungee|waterfall|velocity|bedrock/i', $egg), 'plugins'=>$paper || $spigot, 'loader'=>$paper ? 'paper' : ($spigot ? 'spigot' : null)];
    }
    public static function requireMinecraft(Server $server): void { abort_unless(self::capabilities($server)['minecraft'], 403, 'Minecraft tools are unavailable for this Egg.'); }
    public static function requirePlugins(Server $server): void { abort_unless(self::capabilities($server)['plugins'], 403, 'Plugin installation is only available for Paper and Spigot Eggs.'); }
}
