<?php
namespace Pterodactyl\Services\Minecraft;
class PropertiesOptions
{
    public const DEFAULTS = ['max-players'=>20,'gamemode'=>'survival','difficulty'=>'easy','white-list'=>false,'online-mode'=>true,'allow-flight'=>false,'force-gamemode'=>false,'spawn-protection'=>16,'require-resource-pack'=>false,'resource-pack'=>'','resource-pack-prompt'=>'','pvp'=>true,'view-distance'=>10,'simulation-distance'=>10,'motd'=>'A Minecraft Server'];
    public function read(string $text): array
    {
        $values=self::DEFAULTS;$explicit=[];
        foreach(preg_split('/\r\n|\n|\r/',$text) as $line){
            if(preg_match('/^\s*([a-z][a-z0-9-]*)(?:\s*[:=]\s*|\s+)(.*)$/i',$line,$m) && array_key_exists($m[1],$values)){
                $key=$m[1];$value=$this->decode($m[2]);$explicit[]=$key;
                $values[$key]=is_bool(self::DEFAULTS[$key])?strtolower($value)==='true':(is_int(self::DEFAULTS[$key])?(int)$value:$value);
            }
        }
        return ['options'=>$values,'explicit_keys'=>array_values(array_unique($explicit)),'revision'=>hash('sha256',$text)];
    }
    public function update(string $text,array $changes): string
    {
        foreach($changes as $key=>$v){if(!array_key_exists($key,self::DEFAULTS))throw new \InvalidArgumentException('Unknown server option.');}
        $newline=str_contains($text,"\r\n")?"\r\n":"\n";$lines=preg_split('/\r\n|\n|\r/',$text);$seen=[];
        foreach($lines as &$line){if(preg_match('/^\s*([a-z][a-z0-9-]*)(?:\s*[:=]\s*|\s+)(.*)$/i',$line,$m) && array_key_exists($m[1],$changes)){$line=$m[1].'='.$this->encode($changes[$m[1]]);$seen[$m[1]]=true;}}
        unset($line);while(count($lines)&&end($lines)==='')array_pop($lines);
        foreach($changes as $key=>$v){if(!isset($seen[$key]))$lines[]=$key.'='.$this->encode($v);}
        return implode($newline,$lines).$newline;
    }
    private function encode(mixed $value): string
    {
        if(is_bool($value))return $value?'true':'false';if(is_int($value)||is_float($value))return (string)$value;
        $value=strtr((string)$value,['\\'=>'\\\\',"\n"=>'\\n',"\r"=>'\\r',"\t"=>'\\t',"\f"=>'\\f']);
        return preg_replace_callback('/[^\x00-\x7F]/u',function($m){$words=unpack('n*',mb_convert_encoding($m[0],'UTF-16BE','UTF-8'));return implode('',array_map(fn($n)=>sprintf('\\u%04X',$n),$words));},$value);
    }
    private function decode(string $value): string
    {
        $value=preg_replace_callback('/(?:\\\\u[0-9a-fA-F]{4})+/',function($m){preg_match_all('/\\\\u([0-9a-fA-F]{4})/',$m[0],$matches);return mb_convert_encoding(pack('n*',...array_map('hexdec',$matches[1])),'UTF-8','UTF-16BE');},$value);
        return strtr($value,['\\n'=>"\n",'\\r'=>"\r",'\\t'=>"\t",'\\f'=>"\f",'\\='=>'=','\\:'=>':','\\\\'=>'\\']);
    }
}
