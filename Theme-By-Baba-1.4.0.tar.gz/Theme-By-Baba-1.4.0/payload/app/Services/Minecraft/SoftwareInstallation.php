<?php
namespace Pterodactyl\Services\Minecraft;
use Pterodactyl\Models\{Server,ServerVariable};
use Pterodactyl\Repositories\Wings\{DaemonFileRepository,DaemonServerRepository};
use Pterodactyl\Contracts\Repository\SettingsRepositoryInterface;
use Illuminate\Support\Facades\{Cache,DB,Validator};
class SoftwareInstallation {
 public function __construct(private DaemonFileRepository $files,private DaemonServerRepository $daemon,private SettingsRepositoryInterface $settings){}
 private function key(Server $s):string{return 'settings::mc-installed:'.$s->uuid;}
 public static function fingerprint(array $f):string{return hash('sha256',json_encode([$f['size']??0,$f['modified']??$f['modified_at']??'']));}
 public static function fromFilename(string $name):?array {if(preg_match('/^(paper|purpur|vanilla|fabric)-(\d+(?:\.\d+){1,3})(?:-([a-zA-Z0-9._-]+))?\.jar$/i',$name,$m))return ['software'=>strtolower($m[1]),'version'=>$m[2],'build'=>$m[3]??null];return null;}
 public function installed(Server $s):?array {
  if(!preg_match('/minecraft|paper|spigot|bungee|velocity|purpur|fabric|forge|bedrock/i',($s->egg->nest->name??'').' '.($s->egg->name??'')))return null;
  return Cache::remember('mc-installed:'.$s->uuid,5,function()use($s){try{
   $var=$s->variables->firstWhere('env_variable','SERVER_JARFILE');$path=ltrim((string)($var?->server_value ?: $var?->default_value ?: 'server.jar'),'/');
   if(!preg_match('/^[a-zA-Z0-9._\/-]+\.jar$/',$path)||str_contains($path,'..'))return null;
   $dir=dirname('/'.$path);$entry=collect($this->files->setServer($s)->getDirectory($dir))->firstWhere('name',basename($path));if(!$entry || !($entry['file']??false) || ($entry['size']??0)<4)return null;
   $saved=json_decode($this->settings->get($this->key($s),'{}'),true)?:[];
   if(($saved['path']??null)==='/'.$path && ($saved['fingerprint']??null)===self::fingerprint($entry))return array_diff_key($saved,['fingerprint'=>true]);
   $inferred=self::fromFilename(basename($path));return $inferred ? array_merge($inferred,['path'=>'/'.$path,'source'=>'jar filename','verified_download'=>false]) : null;
  }catch(\Throwable $e){return null;}});
 }
 private function offline(Server $s):void {$d=$this->daemon->setServer($s)->getDetails();abort_unless(in_array($d['state']??'', ['offline','stopped'],true),409,'Stop the server before installing software.');}
 public function install(Server $s,string $kind,array $d):array {
  $var=$s->variables->firstWhere('env_variable','SERVER_JARFILE');abort_unless($var && $var->user_editable,422,'This Egg does not expose an editable Server Jar File. Ask an administrator to configure a Java server Egg.');
  Validator::make(['jar'=>'server.jar'],['jar'=>$var->rules])->validate();
  $lock=Cache::lock('mc-download:'.$s->uuid,240);abort_unless($lock->get(),409,'Another download is in progress.');$temp='.baba-install-'.bin2hex(random_bytes(8)).'.jar';$backup=null;$promoted=false;
  try{
   $this->offline($s);$repo=$this->files->setServer($s);$repo->pull($d['url'],'/',['filename'=>$temp,'foreground'=>true]);
   $entry=collect($repo->getDirectory('/'))->firstWhere('name',$temp);abort_unless($entry && ($entry['size']??0)>4,502,'The node did not confirm the downloaded jar.');
   $response=$repo->getHttpClient()->get('/api/servers/'.$s->uuid.'/files/contents',['query'=>['file'=>'/'.$temp],'stream'=>true]);$body=$response->getBody();$magic=$body->read(4);abort_unless(str_starts_with($magic,"PK"),502,'The provider did not return a valid jar.');$algorithm=isset($d['sha256'])?'sha256':(isset($d['sha1'])?'sha1':'sha256');$hash=hash_init($algorithm);hash_update($hash,$magic);$bytes=strlen($magic);while(!$body->eof()){$chunk=$body->read(65536);$bytes+=strlen($chunk);abort_if($bytes>536870912,502,'Downloaded jar exceeds the supported size.');hash_update($hash,$chunk);}$actual=hash_final($hash);$body->close();abort_unless($bytes===(int)$entry['size'],502,'Downloaded jar is incomplete.');if(!empty($d[$algorithm]))abort_unless(hash_equals(strtolower($d[$algorithm]),$actual),502,'Jar checksum verification failed.');
   $this->offline($s);$root=$repo->getDirectory('/');$old=collect($root)->firstWhere('name','server.jar');if($old){abort_unless($old['file']??false,409,'server.jar is a directory.');$backup='server.jar.baba-'.gmdate('Ymd-His').'-'.bin2hex(random_bytes(3)).'.bak';$repo->renameFiles('/',[['from'=>'server.jar','to'=>$backup]]);}
   try{
    $repo->renameFiles('/',[['from'=>$temp,'to'=>'server.jar']]);$promoted=true;$saved=collect($repo->getDirectory('/'))->firstWhere('name','server.jar');abort_unless($saved && (int)$saved['size']===$bytes,502,'Installed jar verification failed.');
    $record=['software'=>$kind,'version'=>$d['version'],'build'=>$d['build']??null,'path'=>'/server.jar','fingerprint'=>self::fingerprint($saved),'source'=>'verified provider download','verified_download'=>true,'installed_at'=>gmdate(DATE_ATOM)];
    DB::transaction(function()use($s,$var,$record){ServerVariable::query()->updateOrCreate(['server_id'=>$s->id,'variable_id'=>$var->id],['variable_value'=>'server.jar']);$this->settings->set($this->key($s),json_encode($record,JSON_THROW_ON_ERROR));});
   }catch(\Throwable $e){if($promoted)$repo->renameFiles('/',[['from'=>'server.jar','to'=>$temp]]);if($backup)$repo->renameFiles('/',[['from'=>$backup,'to'=>'server.jar']]);throw $e;}
   foreach(['mc-installed:','minecraft-status:','resources:'] as $prefix)Cache::forget($prefix.$s->uuid);
   return ['path'=>'/server.jar','filename'=>'server.jar','software'=>$kind,'version'=>$d['version'],'backup'=>$backup?'/'.$backup:null,'restart_required'=>true];
  }finally{try{$this->files->setServer($s)->deleteFiles('/',[$temp]);}catch(\Throwable $e){}$lock->release();}
 }
}
