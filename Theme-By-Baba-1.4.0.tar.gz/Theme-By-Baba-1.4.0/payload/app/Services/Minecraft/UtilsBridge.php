<?php
namespace Pterodactyl\Services\Minecraft;
use Pterodactyl\Models\Server;
use Pterodactyl\Repositories\Wings\{DaemonFileRepository,DaemonServerRepository,DaemonCommandRepository};
class UtilsBridge {
 public const ROOT='/plugins/BabaUtilsBridge';
 public function state(Server $s):?array {
  try{$data=json_decode(app(DaemonFileRepository::class)->setServer($s)->getContent(self::ROOT.'/state.json',1048576),true);return is_array($data)&&($data['schema']??0)===1&&abs(microtime(true)*1000-($data['generated_at']??0))<20000?$data:null;}catch(\Throwable $e){return null;}
 }
 public function player(Server $s,string $uuid):?array {
  if(!$this->state($s))return null;
  try{$p=json_decode(app(DaemonFileRepository::class)->setServer($s)->getContent(self::ROOT.'/players/'.$uuid.'.json',1048576),true);return is_array($p)&&($p['uuid']??'')===$uuid&&abs(microtime(true)*1000-($p['generated_at']??0))<20000?$p:null;}catch(\Throwable $e){return null;}
 }
 public function command(Server $s,string $command):void {abort_unless($this->state($s),409,'Install BABA Utils Bridge and start the server to use live controls.');app(DaemonCommandRepository::class)->setServer($s)->send([$command]);}
 public function install(Server $s):array {
  MinecraftAccess::requirePlugins($s);app(\Pterodactyl\Services\Customization\ServerCustomization::class)->offline($s);$f=app(DaemonFileRepository::class)->setServer($s);
  $root=collect($f->getDirectory('/'));$folder=$root->firstWhere('name','plugins');if(!$folder)$f->createDirectory('plugins','/');else abort_if($folder['file']??false,409,'plugins is a file, not a directory.');
  $name='BabaUtilsBridge-1.0.0.jar';$exists=collect($f->getDirectory('/plugins'))->firstWhere('name',$name);if($exists)return ['message'=>'Bridge JAR already exists. Start the server to activate it.'];
  $jar=file_get_contents(public_path('assets/minecraft/'.$name));$f->putContent('/plugins/'.$name,$jar);return ['message'=>'Bridge installed. Start the server to enable real-time player controls and world maps.'];
 }
}
