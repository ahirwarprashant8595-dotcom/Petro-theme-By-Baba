<?php
namespace Pterodactyl\Services\Locations;
use Pterodactyl\Models\Location;
use Pterodactyl\Contracts\Repository\SettingsRepositoryInterface;
class LocationCountry
{
    public static function countries():array {static $list;return $list??=json_decode(file_get_contents(resource_path('data/countries.json')),true);}
    public static function code(Location $l):?string {
        $saved=app(SettingsRepositoryInterface::class)->get('settings::location-country:'.$l->id,'');
        return isset(self::countries()[$saved])?$saved:null;
    }
    public static function save(Location $l,?string $code):void {app(SettingsRepositoryInterface::class)->set('settings::location-country:'.$l->id,$code??'');}
}
