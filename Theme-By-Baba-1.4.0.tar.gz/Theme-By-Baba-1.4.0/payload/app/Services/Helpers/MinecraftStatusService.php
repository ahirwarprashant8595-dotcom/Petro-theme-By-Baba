<?php

namespace Pterodactyl\Services\Helpers;

use Pterodactyl\Models\Server;

class MinecraftStatusService
{
    public function isMinecraft(Server $server): bool
    {
        return (bool) preg_match('/minecraft|paper|spigot|bungeecord|waterfall|velocity|purpur|fabric|forge|bedrock/i', ($server->egg->nest->name ?? '') . ' ' . ($server->egg->name ?? ''));
    }

    public function query(Server $server): ?array
    {
        if (!$this->isMinecraft($server)) {
            return null;
        }
        return cache()->remember('minecraft-status:' . $server->uuid, 5, function () use ($server) {
            $socket = null;
            try {
                $host = $server->allocation->ip;
                if ($host === '0.0.0.0' || $host === '::') {
                    $alias = trim((string) $server->allocation->ip_alias);
                    $host = $alias && (filter_var($alias, FILTER_VALIDATE_IP) || filter_var($alias,FILTER_VALIDATE_DOMAIN,FILTER_FLAG_HOSTNAME)) ? $alias : $server->node->fqdn;
                }
                $port = (int) $server->allocation->port;
                $address = filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) ? '[' . $host . ']' : $host;
                $socket = @stream_socket_client('tcp://' . $address . ':' . $port, $errno, $errstr, 0.7);
                if (!$socket) {
                    return ['available' => false];
                }
                stream_set_timeout($socket, 0, 700000);
                $packet = chr(0) . $this->varint(767) . $this->varint(strlen($host)) . $host . pack('n', $port) . chr(1);
                $request = $this->varint(strlen($packet)) . $packet . chr(1) . chr(0);
                if (fwrite($socket, $request) !== strlen($request)) {
                    return ['available' => false];
                }
                $deadline = microtime(true) + 0.8;
                $packetLength = $this->readVarint($socket, $deadline);
                if ($packetLength < 3 || $packetLength > 262144 || $this->readVarint($socket, $deadline) !== 0) {
                    return ['available' => false];
                }
                $length = $this->readVarint($socket, $deadline);
                if ($length < 2 || $length > $packetLength || $length > 262144) {
                    return ['available' => false];
                }
                $json = '';
                while (strlen($json) < $length && microtime(true) < $deadline) {
                    $chunk = fread($socket, $length - strlen($json));
                    if ($chunk === false || $chunk === '') { break; }
                    $json .= $chunk;
                }
                $data = json_decode($json, true);
                if (strlen($json) !== $length || !is_array($data) || !isset($data['players']['online'], $data['players']['max'])) {
                    return ['available' => false];
                }
                return [
                    'available' => true,
                    'players' => array_values(array_filter(array_slice($data['players']['sample'] ?? [], 0, 100), fn ($p) => is_array($p) && preg_match('/^[a-zA-Z0-9_]{1,16}$/', $p['name'] ?? ''))),
                    'online' => max(0, (int) $data['players']['online']),
                    'max' => max(0, (int) $data['players']['max']),
                    'version' => mb_substr(strip_tags((string) ($data['version']['name'] ?? '')), 0, 100),
                ];
            } catch (\Throwable $exception) {
                return ['available' => false];
            } finally {
                if (is_resource($socket)) { fclose($socket); }
            }
        });
    }

    private function varint(int $value): string
    {
        $result = '';
        do {
            $byte = $value & 127;
            $value >>= 7;
            $result .= chr($byte | ($value ? 128 : 0));
        } while ($value);
        return $result;
    }

    private function readVarint($socket, float $deadline): int
    {
        $value = 0;
        for ($i = 0; $i < 5 && microtime(true) < $deadline; $i++) {
            $byte = fread($socket, 1);
            if ($byte === false || $byte === '') { throw new \RuntimeException('Status response incomplete'); }
            $byte = ord($byte);
            $value |= ($byte & 127) << ($i * 7);
            if (($byte & 128) === 0) { return $value; }
        }
        throw new \RuntimeException('Invalid status response');
    }
}
