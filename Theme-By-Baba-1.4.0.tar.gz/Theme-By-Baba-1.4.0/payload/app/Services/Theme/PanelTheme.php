<?php
namespace Pterodactyl\Services\Theme;
use Pterodactyl\Contracts\Repository\SettingsRepositoryInterface;
class PanelTheme {
    public function __construct(private SettingsRepositoryInterface $settings) {}
    public function defaults(): array { return ['name'=>'BABA HOST','accent'=>'#7f50f2','background'=>'#09090b','surface'=>'#111113','sidebar'=>'#0d0d10','text'=>'#f4f4f5','muted'=>'#9999a4','border'=>'#2b2b30','logo'=>'/assets/baba_cube_logo.png','icon'=>'','wallpaper'=>'','footer'=>'','footer_url'=>'','radius'=>12,'companion'=>true,'card_style'=>'banner','nav_style'=>'outline','density'=>'comfortable','stats_style'=>'default','announcement_enabled'=>false,'announcement'=>'','announcement_color'=>'#7f50f2','announcement_icon'=>'info','announcement_dismissible'=>true,'cta_label'=>'','cta_url'=>'','support_label'=>'Support','support_url'=>'','discord_url'=>'']; }
    public function get(): array { return array_replace($this->defaults(), json_decode($this->settings->get('settings::panel:theme', '{}'),true) ?: []); }
    public function save(array $data): void { \Illuminate\Support\Facades\DB::transaction(function () use ($data) { $this->settings->set('settings::panel:theme',json_encode($data,JSON_THROW_ON_ERROR)); $this->settings->set('settings::app:name',$data['name']); }); }
}
