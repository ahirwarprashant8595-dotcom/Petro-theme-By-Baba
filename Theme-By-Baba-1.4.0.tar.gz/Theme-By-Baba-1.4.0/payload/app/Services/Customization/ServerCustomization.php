<?php
namespace Pterodactyl\Services\Customization;
use Pterodactyl\Models\{Server,Egg,ServerVariable};
use Pterodactyl\Contracts\Repository\SettingsRepositoryInterface;
use Pterodactyl\Repositories\Wings\DaemonServerRepository;
use Illuminate\Support\Facades\{DB,Cache,Validator};
class ServerCustomization
{
    public const EGGS=[15,16];
    public function eligible(Server $s):bool{return in_array($s->egg_id,self::EGGS,true);}
    public static function artwork(Server $s,string $kind):?string {
        $saved=json_decode(app(SettingsRepositoryInterface::class)->get('settings::server-art:'.$s->uuid,'{}'),true)?:[];
        return $saved[$kind]??($s->egg?->{$kind.'_image'}?:null);
    }
    public function offline(Server $s):void {
        $state=app(DaemonServerRepository::class)->setServer($s)->getDetails()['state']??'';
        abort_unless(in_array($state,['offline','stopped'],true),409,'Stop the server before changing its Egg or importing code.');
    }
    public function switchEgg(Server $s,int $id):void {
        abort_unless($this->eligible($s)&&in_array($id,self::EGGS,true),422,'Only Node.js and Python Eggs can be switched here.');
        $lock=Cache::lock('baba-runtime:'.$s->uuid,180);abort_unless($lock->get(),409,'Another server setup task is running.');
        try {
            $this->offline($s);$egg=Egg::findOrFail($id);if($id===$s->egg_id)return;
            $image=array_values($egg->docker_images)[0]??null;abort_unless($image,422,'Target Egg has no Docker image configured.');
            $values=[];foreach($egg->variables as $v){$values[$v->env_variable]=$v->default_value;}
            $rules=[];foreach($egg->variables as $v)$rules[$v->env_variable]=$v->rules;Validator::make($values,$rules)->validate();
            $old=$s->only(['egg_id','nest_id','startup','image']);$oldVariables=ServerVariable::where('server_id',$s->id)->get()->map->only(['server_id','variable_id','variable_value'])->all();
            DB::transaction(function()use($s,$egg,$image,$values){
                $s->forceFill(['egg_id'=>$egg->id,'nest_id'=>$egg->nest_id,'startup'=>$egg->startup,'image'=>$image])->saveOrFail();
                ServerVariable::where('server_id',$s->id)->delete();
                foreach($egg->variables as $v)ServerVariable::create(['server_id'=>$s->id,'variable_id'=>$v->id,'variable_value'=>$values[$v->env_variable]]);
            });
            try {app(DaemonServerRepository::class)->setServer($s->fresh())->sync();}
            catch(\Throwable $e){DB::transaction(function()use($s,$old,$oldVariables){$s->forceFill($old)->saveOrFail();ServerVariable::where('server_id',$s->id)->delete();foreach($oldVariables as $v)ServerVariable::create($v);});try{app(DaemonServerRepository::class)->setServer($s->fresh())->sync();}catch(\Throwable $retry){report($retry);}throw $e;}
        } finally {$lock->release();}
    }
}
