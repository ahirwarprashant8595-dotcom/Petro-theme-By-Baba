<?php
namespace Pterodactyl\Services\Customization;
use GuzzleHttp\Client;
use Pterodactyl\Models\Server;
use Pterodactyl\Repositories\Wings\DaemonFileRepository;
use Illuminate\Support\Facades\Cache;
class GitHubImport
{
    public static function repository(string $url): array {
        abort_unless(preg_match('~\Ahttps://github\.com/([A-Za-z0-9-]{1,39})/([A-Za-z0-9_.-]{1,100})/?\z~i',trim($url),$m),422,'Enter a public repository URL: https://github.com/owner/repository');
        $repo=preg_replace('/\.git$/i','',$m[2]);abort_if(in_array($repo,['.','..',''],true),422,'Invalid repository.');return [$m[1],$repo];
    }
    public static function inspect(string $path): string {
        $zip=new \ZipArchive;abort_unless($zip->open($path)===true,422,'GitHub did not return a valid ZIP archive.');
        try {
            abort_if($zip->numFiles>5000 || $zip->numFiles<1,422,'Repository exceeds the 5,000 entry limit.');$total=0;$prefix=null;
            for($i=0;$i<$zip->numFiles;$i++){
                $e=$zip->statIndex($i);$name=$e['name'];
                abort_if(str_contains($name,'\\') || preg_match('/[\x00-\x1f:]/',$name) || str_starts_with($name,'/'),422,'Unsafe archive path.');
                $parts=explode('/',rtrim($name,'/'));foreach($parts as $part)abort_if(in_array($part,['.','..',''],true),422,'Unsafe archive path.');
                $prefix??=$parts[0];abort_if($prefix!==$parts[0],422,'Unexpected repository archive layout.');
                $ops=0;$attr=0;$zip->getExternalAttributesIndex($i,$ops,$attr);abort_if((($attr>>16)&0170000)===0120000,422,'Repositories containing symlinks are not supported.');
                $total+=$e['size'];abort_if($total>52428800,422,'Extracted repository exceeds 50 MB.');
            }
            return $prefix;
        } finally {$zip->close();}
    }
    public function install(Server $s,string $url,string $branch=''):array {
        @set_time_limit(180);
        [$owner,$repo]=self::repository($url);
        $lock=Cache::lock('baba-runtime:'.$s->uuid,1200);abort_unless($lock->get(),409,'Another server setup task is running.');
        $tmp=tempnam(sys_get_temp_dir(),'baba-git-');$stage=null;$files=app(DaemonFileRepository::class)->setServer($s);
        try {
            app(ServerCustomization::class)->offline($s);
            $client=new Client(['connect_timeout'=>5,'timeout'=>35,'allow_redirects'=>false,'headers'=>['User-Agent'=>'BABA-HOST-Panel','Accept'=>'application/vnd.github+json']]);
            $query=['per_page'=>1];if($branch!=='')$query['sha']=$branch;
            $data=json_decode($client->get('https://api.github.com/repos/'.$owner.'/'.$repo.'/commits',['query'=>$query])->getBody(),true);
            $sha=$data[0]['sha']??'';abort_unless(preg_match('/\A[0-9a-f]{40}\z/',$sha),422,'Could not resolve the repository branch.');
            $response=$client->get('https://codeload.github.com/'.$owner.'/'.$repo.'/zip/'.$sha,['stream'=>true,'headers'=>['Accept'=>'application/zip']]);
            abort_if((int)$response->getHeaderLine('Content-Length')>20971520,422,'ZIP download exceeds 20 MB.');
            $out=fopen($tmp,'wb');$body=$response->getBody();$size=0;
            try{while(!$body->eof()){$chunk=$body->read(65536);$size+=strlen($chunk);abort_if($size>20971520,422,'ZIP download exceeds 20 MB.');fwrite($out,$chunk);}}finally{fclose($out);}
            $prefix=self::inspect($tmp);
            $destination=$repo.'-'.bin2hex(random_bytes(4));$stage='.baba-github-'.bin2hex(random_bytes(8));
            $files->createDirectory($stage,'/');$files->putContent('/'.$stage.'/source.zip',file_get_contents($tmp));
            $files->decompressFile('/'.$stage,'source.zip');
            abort_if(collect($files->getDirectory('/'))->contains('name',$destination),409,'Destination already exists. Retry the import.');
            $files->renameFiles('/',[['from'=>$stage.'/'.$prefix,'to'=>$destination]]);
            return ['directory'=>'/'.$destination,'commit'=>$sha,'repository'=>$owner.'/'.$repo];
        } catch(\GuzzleHttp\Exception\GuzzleException $e){abort(422,'GitHub download failed. Check that the repository and branch are public and available, or retry after the GitHub rate limit resets.');}
        finally {if($stage){try{$files->deleteFiles('/',[$stage]);}catch(\Throwable $e){report($e);}}@unlink($tmp);$lock->release();}
    }
}
