/* Context actions use existing authorized admin links, never destructive requests. */
(function () {
    'use strict';
    var menu = document.createElement('div');
    menu.className = 'ba-context-menu'; menu.hidden = true; menu.setAttribute('role', 'menu');
    menu.setAttribute('aria-label', 'Manage record'); document.body.appendChild(menu);
    var trigger = null;
    function close(restore) {
        menu.hidden = true;
        if (trigger) { trigger.setAttribute('aria-expanded', 'false'); if (restore && document.contains(trigger)) trigger.focus(); }
    }
    function recordLinks(row) {
        return Array.from(row.querySelectorAll('a[href]')).filter(function (a) {
            var u = new URL(a.href, location.href);
            return u.origin === location.origin && /^\/admin\/(users|nodes|servers|locations|mounts|nests|databases)\/.+/.test(u.pathname);
        }).filter(function (a, i, links) { return links.findIndex(function (b) { return a.href === b.href; }) === i; }).slice(0, 6);
    }
    function open(row, x, y, button) {
        var links = recordLinks(row); if (!links.length) return;
        close(false); trigger = button; trigger.setAttribute('aria-expanded', 'true'); menu.replaceChildren();
        links.forEach(function (link, index) {
            var a = document.createElement('a'); a.href = link.href; a.setAttribute('role', 'menuitem');
            var icon = document.createElement('i'); icon.className = 'fa ' + (index === 0 ? 'fa-sliders' : 'fa-external-link'); icon.setAttribute('aria-hidden', 'true');
            var text = document.createElement('span');
            text.textContent = index === 0 ? 'Manage ' + (link.textContent.trim().slice(0, 48) || 'record') : (/\/servers/.test(a.pathname) ? 'View related servers' : (link.textContent.trim().slice(0, 48) || 'Open details'));
            a.append(icon, text); menu.appendChild(a);
        });
        menu.hidden = false;
        var rect = menu.getBoundingClientRect();
        menu.style.left = Math.max(8, Math.min(x, window.innerWidth - rect.width - 8)) + 'px';
        menu.style.top = Math.max(8, Math.min(y, window.innerHeight - rect.height - 8)) + 'px';
        menu.querySelector('a').focus();
    }
    document.querySelectorAll('.content table.table').forEach(function (table) {
        var rows = Array.from(table.querySelectorAll('tr')).filter(function (row) { return !row.querySelector('th') && recordLinks(row).length; });
        if (!rows.length) return;
        var existing = table.querySelector('[data-ba-manage]');
        if (!existing) {
            var header = table.querySelector('thead tr:last-child') || Array.from(table.querySelectorAll('tr')).find(function (row) { return row.querySelector('th'); });
            if (header) { var th = document.createElement('th'); th.textContent = 'Manage'; th.className = 'text-right ba-actions-column'; header.appendChild(th); }
        }
        rows.forEach(function (row) {
            var button = row.querySelector('[data-ba-manage]');
            if (!button) { var cell = document.createElement('td'); cell.className = 'text-right ba-actions-column'; button = document.createElement('button'); cell.appendChild(button); row.appendChild(cell); }
            button.type = 'button'; button.className = 'ba-manage-button'; button.setAttribute('aria-label', 'Manage this record'); button.setAttribute('aria-haspopup', 'menu'); button.setAttribute('aria-expanded', 'false');
            var icon = document.createElement('i'); icon.className = 'fa fa-ellipsis-h'; icon.setAttribute('aria-hidden', 'true'); button.replaceChildren(icon);
            button.addEventListener('click', function (e) { e.preventDefault(); e.stopPropagation(); var rect = button.getBoundingClientRect(); if (trigger === button && !menu.hidden) { close(false); return; } open(row, rect.right - 220, rect.bottom + 6, button); });
            row.addEventListener('contextmenu', function (e) { if (e.shiftKey || e.target.closest('input,textarea,select')) return; e.preventDefault(); open(row, e.clientX, e.clientY, button); });
            row.addEventListener('keydown', function (e) { if ((e.shiftKey && e.key === 'F10') || e.key === 'ContextMenu') { e.preventDefault(); var rect = button.getBoundingClientRect(); open(row, rect.right - 220, rect.bottom + 6, button); } });
        });
    });
    document.querySelectorAll('input[type=search],input[placeholder*=Search],input[placeholder*=search]').forEach(function(input){var group=input.closest('.input-group');if(group)group.classList.add('ba-search-group');input.setAttribute('aria-label',input.getAttribute('aria-label')||input.placeholder||'Search');});
    var icons = {users:'fa-users',servers:'fa-server',nodes:'fa-sitemap',locations:'fa-globe',mounts:'fa-hdd-o',nests:'fa-cubes',databases:'fa-database',settings:'fa-sliders',api:'fa-key'};
    var section = location.pathname.split('/')[2] || 'overview';
    document.querySelectorAll('.content-header>h1,.box-header>.box-title').forEach(function (heading) {
        if (heading.querySelector('.ba-heading-icon')) return;
        var icon = document.createElement('i'); icon.className = 'fa ba-heading-icon ' + (icons[section] || 'fa-th-large'); icon.setAttribute('aria-hidden', 'true'); heading.prepend(icon);
    });
    document.querySelectorAll('.box-tools .btn').forEach(function (button) {
        if (button.querySelector('i')) return;
        if (/Create New|Create$/i.test(button.textContent.trim())) { var icon = document.createElement('i'); icon.className = 'fa fa-plus'; icon.setAttribute('aria-hidden', 'true'); button.prepend(icon, document.createTextNode(' ')); }
    });
    document.addEventListener('click', function (e) { if (!menu.contains(e.target)) close(false); });
    document.addEventListener('keydown', function (e) {
        if (menu.hidden) return;
        if (e.key === 'Escape') { e.preventDefault(); close(true); }
        if (e.key === 'Tab') close(false);
        if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); var links = Array.from(menu.querySelectorAll('a')); var n = links.indexOf(document.activeElement); links[(n + (e.key === 'ArrowDown' ? 1 : -1) + links.length) % links.length].focus(); }
    });
    window.addEventListener('resize', function () { close(false); });
    window.addEventListener('scroll', function (e) { if (!menu.contains(e.target)) close(false); }, true);
}());
