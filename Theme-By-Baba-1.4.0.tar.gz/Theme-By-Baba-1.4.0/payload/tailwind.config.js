const colors = require('tailwindcss/colors');

const gray = {
    50: '#f8f7fc',
    100: '#ece9f5',
    200: '#c9c3d9',
    300: '#a39ab8',
    400: '#796e94',
    500: '#443a5c',
    600: '#303034',
    700: '#242427',
    800: '#161618',
    900: '#101012',
};

const purple = {
    50: '#faf5ff',
    100: '#f3e8ff',
    200: '#e1d5ff',
    300: '#c9b4fe',
    400: '#7f50f2',
    500: '#7f50f2',
    600: '#7f50f2',
    700: '#7f50f2',
    800: '#7f50f2',
    900: '#472d87',
};

module.exports = {
    content: [
        './resources/scripts/**/*.{js,ts,tsx}',
    ],
    theme: {
        extend: {
            fontFamily: {
                header: ['"IBM Plex Sans"', '"Roboto"', 'system-ui', 'sans-serif'],
            },
            colors: {
                black: '#09060f',
                primary: purple,
                purple: purple,
                gray: gray,
                neutral: gray,
                cyan: purple,
                blue: purple,
            },
            fontSize: {
                '2xs': '0.625rem',
            },
            transitionDuration: {
                250: '250ms',
            },
            borderColor: theme => ({
                default: '#2b243b',
            }),
        },
    },
    plugins: [
        require('@tailwindcss/line-clamp'),
        require('@tailwindcss/forms')({
            strategy: 'class',
        }),
    ]
};
