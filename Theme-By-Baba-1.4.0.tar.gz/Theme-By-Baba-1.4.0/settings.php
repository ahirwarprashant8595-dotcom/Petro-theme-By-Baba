<?php
[$script,$action,$panel,$folder]=$argv;
require $panel.'/vendor/autoload.php';$app=require $panel.'/bootstrap/app.php';$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();
$settings=app(Pterodactyl\Contracts\Repository\SettingsRepositoryInterface::class);
$keys=['settings::panel:theme','settings::app:name'];
if($action==='backup'){$values=[];foreach($keys as $key)$values[$key]=$settings->get($key,null);file_put_contents($folder.'/theme-settings-before.json',json_encode($values,JSON_THROW_ON_ERROR));chmod($folder.'/theme-settings-before.json',0600);}
elseif($action==='install'){$theme=json_decode(file_get_contents($folder.'/theme-settings.json'),true,512,JSON_THROW_ON_ERROR);app(Pterodactyl\Services\Theme\PanelTheme::class)->save($theme);}
elseif($action==='restore'){$values=json_decode(file_get_contents($folder.'/theme-settings-before.json'),true,512,JSON_THROW_ON_ERROR);foreach($values as $key=>$value){if($value===null)Illuminate\Support\Facades\DB::table('settings')->where('key',$key)->delete();else $settings->set($key,$value);}}
else throw new RuntimeException('Unknown action');
